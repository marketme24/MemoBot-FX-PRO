import React, { useEffect, useState } from "react";
import { ApiClient } from "../services/api";
import { PerformanceChart } from "../components/PerformanceChart";
import { IntegrationBlueprintHero } from "../components/IntegrationBlueprintHero";
import { WebSocketManager } from "../services/websocket";
import { TOPICS } from "../config/constants";
import { TrendingUp, TrendingDown, RefreshCw, ShieldAlert, Award, Briefcase, Zap, Activity, ChevronDown } from "lucide-react";
import { useNotification } from "../components/NotificationProvider";
import { useLanguage } from "../components/LanguageProvider";
import { useTheme } from "../components/ThemeProvider";
import { PageLoader } from "../components/PageLoader";

interface DashboardProps {
  onRefreshSidebar: () => void;
  complianceMode: "Islamic" | "Commercial";
  onComplianceToggle?: (mode: "Islamic" | "Commercial") => void;
  onNavigateTo?: (page: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onRefreshSidebar, complianceMode, onComplianceToggle, onNavigateTo }) => {
  const { t } = useLanguage();
  let accentColor = "#FA1F4E";
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
  } catch (e) {}

  const [balances, setBalances] = useState<any>(null);
  const [positions, setPositions] = useState<any>({});
  const [dailyStats, setDailyStats] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSystemLive, setIsSystemLive] = useState<boolean>(true);
  const { showAlert, showConfirm } = useNotification();

  const handleToggleSystemLive = async () => {
    const nextState = !isSystemLive;
    try {
      if (nextState) {
        await ApiClient.post("/engine/start").catch(() => {});
        setIsSystemLive(true);
        showAlert("TRADING SYSTEM INITIALIZED: LIVE EXECUTION ACTIVE");
      } else {
        await ApiClient.post("/engine/stop").catch(() => {});
        setIsSystemLive(false);
        showAlert("TRADING SYSTEM IDLED: ALL STREAMS PAUSED");
      }
      onRefreshSidebar();
    } catch (err) {
      setIsSystemLive(nextState);
    }
  };

  const fetchDashboardData = async () => {
    try {
      const bData = await ApiClient.get("/execution/balances");
      const pData = await ApiClient.get("/execution/active-positions");
      const dData = await ApiClient.get("/execution/daily-stats");
      const hData = await ApiClient.get("/execution/history");

      setBalances(bData);
      setPositions(pData);
      setDailyStats(dData);
      
      // format chart data
      const chartPoints = (hData || []).slice().reverse().map((t: any, idx: number) => {
        const profit = t.fill_price ? (t.fill_price - t.price) * (t.fill_amount || t.amount) : 0;
        const netProfit = t.side === "SELL" ? profit : -profit;
        return {
          timestamp: new Date(t.timestamp).toLocaleTimeString(),
          value: netProfit
        };
      });
      
      // If no points, show initial zero line
      if (chartPoints.length === 0) {
        chartPoints.push({ timestamp: "Start", value: 0 });
      }
      setHistory(chartPoints);
      setLoading(false);
      onRefreshSidebar();
    } catch (err) {
      console.error("Failed to load dashboard data:", err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();

    // WS subscriptions (Rule 6, stateless reactivity)
    const unsubBalance = WebSocketManager.subscribe(TOPICS.BALANCE_CHANGED, () => {
      fetchDashboardData();
    });

    const unsubMode = WebSocketManager.subscribe(TOPICS.ENGINE_MODE_CHANGED, () => {
      fetchDashboardData();
    });

    const unsubKill = WebSocketManager.subscribe(TOPICS.EMERGENCY_KILL_SWITCH_ACTIVATED, () => {
      fetchDashboardData();
    });

    return () => {
      unsubBalance();
      unsubMode();
      unsubKill();
    };
  }, []);

  const handleKillSwitch = async () => {
    showConfirm(
      "DANGER: Triggering this emergency kill switch will shut down all active trade engines and cancel all pending pipelines. Execute emergency halt?",
      async () => {
        try {
          await ApiClient.post("/engine/kill");
          showAlert("EMERGENCY KILL SWITCH COMMAND GRANTED. ALL SYSTEMS DOCKED.");
          await fetchDashboardData();
        } catch (err) {
          showAlert("Kill switch failed to propagate.");
        }
      },
      undefined,
      "EMERGENCY KILL SWITCH"
    );
  };

  if (loading) {
    return <PageLoader message="SYNCHRONIZING WITH IMMUTABLE EXCHANGE LEDGER..." subMessage="Deterministic MemoCore Cluster Active" />;
  }

  const pnl = dailyStats?.daily_pnl || 0.0;
  const isPnlPositive = pnl >= 0;

  // Flatten positions list
  const flatPositions: any[] = [];
  Object.keys(positions || {}).forEach((engId) => {
    const arr = positions[engId] || [];
    arr.forEach((p: any) => {
      flatPositions.push({ ...p, engineId: engId });
    });
  });

  return (
    <div className="flex-1 bg-[#040508] p-4 sm:p-6 overflow-y-auto space-y-6">
      
      {/* Page Header */}
      <div 
        style={{ borderColor: `${accentColor}30` }}
        className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b pb-4 shrink-0"
      >
        <div>
          <h2 
            style={{ color: accentColor, textShadow: `0 0 15px ${accentColor}40` }}
            className="text-2xl font-aquire tracking-tighter uppercase"
          >
            {t("DASHBOARD CONTROL DECK")}
          </h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            {t("Institutional ledger metrics, active spot allocation, and risk management parameters.")}
          </p>
        </div>
        <div className="flex flex-col items-end gap-2.5 w-full xl:w-auto">
          {/* Protocol Mode Toggle Buttons */}
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-[#8a8d9a] font-bold uppercase tracking-widest mr-1">{t("ACTIVE PROTOCOL:")}</span>
            <div className="flex items-center p-1 rounded-xl bg-[#05060b] border border-[#1b202e] gap-1">
              <button
                type="button"
                onClick={() => onComplianceToggle && onComplianceToggle("Islamic")}
                style={
                  complianceMode === "Islamic"
                    ? {
                        backgroundColor: accentColor,
                        color: "#ffffff",
                        boxShadow: `0 0 12px ${accentColor}50`,
                      }
                    : {}
                }
                className={`px-3.5 py-1 rounded-lg text-[10.5px] font-mono font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${
                  complianceMode === "Islamic"
                    ? "text-white"
                    : "bg-transparent text-slate-400 hover:text-white"
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${complianceMode === "Islamic" ? "bg-white shadow-[0_0_6px_#ffffff]" : "bg-slate-600"}`} />
                {t("ISLAMIC")}
              </button>

              <button
                type="button"
                onClick={() => onComplianceToggle && onComplianceToggle("Commercial")}
                style={
                  complianceMode === "Commercial"
                    ? {
                        backgroundColor: accentColor,
                        color: "#ffffff",
                        boxShadow: `0 0 12px ${accentColor}50`,
                      }
                    : {}
                }
                className={`px-3.5 py-1 rounded-lg text-[10.5px] font-mono font-black uppercase tracking-wider transition-all cursor-pointer flex items-center gap-1.5 ${
                  complianceMode === "Commercial"
                    ? "text-white"
                    : "bg-transparent text-slate-400 hover:text-white"
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${complianceMode === "Commercial" ? "bg-white shadow-[0_0_6px_#ffffff]" : "bg-slate-600"}`} />
                {t("COMMERCIAL")}
              </button>
            </div>
          </div>

          {/* Emergency Kill Switch */}
          <button
            onClick={handleKillSwitch}
            style={{
              borderColor: `${accentColor}60`,
              backgroundColor: `${accentColor}15`,
              color: "#ffffff",
              boxShadow: `0 0 12px ${accentColor}20`
            }}
            className="flex items-center gap-2 px-4 py-2 border rounded-xl text-xs font-mono font-black tracking-wide transition-all uppercase w-full justify-center cursor-pointer active:scale-98"
          >
            <ShieldAlert className="w-3.5 h-3.5" style={{ color: accentColor }} />
            <span>{t("EMERGENCY KILL SWITCH")}</span>
          </button>

          {/* Live / Idle Button */}
          <button
            onClick={handleToggleSystemLive}
            style={
              isSystemLive
                ? {
                    backgroundColor: `${accentColor}20`,
                    borderColor: accentColor,
                    boxShadow: `0 0 16px ${accentColor}35`,
                    color: "#ffffff"
                  }
                : {
                    backgroundColor: "#080a12",
                    borderColor: "#181d2a",
                    color: "#8a8d9a"
                  }
            }
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-black tracking-wider transition-all uppercase w-full border cursor-pointer active:scale-98"
          >
            <span
              style={{ backgroundColor: isSystemLive ? accentColor : "#64748b" }}
              className={`w-2 h-2 rounded-full ${isSystemLive ? "animate-pulse" : ""}`}
            />
            <span>{isSystemLive ? t("SYSTEM: LIVE") : t("SYSTEM: IDLE")}</span>
          </button>
        </div>
      </div>

      {/* Primary Visual Artwork First Impression: Integration Blueprint Engine Station */}
      <IntegrationBlueprintHero onNavigateTo={onNavigateTo} />

      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Equity */}
        <div 
          className="bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-4 sm:p-5 rounded-2xl flex justify-between items-start transition-all shadow-lg"
          style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)' }}
        >
          <div className="space-y-1">
            <span style={{ color: accentColor }} className="text-[10px] uppercase font-bold tracking-wider block">
              {t("ACCOUNT EQUITY")}
            </span>
            <div className="text-xl font-black font-mono text-white">
              ${(balances?.net_worth ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-[#717688] font-mono">100% VERIFIED SPOT</span>
          </div>
          <div 
            className="w-9 h-9 rounded-xl bg-[#05060b] border border-[#1b202e] flex items-center justify-center shrink-0"
            style={{ boxShadow: `0 0 10px ${accentColor}15` }}
          >
            <Briefcase className="w-4 h-4" style={{ color: accentColor }} />
          </div>
        </div>

        {/* USDT Available */}
        <div 
          className="bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-4 sm:p-5 rounded-2xl flex justify-between items-start transition-all shadow-lg"
          style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)' }}
        >
          <div className="space-y-1">
            <span style={{ color: accentColor }} className="text-[10px] uppercase font-bold tracking-wider block">
              {t("AVAILABLE USDT")}
            </span>
            <div className="text-xl font-black font-mono text-white">
              ${(balances?.balances?.USDT || 0.0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
            <span className="text-[10px] text-[#717688] font-mono">LIQUID ALLOCATION</span>
          </div>
          <div 
            className="w-9 h-9 rounded-xl bg-[#05060b] border border-[#1b202e] flex items-center justify-center shrink-0"
            style={{ boxShadow: `0 0 10px ${accentColor}15` }}
          >
            <Zap className="w-4 h-4" style={{ color: accentColor }} />
          </div>
        </div>

        {/* Total Trades */}
        <div 
          className="bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-4 sm:p-5 rounded-2xl flex justify-between items-start transition-all shadow-lg"
          style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)' }}
        >
          <div className="space-y-1">
            <span style={{ color: accentColor }} className="text-[10px] uppercase font-bold tracking-wider block">
              {t("TOTAL TRADES")}
            </span>
            <div className="text-xl font-black font-mono text-white">
              {dailyStats?.total_trades || 0}
            </div>
            <span className="text-[10px] text-[#717688]">{t("EXECUTED TODAY")}</span>
          </div>
          <div 
            className="w-9 h-9 rounded-xl bg-[#05060b] border border-[#1b202e] flex items-center justify-center shrink-0"
            style={{ boxShadow: `0 0 10px ${accentColor}15` }}
          >
            <Activity className="w-4 h-4" style={{ color: accentColor }} />
          </div>
        </div>

        {/* Win Rate */}
        <div 
          className="bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-4 sm:p-5 rounded-2xl flex justify-between items-start transition-all shadow-lg"
          style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)' }}
        >
          <div className="space-y-1">
            <span style={{ color: accentColor }} className="text-[10px] uppercase font-bold tracking-wider block">
              {t("WIN RATE INDEX")}
            </span>
            <div className="text-xl font-black font-mono text-white">
              {(dailyStats?.win_rate || 0.0).toFixed(1)}%
            </div>
            <span className="text-[10px] text-[#717688]">
              {dailyStats?.wins || 0}W / {dailyStats?.losses || 0}L {t("CLOSED TODAY")}
            </span>
          </div>
          <div 
            className="w-9 h-9 rounded-xl bg-[#05060b] border border-[#1b202e] flex items-center justify-center shrink-0"
            style={{ boxShadow: `0 0 10px ${accentColor}15` }}
          >
            <Award className="w-4 h-4" style={{ color: accentColor }} />
          </div>
        </div>
      </div>

      {/* Mid row: P&L Card + Performance Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* P&L card */}
        <div 
          className="lg:col-span-1 bg-[#080a12]/90 border border-[#181d2a] hover:border-[#2a3248] p-5 rounded-2xl flex flex-col justify-between min-h-[220px] transition-all shadow-lg"
          style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)' }}
        >
          <div>
            <span style={{ color: accentColor }} className="text-[10px] uppercase font-bold tracking-wider block mb-1">
              {t("DAILY UNREALIZED YIELD")}
            </span>
            <h3 className="text-4xl font-black font-mono text-white tracking-tight">
              {isPnlPositive ? "+" : ""}${(pnl ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h3>
          </div>
          <div className="mt-4 border-t border-[#181d2a] pt-4 flex items-center gap-2">
            {isPnlPositive ? (
              <TrendingUp className="w-5 h-5 text-white" />
            ) : (
              <TrendingDown className="w-5 h-5" style={{ color: accentColor }} />
            )}
            <span className="text-xs font-mono font-bold text-white">
              {isPnlPositive ? t("▲ YIELD ASCENDING") : t("▼ DRAWDOWN INTRUSION")}
            </span>
          </div>
        </div>

        {/* Chart */}
        <div className="lg:col-span-2">
          <PerformanceChart data={history} />
        </div>
      </div>

      {/* Active Positions Table */}
      <div 
        className="bg-[#080a12]/90 border border-[#181d2a] rounded-2xl p-5 shadow-lg"
        style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)' }}
      >
        <div className="flex items-center justify-between mb-4 border-b border-[#181d2a] pb-3">
          <span style={{ color: accentColor }} className="text-xs font-bold font-mono tracking-wider uppercase">
            {t("ACTIVE SPOT OPEN POSITIONS")}
          </span>
          <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-[#05060b] border border-[#1b202e] text-slate-400 font-bold uppercase">
            {flatPositions.length} POSITIONS RECORDED
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#181d2a] text-[#717688] uppercase font-mono">
                <th className="py-3 px-4 font-semibold">{t("ENGINE ID")}</th>
                <th className="py-3 px-4 font-semibold">{t("SYMBOL")}</th>
                <th className="py-3 px-4 font-semibold">{t("SIZE")}</th>
                <th className="py-3 px-4 font-semibold">{t("ENTRY PRICE")}</th>
                <th className="py-3 px-4 font-semibold">{t("MARK PRICE")}</th>
                <th className="py-3 px-4 font-semibold">{t("UNREALIZED P&L")}</th>
                <th className="py-3 px-4 font-semibold">{t("VALUE")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#181d2a]">
              {flatPositions.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#717688] font-mono">
                    {t("NO ACTIVE TRADING POSITIONS LOADED IN PLATFORM MEMORY")}
                  </td>
                </tr>
              ) : (
                flatPositions.map((pos, idx) => (
                  <tr key={idx} className="hover:bg-[#0c0f18] font-mono transition-colors">
                    <td className="py-3 px-4 text-white font-bold">{t(pos.engineId.toUpperCase())}</td>
                    <td className="py-3 px-4 text-white">{t(pos.symbol)}</td>
                    <td className="py-3 px-4 text-white">{pos.amount}</td>
                    <td className="py-3 px-4 text-white">${(pos.entry_price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                    <td className="py-3 px-4 text-white">${(pos.current_price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                    <td className="py-3 px-4 font-bold text-white">
                      {pos.pnl >= 0 ? "+" : ""}${(pos.pnl ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })} ({(pos.roi ?? 0).toFixed(2)}%)
                    </td>
                    <td className="py-3 px-4 text-white">${(pos.locked_margin ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
