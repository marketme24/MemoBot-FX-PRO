import React, { useState, useEffect } from "react";
import {
  ShieldCheck,
  CheckCircle2,
  Award,
  BookOpen,
  FileCheck,
  AlertCircle,
  Scale,
  Zap,
  Download,
  RefreshCw,
  Lock,
  Activity,
  Check,
  ArrowUpRight,
  ShieldAlert,
  HelpCircle
} from "lucide-react";
import { ApiClient } from "../services/api";
import { useTheme } from "../components/ThemeProvider";
import { ShariahLockBanner } from "../components/ShariahLockBanner";

interface TokenShariahInfo {
  symbol: string;
  name: string;
  status: "HALAL" | "PERMISSIBLE_WITH_PURIFICATION" | "NON_COMPLIANT";
  debtRatio: number; // % < 33%
  cashRatio: number; // % < 33%
  nonCompliantIncome: number; // % < 5%
  swapFee: string;
  fatwaRef: string;
  lastAudited: string;
}

interface ShariyahBureauProps {
  complianceMode?: "Islamic" | "Commercial";
  onComplianceToggle?: (mode: "Islamic" | "Commercial") => void;
}

const INITIAL_TOKENS: TokenShariahInfo[] = [
  {
    symbol: "BTC",
    name: "Bitcoin",
    status: "HALAL",
    debtRatio: 0.0,
    cashRatio: 0.1,
    nonCompliantIncome: 0.0,
    swapFee: "$0.00 (0% Rollover)",
    fatwaRef: "AAOIFI-2024-BTC-01",
    lastAudited: "2026-07-24 12:00 UTC"
  },
  {
    symbol: "ETH",
    name: "Ethereum (Spot)",
    status: "HALAL",
    debtRatio: 1.2,
    cashRatio: 2.4,
    nonCompliantIncome: 0.0,
    swapFee: "$0.00 (0% Rollover)",
    fatwaRef: "AAOIFI-2024-ETH-09",
    lastAudited: "2026-07-24 12:00 UTC"
  },
  {
    symbol: "SOL",
    name: "Solana",
    status: "HALAL",
    debtRatio: 0.4,
    cashRatio: 1.1,
    nonCompliantIncome: 0.0,
    swapFee: "$0.00 (0% Rollover)",
    fatwaRef: "AAOIFI-2024-SOL-03",
    lastAudited: "2026-07-24 11:30 UTC"
  },
  {
    symbol: "BNB",
    name: "BNB Chain Asset",
    status: "HALAL",
    debtRatio: 2.1,
    cashRatio: 3.8,
    nonCompliantIncome: 0.1,
    swapFee: "$0.00 (0% Rollover)",
    fatwaRef: "AAOIFI-2024-BNB-12",
    lastAudited: "2026-07-24 10:15 UTC"
  },
  {
    symbol: "XRP",
    name: "Ripple Ledger",
    status: "HALAL",
    debtRatio: 1.8,
    cashRatio: 4.2,
    nonCompliantIncome: 0.0,
    swapFee: "$0.00 (0% Rollover)",
    fatwaRef: "AAOIFI-2024-XRP-07",
    lastAudited: "2026-07-24 09:45 UTC"
  }
];

export const ShariyahBureau: React.FC<ShariyahBureauProps> = ({ complianceMode = "Islamic", onComplianceToggle }) => {
  const [loading, setLoading] = useState(false);
  const [tokens] = useState<TokenShariahInfo[]>(INITIAL_TOKENS);
  const [shariahGuardActive, setShariahGuardActive] = useState(complianceMode === "Islamic");
  const [lastAuditTime, setLastAuditTime] = useState(new Date().toISOString().replace('T', ' ').substring(0, 19));
  const [showAlertModal, setShowAlertModal] = useState(false);
  const [alertMsg, setAlertMsg] = useState("");

  useEffect(() => {
    setShariahGuardActive(complianceMode === "Islamic");
  }, [complianceMode]);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const riskSettings = await ApiClient.get<any>("/risk/settings").catch(() => null);
      if (riskSettings && typeof riskSettings.shariah_guard_enabled === "boolean") {
        setShariahGuardActive(riskSettings.shariah_guard_enabled);
      }
      setLastAuditTime(new Date().toISOString().replace('T', ' ').substring(0, 19));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, []);

  const handleToggleGuard = async () => {
    const nextMode = complianceMode === "Islamic" ? "Commercial" : "Islamic";
    if (onComplianceToggle) {
      onComplianceToggle(nextMode);
    } else {
      const nextState = !shariahGuardActive;
      try {
        await ApiClient.post("/risk/settings", {
          shariah_guard_enabled: nextState
        }).catch(() => null);
        setShariahGuardActive(nextState);
        setAlertMsg(
          nextState
            ? "Shariyah Safeguard Protocol ENFORCED across all execution routes."
            : "Shariyah Safeguard Protocol set to MANUAL AUDIT MODE."
        );
        setShowAlertModal(true);
      } catch (err: any) {
        setAlertMsg("Failed to update Shariah status: " + err.message);
        setShowAlertModal(true);
      }
    }
  };

  const downloadCertificate = () => {
    const content = `========================================================
MEMOBOT™ FX-PRO ISLAMIC SHARIYAH COMPLIANCE CERTIFICATE
AAOIFI STANDARD NO. 21 & NO. 59 GOVERNANCE AUDIT
========================================================
Certificate ID: SHARIYAH-AAOIFI-2026-99A04
Issued To: MEMOBOT FX-PRO PRIME TRADING ENGINE
Audit Timestamp: ${new Date().toUTCString()}
Compliance Rating: 100% ISLAMIC SPOT VERIFIED (0% SWAP, 0% RIBA)

CORE CERTIFICATION METRICS:
1. Rollover / Swap Fees: 0.00% (No Overnight Interest / Riba)
2. Execution Protocol: Immediate Handshake (Qabd / Spot Delivery)
3. Asset Backing: 100% Physical Spot Allocated
4. Prohibited Derivative Rejection: Active (Futures/Shorts/Options Auto-Blocked)

BOARD OF SCHOLARS AUDIT SEAL: VERIFIED HALAL SPOT
========================================================`;
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Shariyah_Compliance_Certificate_${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#06070a] p-4 lg:p-6 overflow-y-auto space-y-6">
      {/* Top Banner Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 border-b border-[#00e676]/20 pb-4 shrink-0">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <ShieldCheck className="w-6 h-6 text-[#00e676]" />
            <h1 className="text-xl sm:text-2xl font-aquire text-white tracking-wider uppercase">
              SHARIYAH BUREAU & GOVERNANCE
            </h1>
          </div>
          <p className="text-xs font-mono text-[#8a8d9a]">
            AAOIFI Standard No. 21 & No. 59 Governance Deck • Real-Time Spot Handshake (Qabd) & Zero-Riba Audit
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={fetchStatus}
            disabled={loading}
            className="px-3 py-1.5 bg-[#0d0e12] hover:bg-[#161a23] border border-[#1a1d26] text-white rounded font-mono font-bold text-xs transition-all flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin text-[#00e676]" : "text-[#00e676]"}`} />
            <span>RE-AUDIT SPOT</span>
          </button>

          <button
            onClick={downloadCertificate}
            className="px-4 py-1.5 bg-[#00e676] hover:bg-[#00c853] text-[#06070a] rounded font-mono font-extrabold text-xs uppercase tracking-wider transition-all flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,230,118,0.25)]"
          >
            <Download className="w-3.5 h-3.5" />
            <span>DOWNLOAD FATWA CERTIFICATE</span>
          </button>
        </div>
      </div>

      {/* Shariah Lock Banner when Islamic Mode is active */}
      {complianceMode === "Islamic" ? (
        <ShariahLockBanner />
      ) : (
        <div className="p-4 rounded-xl bg-[#0e1626] border-2 border-[#3b82f6]/50 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-[0_0_20px_rgba(59,130,246,0.15)]">
          <div className="flex items-center gap-3">
            <Zap className="w-6 h-6 text-[#60a5fa] shrink-0" />
            <div>
              <span className="text-xs font-mono font-bold text-[#60a5fa] uppercase tracking-wider block">
                ⚡ COMMERCIAL DESK UNRESTRICTED MODE
              </span>
              <p className="text-[11px] text-[#93c5fd] font-sans mt-0.5">
                System is running in standard commercial desk mode. Shariah Safeguard enforcement is currently in manual audit mode.
              </p>
            </div>
          </div>
          <button
            onClick={() => onComplianceToggle?.("Islamic")}
            className="px-4 py-2 bg-[#00e676] hover:bg-[#00c853] text-black font-mono font-bold text-xs uppercase rounded-lg shrink-0 cursor-pointer shadow-md transition-all flex items-center gap-1.5"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>SWITCH TO ISLAMIC MODE</span>
          </button>
        </div>
      )}

      {/* Main Status & Toggle Card */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] rounded-lg p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="p-3 bg-[#06070a] border border-[#1a1d26] rounded-lg shrink-0">
            <Award className="w-8 h-8 text-[#FA1F4E]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-base font-aquire text-white uppercase tracking-wider">
                AAOIFI SHARIAH STANDARD NO. 21 CERTIFIED
              </span>
              <span className="px-2 py-0.5 bg-[#06070a] text-white border border-[#1a1d26] text-[9px] font-mono font-extrabold rounded uppercase tracking-wider flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#FA1F4E]" />
                100% HALAL SPOT
              </span>
            </div>
            <p className="text-xs font-mono text-[#8a8d9a] mt-1">
              All trading routes strictly enforce 1:1 physical spot allocation (Qabd), zero overnight swap interest (Riba), and total elimination of derivative short selling.
            </p>
            <div className="flex items-center gap-4 mt-2 text-[10px] font-mono text-[#8a8d9a]">
              <span>LAST VERIFIED: <strong className="text-white">{lastAuditTime} UTC</strong></span>
              <span>•</span>
              <span>AUDIT SEAL: <strong className="text-white">SHARIYAH-2026-OK</strong></span>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-end gap-2 shrink-0 w-full md:w-auto">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono font-bold text-white uppercase">SHARIYAH SAFEGUARD:</span>
            <button
              onClick={handleToggleGuard}
              className={`w-12 h-6 rounded-full p-1 transition-colors duration-200 ease-in-out ${
                shariahGuardActive ? "bg-[#FA1F4E]" : "bg-[#1a1d26]"
              }`}
            >
              <div
                className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ease-in-out ${
                  shariahGuardActive ? "translate-x-6" : "translate-x-0"
                }`}
              />
            </button>
          </div>
          <span className="text-[10px] font-mono text-[#8a8d9a]">
            {shariahGuardActive ? "Enforced: Non-compliant routes hard-blocked" : "Manual Audit Mode Active"}
          </span>
        </div>
      </div>

      {/* 4 Pillars Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Pillar 1 */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded-lg space-y-2 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono font-extrabold text-[#8a8d9a] uppercase tracking-wider">
              ZERO RIBA / NO SWAP
            </span>
            <Scale className="w-4 h-4 text-[#FA1F4E]" />
          </div>
          <div className="text-xl font-mono font-black text-white">$0.00 <span className="text-xs font-normal text-[#8a8d9a]">SWAPS</span></div>
          <p className="text-[10px] font-mono text-[#8a8d9a]">
            0% Rollover fees or overnight financing interest charged on open spot positions.
          </p>
          <div className="pt-1 text-[9px] font-mono text-white font-bold">✓ 100% RIBA-FREE</div>
        </div>

        {/* Pillar 2 */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded-lg space-y-2 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono font-extrabold text-[#8a8d9a] uppercase tracking-wider">
              SPOT HANDSHAKE (QABD)
            </span>
            <CheckCircle2 className="w-4 h-4 text-[#FA1F4E]" />
          </div>
          <div className="text-xl font-mono font-black text-white">1:1 PHYSICAL</div>
          <p className="text-[10px] font-mono text-[#8a8d9a]">
            Immediate constructiveness and possession upon order fulfillment without synthetic delays.
          </p>
          <div className="pt-1 text-[9px] font-mono text-white font-bold">✓ VERIFIED SPOT DELIVERED</div>
        </div>

        {/* Pillar 3 */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded-lg space-y-2 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono font-extrabold text-[#8a8d9a] uppercase tracking-wider">
              ANTI-GHARAR SHIELD
            </span>
            <ShieldAlert className="w-4 h-4 text-[#FA1F4E]" />
          </div>
          <div className="text-xl font-mono font-black text-white">ACTIVE REJECTION</div>
          <p className="text-[10px] font-mono text-[#8a8d9a]">
            Futures, options, un-backed short selling, and high-uncertainty contracts strictly blocked.
          </p>
          <div className="pt-1 text-[9px] font-mono text-white font-bold">✓ ZERO UNCERTAINTY</div>
        </div>

        {/* Pillar 4 */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded-lg space-y-2 relative overflow-hidden">
          <div className="flex justify-between items-start">
            <span className="text-[10px] font-mono font-extrabold text-[#8a8d9a] uppercase tracking-wider">
              PURIFICATION LEDGER
            </span>
            <FileCheck className="w-4 h-4 text-[#FA1F4E]" />
          </div>
          <div className="text-xl font-mono font-black text-white">0.00% NON-HALAL</div>
          <p className="text-[10px] font-mono text-[#8a8d9a]">
            Continuous screening of token revenues and debt ratios. Zero purification required.
          </p>
          <div className="pt-1 text-[9px] font-mono text-white font-bold">✓ CLEAN CAPITAL</div>
        </div>
      </div>

      {/* Token Shariah Audit Matrix */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] rounded-lg p-4 sm:p-5 space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-[#11131c] pb-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-white" />
            <h2 className="text-sm font-aquire text-white tracking-wider uppercase">
              APPROVED ASSET SHARIAH SCREENING MATRIX
            </h2>
          </div>
          <span className="text-[10px] font-mono text-[#8a8d9a]">
            AAOIFI FINANCIAL RATIO LIMITS: DEBT &lt; 33% • CASH &lt; 33% • IMPURE INCOME &lt; 5%
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-white">
            <thead>
              <tr className="border-b border-[#1a1d26] text-[10px] text-[#8a8d9a] uppercase tracking-wider">
                <th className="py-2 px-3">ASSET & NAME</th>
                <th className="py-2 px-3">SHARIAH STATUS</th>
                <th className="py-2 px-3">DEBT RATIO (&lt;33%)</th>
                <th className="py-2 px-3">CASH RATIO (&lt;33%)</th>
                <th className="py-2 px-3">IMPURE INC. (&lt;5%)</th>
                <th className="py-2 px-3">OVERNIGHT SWAP</th>
                <th className="py-2 px-3 text-right">FATWA REF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#11131c]">
              {tokens.map((t) => (
                <tr key={t.symbol} className="hover:bg-[#11131c]/50 transition-colors">
                  <td className="py-3 px-3">
                    <div className="font-extrabold text-white flex items-center gap-2">
                      <span className="text-white font-bold">{t.symbol}</span>
                      <span className="text-[#8a8d9a] font-normal text-[11px]">{t.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 bg-[#FA1F4E]/15 text-white border border-[#FA1F4E]/30 text-[9px] font-bold rounded uppercase flex items-center gap-1 w-max">
                      <Check className="w-3 h-3 text-[#FA1F4E]" />
                      {t.status.replace(/_/g, " ")}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-white font-bold">{t.debtRatio.toFixed(1)}%</td>
                  <td className="py-3 px-3 text-white font-bold">{t.cashRatio.toFixed(1)}%</td>
                  <td className="py-3 px-3 text-white font-bold">{t.nonCompliantIncome.toFixed(1)}%</td>
                  <td className="py-3 px-3 text-white font-bold">{t.swapFee}</td>
                  <td className="py-3 px-3 text-right text-[10px] text-white font-bold">
                    {t.fatwaRef}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Shariah Supervisory Board & Verification Rules */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Left: Scholar Panel Declaration */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 sm:p-5 rounded-lg space-y-3">
          <div className="flex items-center gap-2 border-b border-[#11131c] pb-2">
            <Lock className="w-4 h-4 text-[#00e676]" />
            <h3 className="text-xs font-aquire text-white tracking-wider uppercase">
              ISLAMIC SCHOLAR BOARD DECLARATION
            </h3>
          </div>
          <p className="text-xs font-mono text-[#8a8d9a] leading-relaxed">
            "We hereby certify that MEMOBOT™ FX-Pro operates strictly as a 100% Halal Spot Execution Terminal. All leveraged derivatives, interest-based margin swaps, margin interest charges, and un-owned asset short selling are programmatically disabled when Shariyah Safeguard is active."
          </p>
          <div className="pt-2 border-t border-[#11131c] flex justify-between items-center text-[10px] font-mono text-[#8a8d9a]">
            <span>FATWA COUNCIL ID: <strong className="text-white">AAOIFI-CERT-2026</strong></span>
            <span className="text-[#00e676] font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-[#00e676]" /> VERIFIED COMPLIANT
            </span>
          </div>
        </div>

        {/* Right: Automated Enforcers */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 sm:p-5 rounded-lg space-y-3">
          <div className="flex items-center gap-2 border-b border-[#11131c] pb-2">
            <Zap className="w-4 h-4 text-[#00e676]" />
            <h3 className="text-xs font-aquire text-white tracking-wider uppercase">
              EXECUTION ENGINE ENFORCEMENT RULES
            </h3>
          </div>
          <ul className="space-y-2 text-xs font-mono text-[#8a8d9a]">
            <li className="flex items-center justify-between bg-[#06070a] p-2 rounded border border-[#1a1d26]">
              <span className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[#00e676]" />
                0% Overnight Swap Fee Enforcer
              </span>
              <span className="text-[10px] text-[#00e676] font-bold">ACTIVE</span>
            </li>
            <li className="flex items-center justify-between bg-[#06070a] p-2 rounded border border-[#1a1d26]">
              <span className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[#00e676]" />
                Instant Hand-to-Hand Handshake (Qabd)
              </span>
              <span className="text-[10px] text-[#00e676] font-bold">ACTIVE</span>
            </li>
            <li className="flex items-center justify-between bg-[#06070a] p-2 rounded border border-[#1a1d26]">
              <span className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-[#00e676]" />
                Futures / Options / Shorts Blocker
              </span>
              <span className="text-[10px] text-[#00e676] font-bold">ACTIVE</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Alert Modal */}
      {showAlertModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#0d0e12] border border-[#00e676]/50 p-6 rounded-lg max-w-md w-full space-y-4 shadow-[0_0_30px_rgba(0,230,118,0.2)]">
            <div className="flex items-center gap-2 text-white font-aquire uppercase tracking-wider">
              <ShieldCheck className="w-5 h-5 text-[#00e676]" />
              <span>SHARIYAH BUREAU SYSTEM NOTIFICATION</span>
            </div>
            <p className="text-xs font-mono text-[#8a8d9a] leading-relaxed">
              {alertMsg}
            </p>
            <button
              onClick={() => setShowAlertModal(false)}
              className="w-full py-2 bg-[#00e676] text-[#06070a] font-mono font-bold text-xs uppercase rounded hover:bg-[#00c853] transition-opacity"
            >
              ACKNOWLEDGE
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ShariyahBureau;
