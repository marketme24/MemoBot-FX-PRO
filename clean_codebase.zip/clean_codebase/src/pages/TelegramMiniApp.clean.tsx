import React, { useState, useEffect } from 'react';
import { Bot, TrendingUp, TrendingDown, Clock, Activity, Zap, RefreshCw, Briefcase, ChevronRight } from 'lucide-react';
import { ApiClient } from '../services/api';
import { useNotification } from '../components/NotificationProvider';

export function TelegramMiniApp() {
  const [advice, setAdvice] = useState<string>("Analyzing market sentiment...");
  const [paperBalance, setPaperBalance] = useState<number>(100000);
  const [activeTrades, setActiveTrades] = useState<any[]>([]);
  const { showAlert } = useNotification();

  // 1- Hourly Advice
  useEffect(() => {
    const advices = [
      "EUR/USD showing strong support at 1.0850. Consider long positions with tight stops.",
      "Gold (XAU/USD) volatility increasing ahead of FOMC. Reduce exposure.",
      "GBP/JPY breakout imminent. Watch 190.20 resistance level closely.",
      "Crypto markets consolidating. Bitcoin holding above 60k. Favorable risk/reward for altcoins."
    ];
    setAdvice(advices[Math.floor(0 * advices.length)]);
