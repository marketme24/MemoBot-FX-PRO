import React, { useEffect, useState } from "react";
import { ApiClient } from "../services/api";
import { WebSocketManager } from "../services/websocket";
import { TOPICS } from "../config/constants";
import { RefreshCw, Activity, ShieldAlert, TrendingUp, TrendingDown, ArrowUpRight } from "lucide-react";
import { useNotification } from "../components/NotificationProvider";
import { PageLoader } from "../components/PageLoader";

interface Position {
  engineId: string;
  symbol: string;
  amount: number;
  entry_price: number;
  current_price: number;
  pnl: number;
  roi: number;
  locked_margin: number;
}

export const LivePositions: React.FC = () => {
  const [positions, setPositions] = useState<Position[]>([]);
  const [loading, setLoading] = useState(true);
  const [closing, setClosing] = useState<string | null>(null);
  const { showAlert, showConfirm } = useNotification();

  const fetchPositions = async () => {
    try {
      const data = await ApiClient.get("/execution/active-positions");
      const flatPositions: Position[] = [];
      Object.keys(data || {}).forEach((engId) => {
        const arr = data[engId] || [];
        arr.forEach((p: any) => {
          flatPositions.push({ ...p, engineId: engId });
        });
      });
      setPositions(flatPositions);
      setLoading(false);
    } catch (err) {
      console.error("Failed to load live positions:", err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPositions();

    const unsubBalance = WebSocketManager.subscribe(TOPICS.BALANCE_CHANGED, () => {
      fetchPositions();
    });
    const unsubEngine = WebSocketManager.subscribe(TOPICS.ENGINE_STATUS_CHANGED, () => {
      fetchPositions();
    });

    return () => {
      unsubBalance();
      unsubEngine();
    };
  }, []);

  const handleClosePosition = async (engineId: string, symbol: string, amount: number, side: string) => {
    showConfirm(
      `Are you sure you want to manually LIQUIDATE and close this ${side} position of ${amount} ${symbol}?`,
      async () => {
        setClosing(engineId);
        try {
          const oppositeSide = side === "BUY" ? "SELL" : "BUY";
          await ApiClient.post("/execution/trade", {
            symbol,
            side: oppositeSide,
            type: "MARKET",
            amount,
            engine: engineId
          });
          showAlert("Position liquidated successfully.");
          await fetchPositions();
        } catch (err: any) {
          showAlert(`Liquidation failed: ${err.message}`);
        } finally {
          setClosing(null);
        }
      },
      undefined,
      "MANUAL LIQUIDATION"
    );
  };

  const handleTriggerKillSwitch = async () => {
    showConfirm(
      "EMERGENCY ACTION: Initiate global trade halt and immediate liquidation of ALL open positions? This action is irreversible.",
      async () => {
        try {
          await ApiClient.post("/engine/kill");
          showAlert("Emergency Kill Switch Activated. Initiating liquidations.");
          await fetchPositions();
        } catch (err) {
          showAlert("Kill switch failed to propagate.");
        }
      },
      undefined,
      "GLOBAL KILL SWITCH"
    );
  };

  if (loading) {
    return <PageLoader message="LOADING ACTIVE SPOT ALLOCATIONS..." subMessage="Streaming Dynamic Order Book Depth" />;
  }

  const totalPnL = positions.reduce((acc, pos) => acc + pos.pnl, 0);

  return (
    <div id="live-positions-container" className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6">
      {/* Page Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b border-[#FA1F4E]/20 pb-4 shrink-0">
        <div>
          <h2 className="text-2xl font-aquire text-[#FA1F4E] tracking-tighter drop-shadow-[0_0_15px_rgba(250,31,78,0.2)] uppercase">LIVE POSITIONS TERMINAL</h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            Real-time monitoring and manual liquidation controls of active physical-backed spot trading positions.
          </p>
        </div>
        <button
          onClick={handleTriggerKillSwitch}
          className="flex items-center gap-2 px-4 py-2 border border-[#ff1744] bg-[rgba(255,23,68,0.1)] hover:bg-[#ff1744] text-[#ff1744] hover:text-white rounded text-xs font-mono font-extrabold transition-all uppercase"
        >
          <ShieldAlert className="w-4 h-4" />
          EMERGENCY SYSTEM HALT
        </button>
      </div>

      {/* Aggregate Position Stats Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded flex justify-between items-center">
          <div className="space-y-1">
            <span className="text-[10px] text-[#FA1F4E] uppercase font-bold tracking-wider block">ACTIVE POSITIONS COUNT</span>
            <div className="text-xl font-bold font-mono text-white">{positions.length} ACTIVE</div>
          </div>
          <Activity className="w-5 h-5 text-[#FA1F4E]" />
        </div>

        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded flex justify-between items-center">
          <div className="space-y-1">
            <span className="text-[10px] text-[#FA1F4E] uppercase font-bold tracking-wider block">AGGREGATE UNREALIZED P&L</span>
            <div className="text-xl font-bold font-mono text-white">
              {totalPnL >= 0 ? "+" : ""}${ (totalPnL ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          {totalPnL >= 0 ? <TrendingUp className="w-5 h-5 text-white" /> : <TrendingDown className="w-5 h-5 text-[#FA1F4E]" />}
        </div>

        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded flex justify-between items-center">
          <div className="space-y-1">
            <span className="text-[10px] text-[#FA1F4E] uppercase font-bold tracking-wider block">TOTAL RISK MARGIN LOCKED</span>
            <div className="text-xl font-bold font-mono text-white">
              ${positions.reduce((acc, pos) => acc + pos.locked_margin, 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </div>
          </div>
          <ShieldAlert className="w-5 h-5 text-[#FA1F4E]" />
        </div>
      </div>

      {/* Grid List of Positions */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] rounded overflow-hidden">
        <div className="bg-[#090a0d] px-4 py-3 border-b border-[#11131c] flex items-center justify-between">
          <span className="text-[10px] text-[#FA1F4E] font-mono font-bold tracking-wider uppercase">
            ACTIVE REAL-TIME POSITIONS LEDGER
          </span>
          <button onClick={fetchPositions} className="text-[#8a8d9a] hover:text-white transition-colors">
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#11131c] text-[#8a8d9a] uppercase font-mono bg-[#06070a]">
                <th className="py-3 px-4 font-semibold">CORE ID</th>
                <th className="py-3 px-4 font-semibold">ASSET PAIR</th>
                <th className="py-3 px-4 font-semibold">POSITION SIZE</th>
                <th className="py-3 px-4 font-semibold">ENTRY PRICE</th>
                <th className="py-3 px-4 font-semibold">MARK PRICE</th>
                <th className="py-3 px-4 font-semibold">UNREALIZED P&L</th>
                <th className="py-3 px-4 font-semibold">MARGIN TYPE</th>
                <th className="py-3 px-4 font-semibold text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1a1d26]">
              {positions.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-[#8a8d9a] font-mono">
                    NO ACTIVE SPOT POSITIONS RECORDED IN HIGH-FREQUENCY MEMORY
                  </td>
                </tr>
              ) : (
                positions.map((pos, idx) => (
                  <tr key={idx} className="hover:bg-[#12161f] font-mono">
                    <td className="py-3 px-4 text-white font-extrabold">{pos.engineId.toUpperCase()}</td>
                    <td className="py-3 px-4 text-white">{pos.symbol}</td>
                    <td className="py-3 px-4 text-white font-bold">{pos.amount}</td>
                    <td className="py-3 px-4 text-white">${(pos.entry_price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                    <td className="py-3 px-4 text-white">${(pos.current_price ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                    <td className="py-3 px-4 font-bold text-white">
                      {pos.pnl >= 0 ? "+" : ""}${(pos.pnl ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })} ({(pos.roi ?? 0).toFixed(2)}%)
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 border border-[#1a1d26] text-white bg-[#06070a] rounded text-[9px] font-bold">
                        ISOLATED SPOT
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleClosePosition(pos.engineId, pos.symbol, pos.amount, pos.pnl >= 0 ? "BUY" : "SELL")}
                        disabled={closing === pos.engineId}
                        className="px-2 py-1 bg-[rgba(255,23,68,0.15)] border border-[#ff1744] hover:bg-[#ff1744] text-[#ff1744] hover:text-white rounded text-[10px] font-bold uppercase transition-all"
                      >
                        {closing === pos.engineId ? "HALTING..." : "LIQUIDATE"}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
export default LivePositions;
