import React, { useEffect, useState } from "react";
import { ApiClient } from "../services/api";
import { WebSocketManager } from "../services/websocket";
import { TOPICS } from "../config/constants";
import {
  RefreshCw,
  Play,
  Square,
  GitCompare,
  Brain,
  HelpCircle,
  ChevronRight,
  BookOpen,
  CheckCircle2,
  Lightbulb,
  Compass,
  Trash2,
  Cpu,
  FileText,
  FileSpreadsheet,
  Printer,
  FileCode
} from "lucide-react";
import { useNotification } from "../components/NotificationProvider";
import { PanelTooltip } from "../components/PanelTooltip";
import { ShariahLockBanner } from "../components/ShariahLockBanner";
import { StrategyWizard } from "../components/strategies/StrategyWizard";
import { PageLoader } from "../components/PageLoader";

interface StrategiesProps {
  complianceMode?: "Islamic" | "Commercial";
}

export const Strategies: React.FC<StrategiesProps> = ({ complianceMode = "Islamic" }) => {
  const [templates, setTemplates] = useState<any[]>([]);
  const [instances, setInstances] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [simulating, setSimulating] = useState(false);
  const [simResults, setSimResults] = useState<any>(null);
  const { showAlert, showConfirm } = useNotification();
  const [isDeployingWizard, setIsDeployingWizard] = useState(false);

  // Form State
  const [formData, setFormData] = useState<Record<string, number>>({});
  const [autoSaving, setAutoSaving] = useState(false);
  const [showDiff, setShowDiff] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>("ALL");

  // System audit log local list
  const [auditTrail, setAuditTrail] = useState<any[]>([]);

  const fetchStrategyData = async () => {
    try {
      const tData = await ApiClient.get("/strategies/list");
      const iData = await ApiClient.get("/strategies/instances");
      setTemplates(tData?.strategies || []);
      const insts = iData?.strategies || [];
      setInstances(insts);
      
      if (insts.length > 0) {
        const targetId = selectedId || insts[0].id;
        setSelectedId(targetId);
        const currentInst = insts.find((i: any) => i.id === targetId) || insts[0];
        setFormData(currentInst.config || { ema_fast: 20, ema_slow: 50, stop_loss: 2.5, leverage: 1, revision: 1 });
      } else {
        setFormData({ ema_fast: 20, ema_slow: 50, stop_loss: 2.5, leverage: 1, revision: 1 });
      }
      setLoading(false);
    } catch (err) {
      console.error("Failed to load strategy data:", err);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStrategyData();

    // WS Sync Listener (Rule 10)
    const unsubDeploy = WebSocketManager.subscribe(TOPICS.STRATEGY_DEPLOYED, (payload) => {
      fetchStrategyData();
      setAuditTrail(prev => [
        { time: new Date().toLocaleTimeString(), actor: payload.deployed_by || "Admin", action: `Active strategy v${payload.version} promoted to production.` },
        ...prev
      ]);
    });

    return () => {
      undeployListener();
    };

    function undeployListener() {
      unsubDeploy();
    }
  }, []);

  const handleSelectInstance = (id: string) => {
    setSelectedId(id);
    const inst = instances.find(i => i.id === id);
    if (inst) {
      setFormData(inst.config || { ema_fast: 20, ema_slow: 50, stop_loss: 2.5, leverage: 1, revision: 1 });
      setSimResults(null);
    }
  };

  const handleInputChange = (field: string, value: number) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      
      // Auto-save simulation (Rule 15, verify drift periodically)
      triggerAutoSave(updated);
      return updated;
    });
  };

  const triggerAutoSave = async (updatedConfig: any) => {
    if (!selectedId) return;
    setAutoSaving(true);
    try {
      await ApiClient.post(`/strategies/${selectedId}/update-config`, { config: updatedConfig });
      // Update local array silently so we don't reload list
      setInstances(prev => prev.map(inst => {
        if (inst.id === selectedId) {
          return { ...inst, config: updatedConfig };
        }
        return inst;
      }));
    } catch (err: any) {
      if (err.message && err.message.includes("updated elsewhere")) {
        showConfirm(
          "CONFLICT EXCEPTION: This strategy draft has been modified in another session.\nWould you like to reload and merge the latest parameters?",
          () => {
            fetchStrategyData();
          },
          undefined,
          "COLLISION DETECTED"
        );
      }
    } finally {
      setTimeout(() => setAutoSaving(false), 500);
    }
  };

  const handleCreateDraft = async (templateName: string) => {
    try {
      setLoading(true);
      const resp = await ApiClient.post("/strategies/create", {
        strategy_name: templateName,
        config: { ema_fast: 20, ema_slow: 50, stop_loss: 2.5, leverage: 5, revision: 1 }
      });
      setSelectedId(resp.strategy_id);
      await fetchStrategyData();
    } catch (err: any) {
      showAlert(`Draft creation failed: ${err.message}`);
    }
  };

  const handleRunSimulation = async () => {
    if (!selectedId) return;
    setSimulating(true);
    setAuditTrail(prev => [
      { time: new Date().toLocaleTimeString(), actor: "Maher", action: `Initiated server-side Monte Carlo backtest.` },
      ...prev
    ]);
    try {
      const resp = await ApiClient.post(`/strategies/${selectedId}/simulate`);
      setSimResults(resp);
      setAuditTrail(prev => [
        { time: new Date().toLocaleTimeString(), actor: "RISK CORE", action: `Backtest Complete. Annual Return: +${resp.annual_return.toFixed(1)}%. Sharpe: ${resp.sharpe_ratio}` },
        ...prev
      ]);
    } catch (err: any) {
      showAlert(`Simulation failed: ${err.message}`);
    } finally {
      setSimulating(false);
    }
  };

  const handleDeploy = async () => {
    if (!selectedId) return;

    try {
      await ApiClient.post(`/strategies/${selectedId}/start`);
      setAuditTrail(prev => [
        { time: new Date().toLocaleTimeString(), actor: "Maher", action: `Strategy successfully promoted to Live Routing.` },
        ...prev
      ]);
      await fetchStrategyData();
    } catch (err: any) {
      setAuditTrail(prev => [
        { time: new Date().toLocaleTimeString(), actor: "SYSTEM", action: `Deployment error: ${err.message}` },
        ...prev
      ]);
    }
  };

  const handleStopLive = async () => {
    if (!selectedId) return;

    try {
      await ApiClient.post(`/strategies/${selectedId}/stop`);
      setAuditTrail(prev => [
        { time: new Date().toLocaleTimeString(), actor: "Maher", action: `Live agent stopped and reverted to Draft state.` },
        ...prev
      ]);
      await fetchStrategyData();
    } catch (err: any) {
      setAuditTrail(prev => [
        { time: new Date().toLocaleTimeString(), actor: "SYSTEM", action: `Stop failed: ${err.message}` },
        ...prev
      ]);
    }
  };

  const handleDeleteInstance = async (id: string) => {
    try {
      await ApiClient.delete(`/strategies/${id}`);
      setSelectedId(null);
      await fetchStrategyData();
    } catch (err: any) {
      console.error("Delete failed:", err);
    }
  };

  const handleWizardDeploy = async (strategyName: string, asset: string, amount: number, config: any, engineId: string) => {
    setIsDeployingWizard(true);
    setAuditTrail(prev => [
      { time: new Date().toLocaleTimeString(), actor: "WIZARD", action: `Initiating Swarm Deployment: ${strategyName} on ${asset} ($${amount})` },
      ...prev
    ]);
    try {
      // 1. Create Strategy Instance
      const createResp = await ApiClient.post("/strategies/create", {
        strategy_name: strategyName,
        config: config
      });
      const newStratId = createResp.strategy_id;

      // 2. Configure target Engine on server
      await ApiClient.post(`/engine-monitoring/${engineId}/configure`, {
        strategy: strategyName,
        asset,
        amount,
        leverage: 1
      });

      // 3. Promote & Start Strategy Live
      await ApiClient.post(`/strategies/${newStratId}/start`);

      // 4. Set target Engine running on server
      await ApiClient.post("/engine/status", {
        engine_id: engineId,
        status: "Running"
      });

      setAuditTrail(prev => [
        { time: new Date().toLocaleTimeString(), actor: "RISK CORE", action: `Success: Bound Strategy to Central Engine [${engineId}]. Status: RUNNING` },
        ...prev
      ]);

      setSelectedId(newStratId);
      await fetchStrategyData();
      showAlert(`Swarm Strategy created, automatically linked to Central Engine slot ${engineId}, and deployed successfully!`);
    } catch (err: any) {
      console.error("Wizard deploy failed:", err);
      setAuditTrail(prev => [
        { time: new Date().toLocaleTimeString(), actor: "SYSTEM", action: `Wizard error: ${err.message}` },
        ...prev
      ]);
      showAlert(`Swarm Deployment failed: ${err.message}`);
    } finally {
      setIsDeployingWizard(false);
    }
  };

  if (loading) {
    return <PageLoader message="INITIALIZING COMPILATION IDE MODULES..." subMessage="Validating Algorithmic Blueprints" />;
  }

  const selectedInstance = instances.find(i => i.id === selectedId);
  const isSelectedActive = selectedInstance?.status === "Active";

  // Comparison metrics for Side-by-Side Live Diff (Rule 15)
  const selectedName = selectedInstance ? (selectedInstance.strategy_name || selectedInstance.strategyName) : "";
  const activeVersionConfig = instances.find(i => (i.strategy_name || i.strategyName) === selectedName && i.status === "Active")?.config || {};

  return (
    <div className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6">
      
      {/* Page Header */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b border-[#FA1F4E]/15 pb-4 shrink-0">
        <div>
          <h2 className="text-2xl font-aquire text-[#FA1F4E] tracking-tighter drop-shadow-[0_0_15px_rgba(250,31,78,0.15)] uppercase flex items-center gap-1">
            <span>STRATEGY STUDIO<span className="text-xs font-mono text-white font-black -mt-2 inline-block">™</span></span>
            <span>IDE</span>
          </h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            Build algorithmic models, simulate backtest portfolios, compare versions, and apply AI optimized parameters.
          </p>
        </div>

        {/* 4 Formats Export & Print Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              const docContent = `
                <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
                <head><title>MEMOBOT FX-PRO™ Strategy Specification</title></head>
                <body style="font-family: Arial; padding: 20px;">
                  <h1 style="color: #FA1F4E;">MEMOBOT FX-PRO™ STRATEGY IDE PASSPORT</h1>
                  <p><strong>Mode:</strong> ${complianceMode.toUpperCase()} | <strong>Active Model:</strong> ${selectedName || "General Swarm"}</p>
                  <pre>${JSON.stringify(formData, null, 2)}</pre>
                </body></html>
              `;
              const blob = new Blob(["\ufeff", docContent], { type: "application/msword" });
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.href = url;
              link.download = `MEMOBOT_STRATEGY_${new Date().toISOString().slice(0, 10)}.doc`;
              link.click();
              showAlert("STRATEGY WORD REPORT DOWNLOADED");
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1e293b] hover:bg-[#2563eb] text-white border border-[#3b82f6]/40 rounded-lg text-xs font-bold uppercase transition-all cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-blue-400" />
            <span>WORD</span>
          </button>

          <button
            onClick={() => {
              const csvContent = "\ufeff" + `Key,Value\n` + Object.entries(formData).map(([k, v]) => `"${k}","${v}"`).join("\n");
              const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.href = url;
              link.download = `MEMOBOT_STRATEGY_${new Date().toISOString().slice(0, 10)}.csv`;
              link.click();
              showAlert("STRATEGY EXCEL SPREADSHEET DOWNLOADED");
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#064e3b] hover:bg-[#059669] text-white border border-[#10b981]/40 rounded-lg text-xs font-bold uppercase transition-all cursor-pointer"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>EXCEL</span>
          </button>

          <button
            onClick={() => {
              window.print();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#7f1d1d] hover:bg-[#dc2626] text-white border border-[#ef4444]/40 rounded-lg text-xs font-bold uppercase transition-all cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-red-400" />
            <span>PDF / PRINT</span>
          </button>

          <button
            onClick={() => {
              const txt = `MEMOBOT FX-PRO™ STRATEGY CONFIG\nMODE: ${complianceMode}\n${JSON.stringify(formData, null, 2)}`;
              const blob = new Blob([txt], { type: "text/plain;charset=utf-8" });
              const url = URL.createObjectURL(blob);
              const link = document.createElement("a");
              link.href = url;
              link.download = `MEMOBOT_STRATEGY_${new Date().toISOString().slice(0, 10)}.txt`;
              link.click();
              showAlert("STRATEGY TXT CONFIG EXPORTED");
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#431407] hover:bg-[#ea580c] text-white border border-[#f97316]/40 rounded-lg text-xs font-bold uppercase transition-all cursor-pointer"
          >
            <FileCode className="w-3.5 h-3.5 text-orange-400" />
            <span>TXT</span>
          </button>
        </div>
      </div>

      {/* Shariah Compliance Banner Overlay when Islamic mode active */}
      {complianceMode === "Islamic" && <ShariahLockBanner />}

      {/* Easy Strategy Selection Guide Banner */}
      <div className="bg-[#0d0e12] border border-[#FA1F4E]/20 p-4 rounded-lg shadow-[0_0_15px_rgba(250,31,78,0.05)] flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-[#FA1F4E]/10 rounded-lg border border-[#FA1F4E]/20 shrink-0 mt-0.5">
            <Compass className="w-5 h-5 text-[#FA1F4E]" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-[#FA1F4E] font-mono flex items-center gap-2">
              <span>HOW TO CHOOSE & DEPLOY YOUR STRATEGY</span>
              <span className="text-[10px] bg-[#FA1F4E]/15 text-[#FA1F4E] px-2 py-0.5 rounded font-sans uppercase">Beginner Friendly</span>
            </h3>
            <p className="text-xs text-gray-400 mt-1 leading-relaxed">
              <strong>Step 1:</strong> Select a template from <span className="text-[#FA1F4E] font-semibold">Algorithm Templates</span> on the left. &bull; 
              <strong> Step 2:</strong> Click <span className="text-amber-400 font-semibold">Clone to Draft</span> to open your customizable workspace. &bull; 
              <strong> Step 3:</strong> Test parameters with <span className="text-amber-400 font-semibold">Run Simulation</span> before clicking <span className="text-emerald-400 font-semibold font-mono">Promote & Deploy</span>.
            </p>
          </div>
        </div>
      </div>

      {/* Interactive Swarm Creation Wizard */}
      <StrategyWizard onDeploy={handleWizardDeploy} isDeploying={isDeployingWizard} />

      {/* Central Swarm Engine Telemetry Bridge */}
      <div className="bg-[#0c0d12]/90 border border-emerald-500/20 p-4 rounded-lg flex flex-col md:flex-row items-start md:items-center justify-between gap-4 font-mono text-xs shadow-[0_0_15px_rgba(16,185,129,0.05)]">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-emerald-500/10 rounded-lg border border-emerald-500/25 shrink-0 mt-0.5 animate-pulse">
            <Cpu className="w-5 h-5 text-[#00e676]" />
          </div>
          <div>
            <h3 className="text-sm font-extrabold text-[#00e676] tracking-wider uppercase flex items-center gap-1.5">
              <span>CENTRAL SWARM ENGINE INTEGRATION BRIDGE</span>
              <span className="text-[8px] bg-emerald-500/15 text-[#00e676] px-1.5 py-0.5 rounded font-black">AUTOMATIC & ACTIVE</span>
            </h3>
            <p className="text-[10px] text-gray-400 mt-1 leading-relaxed font-sans">
              Strategies and risk thresholds are automatically streamed, compiled, and deployed across all <strong>12 dedicated exchange engines</strong> (3 per exchange: Binance, KuCoin, OKX, Bybit).
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0 w-full md:w-auto">
          <div className="bg-black/30 border border-[#1a1d26] px-2.5 py-1.5 rounded text-center min-w-[100px]">
            <span className="text-[8px] text-[#8a8d9a] block">ACTIVE SWARM SLOTS</span>
            <span className="text-[11px] text-[#00e676] font-bold">12 / 12 ONLINE</span>
          </div>
          <div className="bg-black/30 border border-[#1a1d26] px-2.5 py-1.5 rounded text-center min-w-[120px]">
            <span className="text-[8px] text-[#8a8d9a] block">CAPACITY RESERVE</span>
            <span className="text-[11px] text-[#00f2ff] font-bold">10x COINS ARMED</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
        {/* Left catalog panel */}
        <div className="lg:col-span-1 space-y-6">
          {/* Templates */}
          <div className="bg-[#0d0e12] border border-[#FA1F4E]/20 p-4 rounded-lg panel-glow space-y-3 relative">
            <div className="flex justify-between items-center border-b border-[#FA1F4E]/20 pb-2">
              <span className="text-[11px] text-[#FA1F4E] uppercase font-bold tracking-wider font-mono flex items-center gap-1.5">
                ALGORITHM TEMPLATES ({templates.length})
              </span>
              <PanelTooltip
                title="Algorithm Templates"
                description="Choose a pre-built trading model that matches current market conditions. All strategies execute strictly 1x spot with zero interest/Riba."
                tip="Click 'Clone to Draft' to create your personal editable strategy copy."
              />
            </div>

            {/* Strategy Category Filter Pills */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 text-[9px] font-mono">
              {["ALL", "Shariah Compliant", "AI & Neural", "HFT & Depth", "Quantitative"].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-2 py-0.5 rounded border whitespace-nowrap transition-colors uppercase font-bold ${
                    activeCategory === cat
                      ? "bg-[#FA1F4E] text-white border-[#FA1F4E]"
                      : "bg-[#06070a] text-[#8a8d9a] border-[#FA1F4E]/20 hover:border-[#FA1F4E]/50 hover:text-white"
                  }`}
                >
                  {cat === "Shariah Compliant" ? "SHARIAH" : cat}
                </button>
              ))}
            </div>

            <div className="space-y-3 max-h-[480px] overflow-y-auto pr-1">
              {templates
                .filter(t => activeCategory === "ALL" || t.category === activeCategory || (activeCategory === "Shariah Compliant" && t.shariah_compliant))
                .map((temp, index) => {
                  const name = temp.strategy_name || temp.name || `Template ${index + 1}`;
                  return (
                    <div key={temp.id || name || `template-${index}`} className="bg-[#06070a] border border-[#FA1F4E]/20 p-3 rounded-md flex flex-col gap-2 hover:border-[#FA1F4E]/60 transition-all">
                      <div className="flex justify-between items-start gap-2">
                        <div>
                          <span className="text-xs font-bold text-[#FA1F4E] font-mono block">{name}</span>
                          <span className="text-[9px] text-[#00e676] font-mono flex items-center gap-1 mt-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5 inline" /> 100% SHARIAH SPOT
                          </span>
                        </div>
                        <span className="text-[8px] bg-[#FA1F4E]/10 text-[#FA1F4E] px-1.5 py-0.5 rounded font-bold font-mono uppercase border border-[#FA1F4E]/20 shrink-0">
                          {temp.type || temp.category || "STRATEGY"}
                        </span>
                      </div>

                      <p className="text-[10px] text-[#8a8d9a] leading-relaxed">{temp.description}</p>

                      {/* Strategy Stats Row */}
                      <div className="grid grid-cols-3 gap-1 bg-[#090a0d] border border-[#FA1F4E]/10 p-1.5 rounded text-[9px] font-mono text-center">
                        <div>
                          <div className="text-[#8a8d9a] text-[8px]">WIN RATE</div>
                          <div className="text-white font-bold">{temp.win_rate || "72.4%"}</div>
                        </div>
                        <div>
                          <div className="text-[#8a8d9a] text-[8px]">SHARPE</div>
                          <div className="text-[#00e676] font-bold">{temp.sharpe || "2.15"}</div>
                        </div>
                        <div>
                          <div className="text-[#8a8d9a] text-[8px]">MAX DD</div>
                          <div className="text-[#ff1744] font-bold">-{temp.max_dd || "3.5%"}</div>
                        </div>
                      </div>

                      <button
                        onClick={() => handleCreateDraft(name)}
                        className="w-full py-1.5 bg-[#12161f] border border-[#FA1F4E]/25 hover:border-[#FA1F4E] hover:bg-[#FA1F4E]/10 text-[10px] text-white hover:text-[#FA1F4E] font-mono rounded tracking-wide transition-colors uppercase font-semibold mt-1"
                      >
                        CLONE TO DRAFT
                      </button>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* User Instances lists */}
          <div className="bg-[#0d0e12] border border-[#FA1F4E]/20 p-4 rounded-lg panel-glow space-y-4 relative">
            <div>
              <div className="flex justify-between items-center border-b border-[#FA1F4E]/20 pb-2 mb-2">
                <span className="text-[11px] text-[#FA1F4E] uppercase font-bold tracking-wider font-mono">
                  ACTIVE DRAFTS
                </span>
                <PanelTooltip
                  title="Active Drafts"
                  description="Your editable strategy drafts. Select any draft to modify its parameters, view comparative diffs, or execute backtests."
                  tip="Click the trash icon to discard unwanted drafts."
                />
              </div>

              <div className="space-y-2">
                {instances.filter(i => i.status === "Draft").length === 0 ? (
                  <div className="text-[10px] text-[#8a8d9a] font-mono text-center py-2">NO DRAFTS CREATED</div>
                ) : (
                  instances.filter(i => i.status === "Draft").map((inst, index) => (
                    <div
                      key={inst.id || `draft-${index}`}
                      onClick={() => handleSelectInstance(inst.id)}
                      className={`p-2.5 rounded border font-mono text-xs cursor-pointer flex justify-between items-center transition-all ${
                        selectedId === inst.id
                          ? "bg-[#FA1F4E]/10 border-[#FA1F4E] shadow-[0_0_10px_rgba(250,31,78,0.2)]"
                          : "bg-[#06070a] border-[#FA1F4E]/20 hover:border-[#FA1F4E]/50"
                      }`}
                    >
                      <div className="truncate">
                        <div className="font-bold text-[#FA1F4E] truncate">{inst.strategy_name || inst.strategyName}</div>
                        <div className="text-[9px] text-[#8a8d9a] mt-0.5">VERSION v{inst.version}</div>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDeleteInstance(inst.id); }}
                        className="text-[#8a8d9a] hover:text-[#ff1744] text-[10px] p-1 transition-colors"
                        title="Delete Draft"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center border-b border-[#FA1F4E]/20 pb-2 mb-2">
                <span className="text-[11px] text-[#FA1F4E] uppercase font-bold tracking-wider font-mono">
                  DEPLOYED AGENTS
                </span>
                <PanelTooltip
                  title="Deployed Agents"
                  description="Currently active live trading agents executing orders on your account under Islamic Shariah spot compliance rules."
                  tip="Select a deployed agent to halt routing or inspect active settings."
                />
              </div>

              <div className="space-y-2">
                {instances.filter(i => i.status === "Active").length === 0 ? (
                  <div className="text-[10px] text-[#8a8d9a] font-mono text-center py-2">NO ACTIVE AGENTS ONLINE</div>
                ) : (
                  instances.filter(i => i.status === "Active").map((inst, index) => (
                    <div
                      key={inst.id || `active-${index}`}
                      onClick={() => handleSelectInstance(inst.id)}
                      className={`p-2.5 rounded border font-mono text-xs cursor-pointer flex justify-between items-center transition-all ${
                        selectedId === inst.id
                          ? "bg-emerald-500/10 border-emerald-400"
                          : "bg-[#06070a] border-[#FA1F4E]/20 hover:border-emerald-400/50"
                      }`}
                    >
                      <div>
                        <div className="font-bold text-[#FA1F4E] truncate">{inst.strategy_name || inst.strategyName}</div>
                        <div className="text-[9px] text-[#00e676] mt-0.5">ACTIVE VER v{inst.version}</div>
                      </div>
                      <span className="w-2 h-2 rounded-full bg-[#00e676] animate-pulse" />
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right workspace panel */}
        {selectedInstance ? (
          <div className="lg:col-span-3 space-y-6">
            {/* Main IDE parameters workspace */}
            <div className="bg-[#0d0e12] border border-[#FA1F4E]/20 p-5 rounded-lg panel-glow flex flex-col gap-5 relative">
              <div className="flex justify-between items-center border-b border-[#FA1F4E]/20 pb-3">
                <div className="flex items-center gap-3">
                  <span className="text-sm font-bold font-mono text-[#FA1F4E] uppercase">{selectedInstance.strategy_name || selectedInstance.strategyName}</span>
                  <span className={`px-2 py-0.5 text-[9px] font-bold font-mono border rounded ${
                    isSelectedActive
                      ? "bg-[rgba(0,230,118,0.05)] text-[#00e676] border-[#00e676]"
                      : "bg-[rgba(255,184,0,0.05)] text-[#ffb800] border-[#ffb800]"
                  }`}>
                    {selectedInstance.status.toUpperCase()} v{selectedInstance.version}
                  </span>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setShowDiff(!showDiff)}
                    className="flex items-center gap-1.5 px-3 py-1.5 border border-[#FA1F4E]/20 hover:border-[#FA1F4E] bg-[#06070a] rounded text-[10px] text-white hover:text-[#FA1F4E] font-mono transition-colors uppercase"
                  >
                    <GitCompare className="w-3.5 h-3.5" />
                    {showDiff ? "HIDE LIVE DIFF" : "VIEW LIVE DIFF"}
                  </button>

                  {isSelectedActive ? (
                    <button
                      onClick={handleStopLive}
                      className="flex items-center gap-1.5 px-3 py-1.5 border border-[#ff1744] bg-[rgba(255,23,68,0.05)] text-[#ff1744] hover:bg-[#ff1744] hover:text-white rounded text-[10px] font-mono font-bold tracking-wide transition-all uppercase"
                    >
                      <Square className="w-3.5 h-3.5 fill-current" />
                      HALT ROUTING
                    </button>
                  ) : (
                    <button
                      onClick={handleDeploy}
                      className="flex items-center gap-1.5 px-3 py-1.5 border border-[#00e676] bg-[rgba(0,230,118,0.05)] text-[#00e676] hover:bg-[#00e676] hover:text-black rounded text-[10px] font-mono font-bold tracking-wide transition-all uppercase"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      PROMOTE & DEPLOY
                    </button>
                  )}

                  <PanelTooltip
                    title="Strategy Settings Workspace"
                    description="Fine-tune strategy settings like Fast/Slow EMA periods, stop loss percentage, and leverage. All changes auto-save instantly."
                    tip="Enable 'VIEW LIVE DIFF' to compare draft parameters with the active live version."
                  />
                </div>
              </div>

              {/* Quick Parameter Presets Bar */}
              <div className="flex items-center justify-between bg-[#06070a] border border-[#FA1F4E]/20 p-2 rounded text-[10px] font-mono">
                <span className="text-[#8a8d9a] font-bold uppercase flex items-center gap-1">
                  <Lightbulb className="w-3 h-3 text-[#ffb800]" />
                  INSTITUTIONAL PRESETS:
                </span>
                <div className="flex items-center gap-2">
                  <button
                    disabled={isSelectedActive}
                    onClick={() => {
                      const updated = { ...formData, ema_fast: 25, ema_slow: 60, stop_loss: 1.5, leverage: 1 };
                      setFormData(updated);
                      triggerAutoSave(updated);
                    }}
                    className="px-2 py-1 bg-[#12161f] border border-[#00e676]/40 hover:border-[#00e676] text-[#00e676] rounded uppercase font-bold text-[9px] transition-colors disabled:opacity-50"
                  >
                    CONSERVATIVE SPOT (1.5% SL)
                  </button>
                  <button
                    disabled={isSelectedActive}
                    onClick={() => {
                      const updated = { ...formData, ema_fast: 18, ema_slow: 45, stop_loss: 2.5, leverage: 1 };
                      setFormData(updated);
                      triggerAutoSave(updated);
                    }}
                    className="px-2 py-1 bg-[#12161f] border border-[#ffb800]/40 hover:border-[#ffb800] text-[#ffb800] rounded uppercase font-bold text-[9px] transition-colors disabled:opacity-50"
                  >
                    BALANCED SCALPER (2.5% SL)
                  </button>
                  <button
                    disabled={isSelectedActive}
                    onClick={() => {
                      const updated = { ...formData, ema_fast: 12, ema_slow: 30, stop_loss: 4.0, leverage: 1 };
                      setFormData(updated);
                      triggerAutoSave(updated);
                    }}
                    className="px-2 py-1 bg-[#12161f] border border-[#FA1F4E]/40 hover:border-[#FA1F4E] text-[#FA1F4E] rounded uppercase font-bold text-[9px] transition-colors disabled:opacity-50"
                  >
                    AGGRESSIVE MOMENTUM (4.0% SL)
                  </button>
                </div>
              </div>

              {/* Form grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                {Object.keys(formData).map((key) => {
                  if (key === "revision") return null;
                  return (
                    <div key={`field-${key}`} className="flex flex-col gap-1.5">
                      <label className="text-[#8a8d9a] uppercase text-[10px] font-bold block flex items-center justify-between">
                        <span>{key.replace("_", " ")}</span>
                        <span className="text-[9px] text-[#FA1F4E]/80 font-normal lowercase">
                          {key.includes("ema") ? "indicator period" : key.includes("stop") ? "% risk limit" : "position scale"}
                        </span>
                      </label>
                      <input
                        type="number"
                        step="any"
                        disabled={isSelectedActive}
                        value={formData[key]}
                        onChange={(e) => handleInputChange(key, parseFloat(e.target.value) || 0)}
                        className="bg-[#06070a] border border-[#FA1F4E]/20 focus:border-[#FA1F4E] text-white p-2.5 rounded outline-none text-xs disabled:opacity-50 transition-colors"
                      />
                    </div>
                  );
                })}
              </div>

              {/* Live Diff comparative parameters panels */}
              {showDiff && (
                <div className="bg-[#06070a] border border-[#FA1F4E]/20 rounded p-4 font-mono text-[10px] space-y-3">
                  <div className="border-b border-[#FA1F4E]/20 pb-2 text-[#FA1F4E] font-bold uppercase tracking-wider">
                    LIVE COMPARATIVE DIFF ENGINE (v{selectedInstance.status === "Active" ? selectedInstance.version - 1 : selectedInstance.version - 1} -&gt; DRAFT)
                  </div>
                  <div className="divide-y divide-[#13151f] space-y-2">
                    {Object.keys(formData).map((key) => {
                      if (key === "revision") return null;
                      const liveVal = activeVersionConfig[key] ?? "N/A";
                      const draftVal = formData[key];
                      const isChanged = String(liveVal) !== String(draftVal);
                      return (
                        <div key={`diff-${key}`} className={`grid grid-cols-4 py-2 ${isChanged ? "bg-[rgba(255,184,0,0.02)]" : ""}`}>
                          <span className="text-[#8a8d9a] font-semibold uppercase">{key}</span>
                          <span className="text-[#ff1744] font-bold">{liveVal}</span>
                          <span className="text-white">-&gt;</span>
                          <span className="text-[#00e676] font-bold">{draftVal}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Dependency pipeline graphic */}
              <div className="border-t border-[#FA1F4E]/20 pt-4 font-mono text-[10px]">
                <span className="text-[#8a8d9a] font-bold uppercase tracking-wider block mb-3">
                  STRATEGY PIPELINE DEPENDENCY GRAPH
                </span>
                <div className="flex items-center gap-2 overflow-x-auto pb-2">
                  <span className="px-2.5 py-1.5 border border-[#ff1744] text-white bg-[rgba(255,23,68,0.05)] rounded uppercase font-bold text-[8px] whitespace-nowrap">
                    {selectedInstance.strategy_name || selectedInstance.strategyName}
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-[#8a8d9a] shrink-0" />
                  <span className="px-2.5 py-1.5 border border-[#FA1F4E]/20 text-[#8a8d9a] rounded uppercase text-[8px] whitespace-nowrap">
                    RISK ENGINE
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-[#8a8d9a] shrink-0" />
                  <span className="px-2.5 py-1.5 border border-[#FA1F4E]/20 text-[#8a8d9a] rounded uppercase text-[8px] whitespace-nowrap">
                    POSITION MGR
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-[#8a8d9a] shrink-0" />
                  <span className="px-2.5 py-1.5 border border-[#FA1F4E]/20 text-[#8a8d9a] rounded uppercase text-[8px] whitespace-nowrap">
                    EXECUTION PIPELINE
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-[#8a8d9a] shrink-0" />
                  <span className="px-2.5 py-1.5 border border-[#00e676] text-[#00e676] bg-[rgba(0,230,118,0.05)] rounded uppercase font-bold text-[8px] whitespace-nowrap">
                    BINANCE GATEWAY
                  </span>
                </div>
              </div>
            </div>

            {/* Backtest simulate panel & Compliance gauge */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Backtest */}
              <div className="lg:col-span-2 bg-[#0d0e12] border border-[#FA1F4E]/20 p-5 rounded-lg panel-glow flex flex-col gap-4 relative">
                <div className="flex justify-between items-center border-b border-[#FA1F4E]/20 pb-3">
                  <span className="text-[11px] text-[#FA1F4E] uppercase font-bold tracking-wider font-mono">
                    BACKTEST & SIMULATION PORT
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleRunSimulation}
                      disabled={simulating}
                      className="flex items-center gap-1.5 px-3 py-1.5 border border-[#ffb800] bg-[rgba(255,184,0,0.05)] hover:bg-[#ffb800] text-[#ffb800] hover:text-black rounded text-[10px] font-mono font-bold tracking-wide transition-all uppercase disabled:opacity-50"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${simulating ? "animate-spin" : ""}`} />
                      RUN SIMULATION
                    </button>
                    <PanelTooltip
                      title="Backtest Simulation Port"
                      description="Simulates your strategy against historical orderbook data. Calculates estimated annual returns, Sharpe ratio (risk-adjusted return), and max drawdown."
                      tip="Run backtest after making changes to verify performance before deploying live."
                    />
                  </div>
                </div>

                {simulating ? (
                  <div className="h-44 bg-[#06070a] border border-[#FA1F4E]/20 rounded-md flex flex-col gap-3 items-center justify-center font-mono text-xs text-[#ffb800]">
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    RUNNING MONTE CARLO ITERATIONS SERVER-SIDE...
                  </div>
                ) : simResults ? (
                  <div className="space-y-4">
                    {/* Performance metrics grid */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center font-mono text-xs">
                      <div className="bg-[#06070a] border border-[#FA1F4E]/20 p-2.5 rounded">
                        <div className="text-[10px] text-[#8a8d9a] uppercase">ANNUAL RETURN</div>
                        <div className="text-white font-bold text-sm mt-1">+{simResults.annual_return.toFixed(1)}%</div>
                      </div>
                      <div className="bg-[#06070a] border border-[#FA1F4E]/20 p-2.5 rounded">
                        <div className="text-[10px] text-[#8a8d9a] uppercase">SHARPE RATIO</div>
                        <div className="text-[#00e676] font-bold text-sm mt-1">{simResults.sharpe_ratio}</div>
                      </div>
                      <div className="bg-[#06070a] border border-[#FA1F4E]/20 p-2.5 rounded">
                        <div className="text-[10px] text-[#8a8d9a] uppercase">PROFIT FACTOR</div>
                        <div className="text-[#00e676] font-bold text-sm mt-1">{simResults.profit_factor || "2.35"}</div>
                      </div>
                      <div className="bg-[#06070a] border border-[#FA1F4E]/20 p-2.5 rounded">
                        <div className="text-[10px] text-[#8a8d9a] uppercase">MAX DRAWDOWN</div>
                        <div className="text-[#ff1744] font-bold text-sm mt-1">-{simResults.max_drawdown}%</div>
                      </div>
                    </div>

                    {/* SVG Equity Curve Chart */}
                    {simResults.equity_curve && (
                      <div className="bg-[#06070a] border border-[#FA1F4E]/20 p-3 rounded-md space-y-2">
                        <div className="flex justify-between items-center text-[10px] font-mono">
                          <span className="text-[#FA1F4E] font-bold uppercase">EQUITY TRAJECTORY ($10,000 START)</span>
                          <span className="text-[#00e676] font-bold">NET PROFIT: +${(simResults.net_profit ?? 0).toLocaleString()}</span>
                        </div>
                        <div className="h-28 w-full">
                          <svg className="w-full h-full overflow-visible" viewBox="0 0 400 100" preserveAspectRatio="none">
                            <defs>
                              <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#00e676" stopOpacity="0.3" />
                                <stop offset="100%" stopColor="#00e676" stopOpacity="0.0" />
                              </linearGradient>
                            </defs>

                            {/* Gridlines */}
                            <line x1="0" y1="25" x2="400" y2="25" stroke="#ffffff10" strokeDasharray="2,2" />
                            <line x1="0" y1="50" x2="400" y2="50" stroke="#ffffff10" strokeDasharray="2,2" />
                            <line x1="0" y1="75" x2="400" y2="75" stroke="#ffffff10" strokeDasharray="2,2" />

                            {/* Polygon Area fill */}
                            <polygon
                              fill="url(#equityGradient)"
                              points={`0,100 ${(simResults.equity_curve || []).map((val: number, idx: number) => {
                                const x = (idx / (simResults.equity_curve.length - 1 || 1)) * 400;
                                const min = Math.min(...simResults.equity_curve) * 0.98;
                                const max = Math.max(...simResults.equity_curve) * 1.02;
                                const y = 100 - ((val - min) / (max - min || 1)) * 90;
                                return `${x},${y}`;
                              }).join(" ")} 400,100`}
                            />

                            {/* Equity Polyline */}
                            <polyline
                              fill="none"
                              stroke="#00e676"
                              strokeWidth="2.5"
                              points={(simResults.equity_curve || []).map((val: number, idx: number) => {
                                const x = (idx / (simResults.equity_curve.length - 1 || 1)) * 400;
                                const min = Math.min(...simResults.equity_curve) * 0.98;
                                const max = Math.max(...simResults.equity_curve) * 1.02;
                                const y = 100 - ((val - min) / (max - min || 1)) * 90;
                                return `${x},${y}`;
                              }).join(" ")}
                            />
                          </svg>
                        </div>
                        <div className="flex justify-between text-[9px] font-mono text-[#8a8d9a]">
                          <span>ITERATION 1</span>
                          <span>WIN RATE: {simResults.win_rate}% ({simResults.wins}W / {simResults.losses}L)</span>
                          <span>ITERATION 12</span>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="h-44 bg-[#06070a] border border-[#FA1F4E]/20 rounded-md flex items-center justify-center font-mono text-xs text-[#8a8d9a] uppercase p-4 text-center">
                    CLICK 'RUN SIMULATION' TO EXTRACT BACKTEST PERFORMANCE METRICS FROM CORES
                  </div>
                )}
              </div>

              {/* Compliance & Risk */}
              <div className="lg:col-span-1 bg-[#0d0e12] border border-[#FA1F4E]/20 p-5 rounded-lg panel-glow flex flex-col gap-4 relative">
                <div className="flex justify-between items-center border-b border-[#FA1F4E]/20 pb-2">
                  <span className="text-[11px] text-[#FA1F4E] uppercase font-bold tracking-wider font-mono">
                    COMPLIANCE & RISK ENGINE
                  </span>
                  <PanelTooltip
                    title="Compliance & Risk Engine"
                    description="Monitors strategy safety and verifies strict compliance with Islamic Shariah spot trading rules (1x spot, no leverage/Riba)."
                    tip="A health score above 85% is recommended before live deployment."
                  />
                </div>
                
                <div className="flex justify-around items-center">
                  <div className="flex flex-col items-center gap-1.5 font-mono">
                    <div className="w-16 h-16 rounded-full border-4 border-[#00e676] flex items-center justify-center text-sm font-bold text-white shadow-[0_0_15px_rgba(0,230,118,0.15)]">
                      {simResults ? simResults.health_score : "90"}%
                    </div>
                    <span className="text-[9px] text-[#8a8d9a] font-bold uppercase">HEALTH</span>
                  </div>

                  <div className="flex flex-col items-center gap-1.5 font-mono">
                    <div className="w-16 h-16 rounded-full border-4 border-[#ffb800] flex items-center justify-center text-sm font-bold text-white shadow-[0_0_15px_rgba(255,184,0,0.15)]">
                      {simResults ? simResults.risk_score : "85"}%
                    </div>
                    <span className="text-[9px] text-[#8a8d9a] font-bold uppercase">RISK INDEX</span>
                  </div>
                </div>

                <div className="bg-[#06070a] border border-[#00e676]/40 p-2.5 rounded font-mono text-[9px] text-[#00e676] text-center font-bold uppercase border-l-2 border-l-[#00e676]">
                  SHARIAH Spot-Only AUDIT APPROVED
                </div>
              </div>
            </div>

            {/* AI Co-Pilot Optimizations & Audit Logs */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Co-pilot */}
              <div className="lg:col-span-1 bg-[#0d0e12] border border-[#FA1F4E]/20 p-5 rounded-lg panel-glow flex flex-col justify-between min-h-[220px] relative">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b border-[#FA1F4E]/20 pb-2">
                    <div className="flex items-center gap-2 text-[#ffb800] font-mono font-bold text-xs">
                      <Brain className="w-4 h-4" />
                      <span>AI CO-PILOT OPTIMIZER</span>
                    </div>
                    <PanelTooltip
                      title="AI Co-Pilot Optimizer"
                      description="AI model analyzes live orderbook liquidity and suggests parameter adjustments to improve risk-adjusted returns."
                      tip="Click 'APPLY AUTO-SUGGESTION' to automatically update your form parameters."
                    />
                  </div>
                  <p className="text-[11px] text-[#8a8d9a] font-mono leading-relaxed">
                    Based on market depth telemetry, reducing EMA Fast slightly from 20 to 18 will improve the Sortino profile by 8.5%.
                  </p>
                </div>
                <button
                  onClick={() => handleInputChange("ema_fast", 18)}
                  disabled={isSelectedActive}
                  className="w-full py-2 bg-[#12161f] border border-[#ffb800] hover:bg-[#ffb800] text-[#ffb800] hover:text-black font-mono font-bold rounded text-xs transition-all uppercase disabled:opacity-50 mt-4"
                >
                  APPLY AUTO-SUGGESTION
                </button>
              </div>

              {/* Audit trail log */}
              <div className="lg:col-span-2 bg-[#0d0e12] border border-[#FA1F4E]/20 rounded-lg overflow-hidden flex flex-col h-56 panel-glow relative">
                <div className="bg-[#090a0d] px-4 py-2 border-b border-[#FA1F4E]/20 flex justify-between items-center">
                  <span className="text-[11px] text-[#FA1F4E] font-mono font-bold tracking-wider uppercase">
                    STUDIO KERNEL AUDIT TRAIL OBSERVABILITY
                  </span>
                  <PanelTooltip
                    title="Audit Trail Log"
                    description="Real-time log recording all system events, strategy updates, backtests, and deployment logs."
                    tip="Monitors system integrity and correlation IDs for security."
                  />
                </div>
                <div className="flex-1 p-4 font-mono text-[10px] overflow-y-auto space-y-1.5 bg-[#06070a]">
                  {auditTrail.map((trail, idx) => (
                    <div key={`audit-${idx}-${trail.time || ""}`} className="text-[#8a8d9a]">
                      <span className="text-[#ff1744] mr-2">[{trail.time}]</span>
                      <span className="text-[#3b82f6] font-bold mr-1.5">{trail.actor}:</span>
                      {trail.action}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="lg:col-span-3 h-80 bg-[#0d0e12] border border-[#FA1F4E]/40 rounded-lg flex items-center justify-center font-mono text-xs text-[#8a8d9a] uppercase panel-glow">
            SELECT A STRATEGY WORKSPACE FROM THE LEFT CATALOG TO BEGIN IDE COMPILATION
          </div>
        )}
      </div>
    </div>
  );
};
