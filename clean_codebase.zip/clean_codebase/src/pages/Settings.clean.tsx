import React, { useState } from "react";
import { Settings as SettingsIcon, Cpu, Palette, CreditCard, ShieldAlert, Bell, Globe } from "lucide-react";
import { MemoBotIcon } from "../components/MemoBotIcon";
import { useNotification } from "../components/NotificationProvider";
import { AboutMemoBotSettings } from "../components/settings/AboutMemoBotSettings";
import { GeneralSettings } from "../components/settings/GeneralSettings";
import { ThemeStudioSettings } from "../components/settings/ThemeStudioSettings";
import { NotificationsSettings } from "../components/settings/NotificationsSettings";
import { SubscriptionFeesSettings } from "../components/settings/SubscriptionFeesSettings";
import { AdminHubSettings } from "../components/settings/AdminHubSettings";
import { TranslationStudioSettings } from "../components/settings/TranslationStudioSettings";
import { SocialManager } from "./SocialManager";
import { useTheme } from "../components/ThemeProvider";
import { useLanguage } from "../components/LanguageProvider";
import { Languages } from "lucide-react";

type SettingsTab = "about" | "general" | "theme" | "translations" | "notifications" | "subscription" | "admin" | "social";

interface SettingsProps {
  initialSubTab?: string;
}

export const Settings: React.FC<SettingsProps> = ({ initialSubTab }) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<SettingsTab>(() => {
    if (initialSubTab === "about") return "about";
    if (initialSubTab === "subscription" || initialSubTab === "billing") return "subscription";
    if (initialSubTab === "admin") return "admin";
    if (initialSubTab === "social") return "social";
    if (initialSubTab === "theme") return "theme";
    if (initialSubTab === "notifications") return "notifications";
    if (initialSubTab === "general") return "general";
    return "about";
  });

  const { showAlert } = useNotification();
  let accentColor = "#FA1F4E";
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
  } catch (e) {}

  const navItems = [
    { id: "about" as SettingsTab, label: t("ABOUT MEMOBOT"), icon: MemoBotIcon },
    { id: "general" as SettingsTab, label: t("GENERAL"), icon: Cpu },
    { id: "theme" as SettingsTab, label: t("THEME STUDIO"), icon: Palette },
    { id: "translations" as SettingsTab, label: t("TRANSLATION STUDIO"), icon: Languages },
    { id: "notifications" as SettingsTab, label: t("NOTIFICATIONS"), icon: Bell },
    { id: "subscription" as SettingsTab, label: t("SUBSCRIPTION & FEES"), icon: CreditCard },
    { id: "social" as SettingsTab, label: t("SOCIAL SUITE"), icon: Globe },
    { id: "admin" as SettingsTab, label: t("ADMIN HUB"), icon: ShieldAlert },
  ];

  return (
    <div id="settings-container" className="flex-1 bg-[#06070a] p-6 overflow-y-auto space-y-6 text-xs text-[#8a8d9a] font-mono">
      {/* Page Header */}
      <div 
        style={{ borderColor: `${accentColor}30` }}
        className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-4 border-b pb-4 shrink-0"
      >
        <div>
          <h2 
            style={{ color: accentColor }}
            className="text-2xl font-aquire tracking-tighter uppercase flex items-center gap-2"
          >
            <SettingsIcon className="w-6 h-6" style={{ color: accentColor }} />
            {t("SYSTEM SETTINGS")}
          </h2>
          <p className="font-sans text-[13px] text-[#8a8d9a] mt-1">
            {t("Platform telemetry configuration, theme studio, alert notifications, institutional billing, and Admin Hub controls.")}
          </p>
        </div>
      </div>

      {/* Internal Settings Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#161822] pb-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={
                isActive
                  ? {
                      borderColor: accentColor,
                      backgroundColor: `${accentColor}20`,
                      boxShadow: `0 0 12px ${accentColor}30`,
                      color: "#ffffff"
                    }
                  : {}
              }
              className={`px-4 py-2 rounded text-[10px] font-extrabold uppercase transition-all flex items-center gap-2 border ${
                isActive
                  ? ""
                  : "bg-[#090a0d] border-[#181a24] text-[#8a8d9a] hover:border-[#333] hover:text-white"
              }`}
            >
              <Icon className="w-3.5 h-3.5" style={{ color: isActive ? accentColor : "#8a8d9a" }} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Active Sub-Panel Rendering */}
      <div className="pt-2">
        {activeTab === "about" && <AboutMemoBotSettings />}
        {activeTab === "general" && <GeneralSettings showAlert={showAlert} />}
        {activeTab === "theme" && <ThemeStudioSettings showAlert={showAlert} />}
        {activeTab === "translations" && <TranslationStudioSettings showAlert={showAlert} />}
        {activeTab === "notifications" && <NotificationsSettings showAlert={showAlert} />}
        {activeTab === "subscription" && <SubscriptionFeesSettings showAlert={showAlert} />}
        {activeTab === "admin" && <AdminHubSettings showAlert={showAlert} />}
        {activeTab === "social" && <SocialManager />}
      </div>
    </div>
  );
};

export default Settings;
