import React, { useState } from "react";
import { ApiClient } from "../services/api";
import { STORAGE_KEYS } from "../config/constants";
import { identityStore, TIER_PROFILES } from "../services/identityStore";
import { IdentityService } from "../services/identityService";
import { TierId } from "../types";
import { useLanguage } from "../components/LanguageProvider";
import { Shield, Key, RefreshCw, Lock, ArrowLeft, Fingerprint, Globe, CheckCircle2, Layers, Cpu } from "lucide-react";

interface LoginProps {
  onLoginSuccess: (token: string) => void;
}

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const { isArabic, toggleLanguage, t } = useLanguage();
  const [selectedTier, setSelectedTier] = useState<TierId>("institutional");
  const [username, setUsername] = useState("maher_root");
  const [password, setPassword] = useState("admin");
  const [mfaCode, setMfaCode] = useState("849201");
  const [ssoDomain, setSsoDomain] = useState("corp-wl09.saml.enterprise");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Password Enforcement Flow States
  const [mustChange, setMustChange] = useState(false);
  const [changeUsername, setChangeUsername] = useState("");
  const [tempPassword, setTempPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const handleSelectTier = (tier: TierId) => {
    setSelectedTier(tier);
    setError(null);
    if (tier === "individual") {
      setUsername("individual_trader");
      setPassword("admin");
    } else if (tier === "investor") {
      setUsername("pro_investor");
      setPassword("admin");
      setMfaCode("849201");
    } else if (tier === "corporate") {
      setUsername("enterprise_admin");
      setPassword("admin");
      setSsoDomain("corp-wl09.saml.enterprise");
    } else {
      setUsername("maher_root");
      setPassword("admin");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (selectedTier === "investor" && mfaCode.length < 4) {
        throw new Error("Invalid TOTP MFA 6-digit verification code.");
      }

      const resp = await ApiClient.post("/auth/login-json", { 
        username, 
        password,
        tier: selectedTier 
      });

      if (resp.mustChangePassword) {
        setChangeUsername(resp.username || username);
        setTempPassword(password);
        setMustChange(true);
      } else if (resp.access_token) {
        IdentityService.switchTier(selectedTier, username);
        localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, resp.access_token);
        onLoginSuccess(resp.access_token);
      } else {
        throw new Error("Invalid token payload returned.");
      }
    } catch (err: any) {
      setError(err.message || "Failed to authenticate secure session.");
    } finally {
      setLoading(false);
    }
  };

  const handleQuickWebAuthn = async () => {
    setLoading(true);
    setError(null);
    try {
      await IdentityService.verifyWebAuthn();
      const resp = await ApiClient.post("/auth/login-json", {
        username: "individual_biometric",
        password: "biometric_authorized",
        tier: "individual"
      });
      IdentityService.switchTier("individual", "individual_biometric");
      localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, resp.access_token || "mbot-biometric-token");
      onLoginSuccess(resp.access_token || "mbot-biometric-token");
    } catch (err: any) {
      setError(err.message || "Biometric authentication failed.");
    } finally {
      setLoading(false);
    }
  };

  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.trim() !== confirmPassword.trim()) {
      setError("Passwords do not match. Please verify.");
      return;
    }
    if (newPassword.trim().length < 4) {
      setError("New password must be at least 4 characters long.");
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const resp = await ApiClient.post("/auth/change-password", {
        username: changeUsername,
        oldPassword: tempPassword,
        newPassword: newPassword.trim()
      });

      if (resp.success && resp.access_token) {
        IdentityService.switchTier(selectedTier, changeUsername);
        setSuccessMsg(t("SECURE CREDENTIAL SWAP COMPLETED"));
        setTimeout(() => {
          localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, resp.access_token);
          onLoginSuccess(resp.access_token);
        }, 1200);
      } else {
        throw new Error(resp.error || "Failed to re-key terminal password.");
      }
    } catch (err: any) {
      setError(err.message || "Credential update rejected by secure node.");
    } finally {
      setLoading(false);
    }
  };

  const activeProfile = TIER_PROFILES[selectedTier];

  return (
    <div className="min-h-screen bg-[#06070a] flex items-center justify-center p-4 relative overflow-hidden font-mono">
      <div className="absolute inset-0 bg-radial-gradient(circle at center, transparent 0%, #06070a 100%) pointer-events-none" />

      {/* Top right language switch */}
      <div className="absolute top-4 right-4 z-20">
        <button
          onClick={toggleLanguage}
          className="px-3 py-1.5 rounded-lg bg-[#0d0e12] hover:bg-[#161a23] border border-[#1a1d26] hover:border-cyan-500/50 text-white text-xs font-bold flex items-center gap-2 cursor-pointer transition-all shadow-md"
        >
          <Globe className="w-3.5 h-3.5 text-cyan-400" />
          <span>{isArabic ? "🇸🇦 العربية" : "🇬🇧 English"}</span>
        </button>
      </div>

      <div 
        className="w-full max-w-lg bg-[#0d0e12] border border-[#1a1d26] p-6 sm:p-8 rounded-xl shadow-[0_20px_50px_rgba(0,0,0,0.7)] z-10 flex flex-col gap-5 panel-glow"
        style={{ direction: isArabic ? "rtl" : "ltr" }}
      >
        {/* Brand Header */}
        <div className="text-center space-y-1 flex flex-col items-center">
          <img src="/MemoBot.png" alt="MemoBot FX-PRO" className="h-10 max-w-[220px] object-contain mix-blend-screen" />
          <div className="flex items-center gap-1.5 mt-1">
            <span className="text-[9px] text-[#8a8d9a] tracking-[0.25em] uppercase font-black">
              {t("IDENTITY MATRIX & AUTHENTICATION GATEWAY")}
            </span>
          </div>
        </div>

        {!mustChange ? (
          <div className="space-y-4 text-xs">
            {/* 4-Tier Provisioning Selector */}
            <div>
              <label className="text-[#8a8d9a] uppercase text-[9px] font-bold block mb-2 flex items-center gap-1">
                <Layers className="w-3 h-3 text-cyan-400" />
                {t("SELECT PROVISIONING TIER")}
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(Object.keys(TIER_PROFILES) as TierId[]).map((tierKey) => {
                  const p = TIER_PROFILES[tierKey];
                  const isSelected = selectedTier === tierKey;
                  return (
                    <button
                      key={tierKey}
                      type="button"
                      onClick={() => handleSelectTier(tierKey)}
                      className={`p-2.5 rounded-lg border text-left flex flex-col justify-between transition-all cursor-pointer ${
                        isSelected 
                          ? "bg-[#131724] shadow-[0_0_15px_rgba(0,0,0,0.5)]" 
                          : "bg-[#08090d] hover:bg-[#10131c] border-[#181c28] opacity-70 hover:opacity-100"
                      }`}
                      style={isSelected ? { borderColor: p.colorAccent } : {}}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-white text-[11px]">
                          {isArabic ? p.nameAr : p.name}
                        </span>
                        {isSelected && <CheckCircle2 className="w-3 h-3" style={{ color: p.colorAccent }} />}
                      </div>
                      <span className="text-[8.5px] font-semibold mt-1" style={{ color: p.colorAccent }}>
                        {isArabic ? p.resourceBoundAr : p.resourceBound}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Active Tier Security Badge */}
            <div 
              className="p-2.5 rounded-lg border flex items-center justify-between text-[10px]"
              style={{ backgroundColor: `${activeProfile.colorAccent}10`, borderColor: `${activeProfile.colorAccent}30` }}
            >
              <div className="flex items-center gap-2">
                <Shield className="w-3.5 h-3.5" style={{ color: activeProfile.colorAccent }} />
                <span className="text-[#a0a4b0]">{isArabic ? activeProfile.authMethodAr : activeProfile.authMethod}</span>
              </div>
              <span className="font-bold font-mono" style={{ color: activeProfile.colorAccent }}>
                {activeProfile.latencySla}
              </span>
            </div>

            {/* Dynamic Auth Form */}
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="flex flex-col gap-1">
                <label className="text-[#8a8d9a] uppercase text-[9px] font-bold block">{t("ACCESS ID (USERNAME)")}</label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-cyan-400 text-white p-2 rounded outline-none text-xs"
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-[#8a8d9a] uppercase text-[9px] font-bold block">{t("SECURE PASSWORD KEY")}</label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-cyan-400 text-white p-2 rounded outline-none text-xs"
                />
              </div>

              {selectedTier === "investor" && (
                <div className="flex flex-col gap-1">
                  <label className="text-[#8a8d9a] uppercase text-[9px] font-bold block">{t("VERIFY MFA CODE")} (TOTP)</label>
                  <input
                    type="text"
                    required
                    value={mfaCode}
                    onChange={(e) => setMfaCode(e.target.value)}
                    placeholder="6-digit authenticator code"
                    className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-blue-400 text-white p-2 rounded outline-none text-xs"
                  />
                </div>
              )}

              {selectedTier === "corporate" && (
                <div className="flex flex-col gap-1">
                  <label className="text-[#8a8d9a] uppercase text-[9px] font-bold block">{t("ENTERPRISE SSO (SAML 2.0)")}</label>
                  <input
                    type="text"
                    required
                    value={ssoDomain}
                    onChange={(e) => setSsoDomain(e.target.value)}
                    className="w-full bg-[#06070a] border border-[#1a1d26] focus:border-purple-400 text-white p-2 rounded outline-none text-xs"
                  />
                </div>
              )}

              {error && (
                <div className="bg-[rgba(255,23,68,0.08)] border border-[#ff1744] text-[#ff1744] p-2 rounded text-[10px] text-center font-semibold">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-white font-bold rounded text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md"
                style={{ backgroundColor: activeProfile.colorAccent, color: selectedTier === "individual" ? "#000" : "#fff" }}
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    {t("INITIALIZING...")}
                  </>
                ) : (
                  t("INITIALIZE SECURE SESSION")
                )}
              </button>

              {selectedTier === "individual" && (
                <button
                  type="button"
                  onClick={handleQuickWebAuthn}
                  disabled={loading}
                  className="w-full py-2 bg-[#121620] hover:bg-[#181e2c] border border-[#222838] text-cyan-400 font-bold rounded text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Fingerprint className="w-3.5 h-3.5" />
                  {t("WEBAUTHN / BIOMETRICS")}
                </button>
              )}
            </form>
          </div>
        ) : (
          /* Password reset */
          <form onSubmit={handleChangePasswordSubmit} className="space-y-3 font-mono text-xs">
            <div className="border-b border-[#1a1d26] pb-2 text-center">
              <div className="text-rose-500 font-bold text-[10px] uppercase flex items-center justify-center gap-1">
                <Lock className="w-3.5 h-3.5" />
                {t("RE-KEY TERMINAL PASSWORD")}
              </div>
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-[#8a8d9a] uppercase text-[9px] font-bold block">{t("NEW SECURE KEY")}</label>
              <input
                type="password"
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2 rounded outline-none"
              />
            </div>

            <div className="flex flex-col gap-1">
              <label className="text-[#8a8d9a] uppercase text-[9px] font-bold block">{t("CONFIRM SECURE KEY")}</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2 rounded outline-none"
              />
            </div>

            {error && <div className="text-rose-500 text-[10px] text-center">{error}</div>}
            {successMsg && <div className="text-emerald-400 text-[10px] text-center">{successMsg}</div>}

            <button
              type="submit"
              disabled={loading || !!successMsg}
              className="w-full py-2.5 bg-cyan-500 text-black font-bold rounded text-xs"
            >
              {t("UPDATE PASSWORD & LAUNCH")}
            </button>
          </form>
        )}

        {/* Security Footer */}
        <div className="flex items-center justify-center gap-1.5 text-[9px] text-[#8a8d9a] font-mono border-t border-[#1a1d26] pt-3">
          <Shield className="w-3 h-3 text-emerald-400" />
          <span>{t("HARDWARE ENCLAVE ACTIVE")} • SHA-256 LEDGER LINKED</span>
        </div>
      </div>
    </div>
  );
};
