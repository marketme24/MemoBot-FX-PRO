import React, { useState, useEffect, useRef } from "react";
import { ApiClient } from "../services/api";
import { NeuralCanvas } from "../components/NeuralCanvas";
import { MemoBotIcon } from "../components/MemoBotIcon";
import { VoiceInputButton } from "../components/VoiceInputButton";
import { useNotification } from "../components/NotificationProvider";
import {
  Cpu,
  Send,
  User,
  Volume2,
  VolumeX,
  RefreshCw,
  Copy,
  Check,
  Terminal,
  ShieldCheck,
  Zap,
  Activity,
  AlertTriangle,
  Server,
  Layers,
  ArrowRight,
  Sparkles,
  Search,
  CheckCircle2,
  Sliders
} from "lucide-react";

interface StructuredResponse {
  understanding?: string;
  rootCause?: string;
  resolutionSteps?: string[];
  compliance?: string;
  rawText?: string;
}

interface Message {
  id: string;
  role: "user" | "ai";
  text: string;
  timestamp: string;
  engineContext?: string;
  errorCode?: string;
  parsed?: StructuredResponse;
  correlationId?: string;
}

const PIPELINE_STAGES = [
  { code: "SG", label: "Signal Gen" },
  { code: "FX", label: "Routing" },
  { code: "SHA", label: "Shariah 1x" },
  { code: "RSK", label: "Risk Kernel" },
  { code: "SIZE", label: "Precision Size" },
  { code: "PLC", label: "Placement" },
  { code: "CMP", label: "Compliance" },
  { code: "REC", label: "Reconcile" },
  { code: "MON", label: "Monitoring" }
];

const ENGINES = [
  { id: "RIGEL", name: "RIGEL", type: "Manual Scalper", latency: "< 8ms", status: "ONLINE" },
  { id: "SIRIUS", name: "SIRIUS", type: "Full Auto HFT", latency: "< 4ms", status: "ONLINE" },
  { id: "CANOPUS", name: "CANOPUS", type: "Hybrid Monitor", latency: "< 12ms", status: "STANDBY" },
  { id: "GEMINI", name: "GEMINI", type: "Flash Core", latency: "< 2ms", status: "ARMED" }
];

const ERROR_PRESETS = [
  { code: "ERR-ORD-422", label: "ERR-ORD-422: Order Validation Failed (Size Precision)", query: "My order on RIGEL didn't execute and returned ERR-ORD-422. Please provide technical root cause and step-by-step resolution." },
  { code: "ERR-WS-210", label: "ERR-WS-210: WebSocket Heartbeat Lost", query: "WebSocket heartbeat dropped with ERR-WS-210. How do I re-sync stateless cluster topics?" },
  { code: "ERR-EX-401", label: "ERR-EX-401: Exchange Auth / Vault Mismatch", query: "Received ERR-EX-401 exchange authentication failure. Audit AES-256 Vault Ed25519 KMS signature." },
  { code: "ERR-ENG-503", label: "ERR-ENG-503: Engine State Offline", query: "SIRIUS auto-engine halted with ERR-ENG-503 after circuit breaker tripped. How to safely resume?" }
];

export const AIChat: React.FC = () => {
  const { showAlert } = useNotification();
  
  const [selectedEngine, setSelectedEngine] = useState<string>("RIGEL");
  const [activeAsset, setActiveAsset] = useState<string>("BTC/USDT");
  const [tradingMode, setTradingMode] = useState<"Paper" | "Live">("Paper");
  const [complianceMode, setComplianceMode] = useState<"Islamic Spot 1x" | "Commercial">("Islamic Spot 1x");
  
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "msg-init-1",
      role: "ai",
      text: "Understanding:\nActive on RIGEL engine in Paper Mode on BTC/USDT.\nWebSocket heartbeat is stable (21ms). AES-256 Vault credentials and AAOIFI Shariah 1:1 Spot compliance filters are verified.\n\nTechnical Root Cause Analysis:\nAll 9 stages of the MEMOBOT execution pipeline (SG ➔ FX ➔ SHA ➔ RSK ➔ SIZE ➔ PLC ➔ CMP ➔ REC ➔ MON) are operational with zero telemetry anomalies.\n\nStep-by-Step Resolution:\n1. Select an active engine or query a technical error code from the telemetry bar below.\n2. Inquire about routing pipeline synchronization, exchange authentication, or order execution.\n3. Use the microphone voice tool to dictate operational commands with low-latency transcription.\n\nCompliance Guardrails:\nMEMOBOT FX-PRO operates under deterministic quantitative protocols. Past performance is not indicative of future results.",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      engineContext: "RIGEL",
      correlationId: "TRC-89042-MEMO"
    }
  ]);

  const [inputQuery, setInputQuery] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isProcessing]);

  const parseStructuredText = (text: string): StructuredResponse => {
    const res: StructuredResponse = { rawText: text };
    
    // Check if contains structured headers
    if (text.includes("Understanding:") || text.includes("Root Cause:") || text.includes("Resolution:")) {
      const parts = text.split(/(Understanding:|Technical Root Cause Analysis:|Root Cause:|Step-by-Step Resolution:|Resolution:|Compliance Guardrails:|Compliance:)/i);
      
      for (let i = 0; i < parts.length; i++) {
        const header = parts[i]?.trim().toLowerCase();
        const content = parts[i + 1]?.trim() || "";
        
        if (header.includes("understanding")) {
          res.understanding = content;
        } else if (header.includes("root cause")) {
          res.rootCause = content;
        } else if (header.includes("resolution")) {
          res.resolutionSteps = content.split(/\n(?=\d+\.)/).map(s => s.trim()).filter(Boolean);
        } else if (header.includes("compliance")) {
          res.compliance = content;
        }
      }
    }
    return res;
  };

  const handleSend = async (overrideText?: string, errorCodePreset?: string) => {
    const textToSend = (overrideText || inputQuery).trim();
    if (!textToSend || isProcessing) return;

    setInputQuery("");
    setIsProcessing(true);

    const corrId = `TRC-${Math.floor(10000 + Math.random() * 90000)}-${selectedEngine}`;
    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      role: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      engineContext: selectedEngine,
      errorCode: errorCodePreset,
      correlationId: corrId
    };

    setMessages((prev) => [...prev, userMsg]);

    try {
      const response = await ApiClient.post("/ai/query", {
        message: textToSend,
        context: {
          activeTab: "Engine Station / " + selectedEngine,
          activeEngine: selectedEngine,
          activeStrategy: selectedEngine === "RIGEL" ? "Fast H-F Scalper" : selectedEngine === "SIRIUS" ? "AI Swarm Consensus" : "Trend Balancer",
          activeAsset,
          complianceMode,
          tradingMode: `${tradingMode} Mode`,
          vaultStatus: "AES-256 SYNCED (Ed25519 KMS Active)",
          wsHeartbeat: "19ms (0% Jitter - Stable)",
          correlationId: corrId
        }
      });

      const rawAiText = response.response || "Inquiry analyzed by Senior Operations Support.";
      const parsedContent = parseStructuredText(rawAiText);

      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        role: "ai",
        text: rawAiText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        engineContext: selectedEngine,
        parsed: parsedContent,
        correlationId: corrId
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: "ai",
          text: `Understanding:\nInquiry logged with Operations Core.\n\nTechnical Root Cause Analysis:\nNetwork gateway latency or local cache fallback engaged: [${err.message || "Cluster link active"}].\n\nStep-by-Step Resolution:\n1. Verify active WebSocket heartbeat in the telemetry ribbon.\n2. Re-test exchange API secret sync in the Secure Vault.\n3. Resume automated order dispatching.`,
          timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          engineContext: selectedEngine,
          correlationId: corrId
        }
      ]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    showAlert("Technical resolution copied to clipboard!");
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleMiniMeExecuteAction = async (endpoint: string, payload: any) => {
    const corrId = `MINI-${Math.floor(10000 + Math.random() * 90000)}`;
    try {
      const resp = await ApiClient.post(endpoint, payload);
      showAlert(`Action dispatched to ${endpoint} successfully. ID: ${corrId}`);
      if (payload.mode) {
        setComplianceMode(payload.mode);
      }
    } catch (err: any) {
      showAlert(`Action execution failed: ${err.message || "Endpoint error"}`);
      throw err;
    }
  };

  return (
    <div className="flex-1 bg-[#07080b] p-3 sm:p-5 overflow-hidden flex flex-col h-full space-y-3 font-mono select-none text-slate-200">
      
      {/* TOP QUANTUM OPERATIONS CONTROL BAR */}
      <div className="bg-[#0b0d13] border border-[#161a24] rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-3 shadow-lg shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#FA1F4E]/10 border border-[#FA1F4E]/40 flex items-center justify-center shadow-[0_0_15px_rgba(250,31,78,0.2)]">
            <Cpu className="w-5 h-5 text-[#FA1F4E] animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-aquire font-black tracking-wider text-white">MEMOBOT FX‑PRO · ELITE TECHNICAL OPERATIONS</h1>
              <span className="px-2 py-0.5 bg-[#FA1F4E]/15 text-[#FA1F4E] border border-[#FA1F4E]/30 text-[8.5px] font-bold rounded">
                TIER-1 SENIOR ENGINE
              </span>
            </div>
            <p className="text-[10px] text-slate-400">Context-Aware Real-Time Engine Triage, Pipeline Diagnostic & Zero-Trust Resolution</p>
          </div>
        </div>

        {/* ACTIVE TELEMETRY CHIPS */}
        <div className="flex items-center gap-2 text-[10px]">
          {/* Engine Selector */}
          <div className="flex items-center bg-[#07080b] border border-[#1a1e2b] rounded-lg p-0.5">
            {ENGINES.map((eng) => (
              <button
                key={eng.id}
                onClick={() => setSelectedEngine(eng.id)}
                className={`px-2.5 py-1 rounded text-[9.5px] font-bold transition-all cursor-pointer ${
                  selectedEngine === eng.id
                    ? "bg-[#FA1F4E] text-white shadow-[0_0_10px_rgba(250,31,78,0.4)]"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {eng.name}
              </button>
            ))}
          </div>

          {/* Mode Pill */}
          <button
            onClick={() => setTradingMode(tradingMode === "Paper" ? "Live" : "Paper")}
            className="px-2.5 py-1 bg-[#07080b] hover:bg-[#121622] border border-[#1a1e2b] text-slate-300 rounded-lg text-[9.5px] font-bold flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <span className={`w-1.5 h-1.5 rounded-full ${tradingMode === "Live" ? "bg-emerald-400 animate-pulse" : "bg-amber-400"}`} />
            <span>{tradingMode.toUpperCase()} MODE</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="p-1.5 bg-[#07080b] hover:bg-[#121622] border border-[#1a1e2b] text-slate-400 hover:text-white rounded-lg transition-all cursor-pointer"
            title="Toggle Audio Feedback"
          >
            {soundEnabled ? <Volume2 className="w-3.5 h-3.5 text-sky-400" /> : <VolumeX className="w-3.5 h-3.5 text-red-400" />}
          </button>
        </div>
      </div>

      {/* NEURAL QUANTUM VISUALIZER */}
      <div className="h-[190px] shrink-0 rounded-xl overflow-hidden border border-[#161a24] bg-[#0b0d13] relative shadow-md">
        <NeuralCanvas isThinking={isProcessing} intensity={isProcessing ? 2 : 1} />
        
        {/* Real-time Heartbeat Overlay */}
        <div className="absolute top-2 left-3 flex items-center gap-2 bg-[#07080b]/80 backdrop-blur-md px-2.5 py-1 rounded border border-[#1a1e2b] text-[9px] text-slate-300">
          <Activity className="w-3 h-3 text-sky-400 animate-pulse" />
          <span>ACTIVE ENGINE: <strong className="text-white">{selectedEngine}</strong></span>
          <span className="text-slate-600">|</span>
          <span>LATENCY: <strong className="text-emerald-400">19ms</strong></span>
          <span className="text-slate-600">|</span>
          <span>VAULT: <strong className="text-sky-400">AES-256 SYNCED</strong></span>
        </div>
      </div>

      {/* 9-STAGE ROUTING PIPELINE RAIL */}
      <div className="bg-[#0b0d13] border border-[#161a24] rounded-xl px-3.5 py-2 flex items-center justify-between overflow-x-auto gap-2 text-[9px] shrink-0">
        <div className="flex items-center gap-1.5 text-slate-400 font-bold uppercase tracking-wider shrink-0 pr-2 border-r border-[#1a1e2b]">
          <Layers className="w-3 h-3 text-[#FA1F4E]" />
          <span>ROUTING PIPELINE:</span>
        </div>
        <div className="flex items-center gap-1.5 flex-1 justify-between min-w-[500px]">
          {PIPELINE_STAGES.map((stg, idx) => (
            <React.Fragment key={stg.code}>
              <div className="flex flex-col items-center bg-[#07080b] border border-[#1a1e2b] px-2.5 py-1 rounded text-center">
                <span className="text-[10px] font-black text-white">{stg.code}</span>
                <span className="text-[7.5px] text-slate-400">{stg.label}</span>
              </div>
              {idx < PIPELINE_STAGES.length - 1 && (
                <ArrowRight className="w-2.5 h-2.5 text-slate-600 shrink-0" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* MAIN CHAT TERMINAL CONTAINER */}
      <div className="flex-1 bg-[#0b0d13] border border-[#161a24] rounded-xl flex flex-col min-h-0 overflow-hidden shadow-2xl relative">
        
        {/* MESSAGES SCROLLER */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 font-mono text-xs leading-relaxed">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-[92%] md:max-w-[85%] ${
                msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
              }`}
            >
              {/* Avatar */}
              <div
                className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center font-bold border ${
                  msg.role === "user"
                    ? "bg-[#3b82f6]/10 text-[#3b82f6] border-[#3b82f6]/40 shadow-[0_0_10px_rgba(59,130,246,0.2)]"
                    : "bg-[#FA1F4E]/10 text-[#FA1F4E] border-[#FA1F4E]/40 shadow-[0_0_10px_rgba(250,31,78,0.2)]"
                }`}
              >
                {msg.role === "user" ? <User className="w-4 h-4" /> : <MemoBotIcon size={18} color="#FA1F4E" />}
              </div>

              {/* Message Content */}
              <div className="space-y-1.5 flex-1 min-w-0">
                <div className="flex items-center justify-between text-[9px] text-slate-400">
                  <div className="flex items-center gap-2">
                    <span className="font-bold tracking-wider uppercase text-white">
                      {msg.role === "user" ? "OPERATOR INQUIRY" : "SENIOR OPERATIONS ENGINEER"}
                    </span>
                    {msg.engineContext && (
                      <span className="px-1.5 py-0.2 bg-[#161a24] border border-[#23293a] text-slate-300 rounded text-[8px]">
                        ENGINE: {msg.engineContext}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {msg.correlationId && (
                      <span className="text-[8px] text-slate-500">{msg.correlationId}</span>
                    )}
                    <span>{msg.timestamp}</span>
                  </div>
                </div>

                <div
                  className={`p-4 rounded-xl border leading-relaxed space-y-3 ${
                    msg.role === "user"
                      ? "bg-[#10141e] border-[#1d2334] text-white"
                      : "bg-[#08090e] border-[#161a24] text-slate-200"
                  }`}
                >
                  {/* If structured format is available, render clean cards */}
                  {msg.parsed?.understanding || msg.parsed?.rootCause || msg.parsed?.resolutionSteps ? (
                    <div className="space-y-3">
                      {msg.parsed.understanding && (
                        <div className="p-2.5 rounded-lg bg-[#0e1118] border border-[#1a1e2b] space-y-1">
                          <div className="text-[9px] font-bold text-sky-400 uppercase tracking-wider flex items-center gap-1.5">
                            <Search className="w-3 h-3" />
                            1. IMMEDIATE UNDERSTANDING & CONTEXT
                          </div>
                          <p className="text-xs text-slate-300 whitespace-pre-wrap">{msg.parsed.understanding}</p>
                        </div>
                      )}

                      {msg.parsed.rootCause && (
                        <div className="p-2.5 rounded-lg bg-[#0e1118] border border-[#1a1e2b] space-y-1">
                          <div className="text-[9px] font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
                            <AlertTriangle className="w-3 h-3" />
                            2. TECHNICAL ROOT-CAUSE ANALYSIS
                          </div>
                          <p className="text-xs text-slate-300 whitespace-pre-wrap">{msg.parsed.rootCause}</p>
                        </div>
                      )}

                      {msg.parsed.resolutionSteps && msg.parsed.resolutionSteps.length > 0 && (
                        <div className="p-2.5 rounded-lg bg-[#0e1118] border border-[#1a1e2b] space-y-2">
                          <div className="text-[9px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                            <CheckCircle2 className="w-3 h-3" />
                            3. STEP-BY-STEP RESOLUTION
                          </div>
                          <div className="space-y-1.5">
                            {msg.parsed.resolutionSteps.map((step, sIdx) => (
                              <div key={sIdx} className="text-xs text-slate-200 flex items-start gap-2 bg-[#08090e] p-2 rounded border border-[#141722]">
                                <span className="font-bold text-[#FA1F4E] shrink-0">#{sIdx + 1}</span>
                                <span>{step.replace(/^\d+\.\s*/, "")}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {msg.parsed.compliance && (
                        <div className="p-2 rounded bg-[#07080b] border border-[#141722] text-[9px] text-slate-400 flex items-center gap-1.5">
                          <ShieldCheck className="w-3 h-3 text-sky-400 shrink-0" />
                          <span>{msg.parsed.compliance}</span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <p className="whitespace-pre-wrap text-xs">{msg.text}</p>
                    </div>
                  )}

                  {/* Message Action Bar */}
                  {msg.role === "ai" && (
                    <div className="flex items-center justify-between pt-2 border-t border-[#141722] text-[9px]">
                      <div className="flex items-center gap-1 text-slate-500">
                        <Server className="w-3 h-3" />
                        <span>MEMOBOT FX-PRO DETERMINISTIC ENGINE</span>
                      </div>
                      <button
                        onClick={() => handleCopy(msg.id, msg.text)}
                        className="px-2 py-0.5 rounded bg-[#0e1118] hover:bg-[#161a24] border border-[#1a1e2b] text-slate-300 hover:text-white flex items-center gap-1 transition-all cursor-pointer"
                      >
                        {copiedId === msg.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedId === msg.id ? "COPIED" : "COPY RESOLUTION"}</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}

          {isProcessing && (
            <div className="flex gap-3 max-w-[80%] mr-auto items-center">
              <div className="w-8 h-8 rounded-lg shrink-0 flex items-center justify-center bg-[#FA1F4E]/10 text-[#FA1F4E] border border-[#FA1F4E]/40">
                <Cpu className="w-4 h-4 animate-spin" />
              </div>
              <div className="p-3 bg-[#08090e] border border-[#161a24] rounded-xl text-[10px] text-sky-400 font-mono flex items-center gap-2 shadow-lg">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#FA1F4E]" />
                <span>SENIOR OPERATIONS ASSISTANT EVALUATING ENGINE TELEMETRY & PIPELINE CONTEXT...</span>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* ERROR CODE & TECHNICAL PRESETS RAIL */}
        <div className="p-2 bg-[#08090e] border-t border-[#161a24] flex items-center gap-2 overflow-x-auto text-[9.5px]">
          <span className="text-slate-400 font-bold uppercase shrink-0 flex items-center gap-1 pl-1">
            <Terminal className="w-3 h-3 text-[#FA1F4E]" />
            ERROR TRIAGE PRESETS:
          </span>
          {ERROR_PRESETS.map((ep) => (
            <button
              key={ep.code}
              onClick={() => handleSend(ep.query, ep.code)}
              disabled={isProcessing}
              className="px-2.5 py-1 bg-[#0e1118] hover:bg-[#161a24] border border-[#1a1e2b] hover:border-[#FA1F4E]/50 text-slate-300 hover:text-white rounded-lg whitespace-nowrap transition-all font-mono cursor-pointer disabled:opacity-50"
            >
              {ep.label}
            </button>
          ))}
        </div>

        {/* INPUT PROMPT BAR WITH HIGH-GRADE VOICE TRANSCRIPTION */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 bg-[#0a0c12] border-t border-[#161a24] flex items-center gap-2 shrink-0"
        >
          {/* Audio Microphone Input via gemini-3.5-transcribe */}
          <VoiceInputButton
            onTranscribe={(transcribedText) => {
              setInputQuery((prev) => (prev ? `${prev} ${transcribedText}` : transcribedText));
            }}
            disabled={isProcessing}
            buttonLabel="VOICE INPUT"
          />

          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder="Type technical question, engine error code (e.g. ERR-ORD-422), or speak via microphone..."
            className="flex-1 bg-[#07080b] border border-[#161a24] focus:border-[#FA1F4E] text-white px-3.5 py-2.5 rounded-lg outline-none font-mono text-xs placeholder:text-slate-600 transition-colors"
          />

          <button
            type="submit"
            disabled={isProcessing || !inputQuery.trim()}
            className="px-5 py-2.5 bg-[#FA1F4E] hover:bg-[#d81943] text-white rounded-lg font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 disabled:opacity-50 cursor-pointer shadow-[0_0_15px_rgba(250,31,78,0.3)]"
          >
            <Send className="w-4 h-4" />
            <span>DISPATCH</span>
          </button>
        </form>
      </div>

    </div>
  );
};

export default AIChat;
