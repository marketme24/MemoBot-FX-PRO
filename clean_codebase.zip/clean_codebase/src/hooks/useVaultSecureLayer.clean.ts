import { useState, useEffect, useCallback, useRef } from "react";
import { VaultSecurityManager, VaultSecurityConfig, DecoyTheme } from "../services/vaultSecurity";

export interface CredentialFormsState {
  [service: string]: { api_key: string; api_secret: string; api_passphrase?: string };
}

const INITIAL_FORMS: CredentialFormsState = {
  Binance: { api_key: "", api_secret: "" },
  Binance_Slot2: { api_key: "", api_secret: "" },
  Binance_Slot3: { api_key: "", api_secret: "" },
  Binance_Slot4: { api_key: "", api_secret: "" },
  
  KuCoin: { api_key: "", api_secret: "", api_passphrase: "" },
  KuCoin_Slot2: { api_key: "", api_secret: "", api_passphrase: "" },
  KuCoin_Slot3: { api_key: "", api_secret: "", api_passphrase: "" },
  KuCoin_Slot4: { api_key: "", api_secret: "", api_passphrase: "" },
  
  OKX: { api_key: "", api_secret: "", api_passphrase: "" },
  OKX_Slot2: { api_key: "", api_secret: "", api_passphrase: "" },
  OKX_Slot3: { api_key: "", api_secret: "", api_passphrase: "" },
  OKX_Slot4: { api_key: "", api_secret: "", api_passphrase: "" },
  
  Bybit: { api_key: "", api_secret: "" },
  Bybit_Slot2: { api_key: "", api_secret: "" },
  Bybit_Slot3: { api_key: "", api_secret: "" },
  Bybit_Slot4: { api_key: "", api_secret: "" },
  
  Telegram: { api_key: "", api_secret: "" },
  WhatsApp: { api_key: "", api_secret: "" },
  Gemini: { api_key: "", api_secret: "" },
  OpenAI: { api_key: "", api_secret: "" },
  Anthropic: { api_key: "", api_secret: "" },
  DeepSeek: { api_key: "", api_secret: "" },
};

export function useVaultSecureLayer() {
  const [config, setConfig] = useState<VaultSecurityConfig>(() => VaultSecurityManager.getConfig());
  const [isLocked, setIsLocked] = useState<boolean>(() => VaultSecurityManager.isLocked());
  const [isTransitioning, setIsTransitioning] = useState<boolean>(false);
  const [forms, setForms] = useState<CredentialFormsState>(INITIAL_FORMS);

  // Sync latest security configuration
  const refreshConfig = useCallback(() => {
    const latestConfig = VaultSecurityManager.getConfig();
    const latestLocked = VaultSecurityManager.isLocked();
    setConfig(latestConfig);
    setIsLocked(latestLocked);
    if (latestLocked) {
      // Immediately purge sensitive fields from RAM when locked
      setForms(INITIAL_FORMS);
    }
  }, []);

  // Lock function with smooth transition delay and memory purge
  const lockVault = useCallback(() => {
    setIsTransitioning(true);
    setTimeout(() => {
      VaultSecurityManager.lock();
      setIsLocked(true);
      setForms(INITIAL_FORMS); // Purge secrets from React state
      setIsTransitioning(false);
    }, 250);
  }, []);

  // Unlock function
  const unlockVault = useCallback((passcode: string): boolean => {
    const isValid = VaultSecurityManager.verifyPasscode(passcode);
    if (isValid) {
      setIsTransitioning(true);
      setTimeout(() => {
        VaultSecurityManager.unlock();
        setIsLocked(false);
        setIsTransitioning(false);
      }, 250);
      return true;
    }
    return false;
  }, []);

  // Purge form input fields on unmount or navigate away
  useEffect(() => {
    const handleBeforeUnload = () => {
      if (config.autoLockOnLeave && config.hasPasscode) {
        VaultSecurityManager.lock();
      }
      setForms(INITIAL_FORMS);
    };

    const handleVisibilityChange = () => {
      if (document.hidden && config.autoLockOnLeave && config.hasPasscode) {
        VaultSecurityManager.lock();
        setIsLocked(true);
        setForms(INITIAL_FORMS);
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    document.addEventListener("visibilitychange", handleVisibilityChange);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      // Auto-purge memory on component unmount
      if (config.autoLockOnLeave && config.hasPasscode) {
        VaultSecurityManager.lock();
      }
      setForms(INITIAL_FORMS);
    };
  }, [config.autoLockOnLeave, config.hasPasscode]);

  const updateFormInput = useCallback((service: string, field: "api_key" | "api_secret" | "api_passphrase", value: string) => {
    setForms((prev) => ({
      ...prev,
      [service]: {
        ...prev[service],
        [field]: value,
      },
    }));
  }, []);

  const clearFormInputs = useCallback(() => {
    setForms(INITIAL_FORMS);
  }, []);

  return {
    config,
    isLocked,
    isTransitioning,
    forms,
    updateFormInput,
    clearFormInputs,
    lockVault,
    unlockVault,
    refreshConfig,
  };
}
