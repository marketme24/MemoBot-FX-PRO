import { pgTable, serial, text, boolean, integer, jsonb, timestamp, pgEnum, primaryKey } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: text('id').primaryKey(),
  username: text('username').notNull(),
  role: text('role').notNull(),
  isActive: boolean('is_active').default(true),
  token: text('token'),
});

export const portfolios = pgTable('portfolios', {
  userId: text('user_id').references(() => users.id).primaryKey(),
  netWorth: integer('net_worth').default(0),
  balanceUsdt: integer('balance_usdt').default(0),
  lockedMargin: integer('locked_margin').default(0),
  unrealizedPnl: integer('unrealized_pnl').default(0),
});

export const decisions = pgTable('decisions', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id).notNull(),
  symbol: text('symbol').notNull(),
  side: text('side').notNull(),
  amountUsdt: integer('amount_usdt').notNull(),
  engineId: text('engine_id').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  decisionData: jsonb('decision_data'),
});

export const circuitBreakers = pgTable('circuit_breakers', {
  userId: text('user_id').references(() => users.id).primaryKey(),
  active: boolean('active').default(false).notNull(),
});

export const riskSettings = pgTable('risk_settings', {
  userId: text('user_id').references(() => users.id).primaryKey(),
  maxDailyDrawdownPct: integer('max_daily_drawdown_pct').notNull(),
  maxPositionSizeUsdt: integer('max_position_size_usdt').notNull(),
  defaultStopLossPct: integer('default_stop_loss_pct').notNull(),
  defaultTakeProfitPct: integer('default_take_profit_pct').notNull(),
  stealthMode: boolean('stealth_mode').default(true).notNull(),
  autoKillSwitchEnabled: boolean('auto_kill_switch_enabled').default(true).notNull(),
  shariahGuardEnabled: boolean('shariah_guard_enabled').default(true).notNull(),
});

export const auditLogs = pgTable('audit_logs', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id).notNull(),
  timestamp: timestamp('timestamp').defaultNow().notNull(),
  action: text('action').notNull(),
  status: text('status').notNull(),
  details: text('details').notNull(),
  correlationId: text('correlation_id').notNull(),
  integrityHash: text('integrity_hash').notNull(),
});

export const userSettings = pgTable('user_settings', {
  userId: text('user_id').references(() => users.id).primaryKey(),
  executionMode: text('execution_mode').default('Paper').notNull(),
  liveModeConfirmed: boolean('live_mode_confirmed').default(false).notNull(),
  complianceMode: text('compliance_mode').default('Islamic').notNull(),
});

export const vault = pgTable('vault', {
  userId: text('user_id').references(() => users.id).notNull(),
  service: text('service').notNull(),
  apiKey: text('api_key').notNull(),
  apiSecret: text('api_secret').notNull(),
  apiPassphrase: text('api_passphrase'),
}, (t) => ({ pk: primaryKey(t.userId, t.service) }));


export const strategies = pgTable('strategies', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id).notNull(),
  strategyName: text('strategy_name').notNull(),
  status: text('status').notNull(),
  version: integer('version').notNull(),
  config: jsonb('config').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const engines = pgTable('engines', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id).notNull(),
  engineId: text('engine_id').notNull(),
  status: text('status').notNull(),
  uptimeSeconds: integer('uptime_seconds').default(0).notNull(),
  strategy: text('strategy'),
  asset: text('asset'),
  amount: integer('amount').default(0).notNull(),
  leverage: integer('leverage').default(1).notNull(),
});
