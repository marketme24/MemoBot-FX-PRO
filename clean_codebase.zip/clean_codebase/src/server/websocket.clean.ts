import { WebSocket, WebSocketServer } from "ws";

export const wss = new WebSocketServer({ noServer: true });
const clients = new Set<WebSocket>();

wss.on("connection", (ws: WebSocket) => {
  clients.add(ws);

  ws.on("message", (data: any) => {
    try {
      const msg = data.toString();
      if (msg === "ping") {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send("pong");
        }
      }
    } catch (e) {
      // ignore
    }
  });

  ws.on("close", () => {
    clients.delete(ws);
  });

  ws.on("error", () => {
    clients.delete(ws);
  });
});

export function broadcastEvent(payload: Record<string, any>) {
  const message = JSON.stringify(payload);
  clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(message);
    }
  });
}
