import { Application, Request, Response } from "express";
import { GoogleGenAI } from "@google/genai";
import { authenticateToken } from "../auth";

export function setupSocialRoutes(app: Application) {
  app.post("/api/social/generate", authenticateToken, async (req: Request, res: Response) => {
    const { platform, campaignType, targetAudience, customContext, includePic } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    let imageUrl: string | undefined = undefined;
    if (includePic) {
      const visualCategories: Record<string, string> = {
        "Twitter/X": "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&q=80", // Cyberpunk grid graph
        "LinkedIn": "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80", // Financial analysis board
        "Reddit": "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80", // Abstract premium waves
        "Telegram": "https://images.unsplash.com/photo-1642790106117-e829e14a795f?w=800&q=80", // Glowing obsidian crypto nodes
        "Discord": "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?w=800&q=80", // Server lines & node networks
        "Email": "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&q=80", // Glowing abstract circuits
        "SMS": "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?w=800&q=80", // High-tech tech grid
        "Instagram": "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80", // Abstract clean art
        "TikTok": "https://images.unsplash.com/photo-1642790106117-e829e14a795f?w=800&q=80", // Glowing lights
        "Facebook": "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&q=80" // Analytics board
      };
      imageUrl = visualCategories[platform] || "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=800&q=80";
    }

    // Elegant fallback content generator in case API key is missing or invalid
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      let fallbackContent = `⚡ MemoBot Intelligence Outbound: Join our 100% Shariah-compliant high-frequency trading desk. Spot execution, zero leverage, maximum discipline. Let's discuss organic trading alpha.`;
      if (platform === "LinkedIn") {
        fallbackContent = `Respected Colleague,\n\nI noticed your focus on Islamic finance and ethical capital management. We have integrated a compliant, spot-only algorithmic engine that avoids leverage and Riba. We'd love to share our audit reports for institutional review.\n\nWarm regards,\nMemoBot Core Team`;
      } else if (platform === "Reddit") {
        fallbackContent = `[Discussion] Why spot-only quantitative engines out-perform leveraged derivatives in high-volatility regimes. Complete audit trails of our multi-tenant memory ledger and low-latency ring buffer. Free from futures rollover financing fees.`;
      }
      return res.json({ content: fallbackContent, imageUrl });
    }

    try {
      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: { "User-Agent": "aistudio-build" }
        }
      });

      const prompt = `You are the chief organic growth manager of MemoBot, an elite algorithmic and portfolio intelligence platform.
Generate a high-converting, non-paid, organic approach post or message suited for ${platform}.
Campaign Type: ${campaignType}
Target Audience: ${targetAudience}
Context / Highlights to include: ${customContext || "Spot-only trading, low-latency execution, Shariah (Islamic) compliant zero-riba, zero-leverage, distributed audit tracing"}

Tone guidelines:
- Professional, value-first, elite, highly authoritative yet welcoming.
- Strictly avoid generic AI words like 'supercharge', 'empower', 'revolutionize', 'delve', or 'testament'.
- Adapt style perfectly to the channel (e.g., informative & analytical for Reddit, respectful & institutional for LinkedIn, short & punchy with hashtags for Twitter/X).
- Keep it highly scannable, natural, and realistic for a human marketing genius.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are a world-class growth-marketing strategist specializing in organic inbound trading communities and high-net-worth algorithmic outreach."
        }
      });

      const content = response.text || "No signal resolved.";
      res.json({ content, imageUrl });
    } catch (err: any) {
      console.error("Gemini Social Generation Error:", err?.message || err);
      res.status(500).json({ error: "Failed to generate social intelligence content." });
    }
  });
}
