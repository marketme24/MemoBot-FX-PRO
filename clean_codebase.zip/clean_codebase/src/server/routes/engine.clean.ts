import { Application, Request, Response } from "express";
import { db } from "../../db";
import { broadcastEvent } from "../websocket";
import { authenticateToken } from "../auth";
import { engines, userSettings, vault } from "../../db/schema";
import { eq, and } from "drizzle-orm";
import { db as memDb, saveDB } from "../db";

const SEED_ENGINES = [
  { id: "ENG-001", name: "Quant Alpha", nickname: "RIGEL (LAM000R)", subtitle: "Manual Scalper Engine", theme: "rigel", strategy: "FAST SCALPER", asset: "BTCUSDT", amount: 100 },
  { id: "ENG-002", name: "Market Hunter", nickname: "SIRIUS (L000L)", subtitle: "Full Auto Swarm Engine (AI)", theme: "sirius", strategy: "AI SWARMconsensus", asset: "ETHUSDT", amount: 250 },
  { id: "ENG-003", name: "Trend Intelligence", nickname: "CANOPUS (OOOKA)", subtitle: "Hybrid Margin Balancer", theme: "canopus", strategy: "TREND BALANCER", asset: "SOLUSDT", amount: 50 },
  { id: "ENG-004", name: "Arbitrage Swarm", nickname: "Gemini", subtitle: "Statistical Arbitrage Core", theme: "gemini", strategy: "STAT ARBITRAGE", asset: "BNBUSDT", amount: 500 },
  { id: "ENG-005", name: "Shariah Guard", nickname: "Halal", subtitle: "Islamic Compliance Auditor", theme: "halal", strategy: "CONSERVATIVE COMPLIANT", asset: "ADAUSDT", amount: 75 },
  { id: "ENG-006", name: "Binance Feed", nickname: "Binance Feed", subtitle: "BINANCE FEED", theme: "binance", strategy: "BINANCE SWIFT", asset: "BTCUSDT", amount: 200 },
  { id: "ENG-007", name: "KuCoin Feed", nickname: "KuCoin Feed", subtitle: "KUCOIN FEED", theme: "kucoin", strategy: "KUCOIN SPREAD", asset: "ETHUSDT", amount: 80 },
  { id: "ENG-008", name: "OKX Feed", nickname: "OKX Feed", subtitle: "OKX FEED", theme: "okx", strategy: "OKX VOLATILITY", asset: "SOLUSDT", amount: 140 },
  { id: "ENG-009", name: "Bybit Feed", nickname: "Bybit Feed", subtitle: "BYBIT FEED", theme: "bybit", strategy: "BYBIT FLOW", asset: "BNBUSDT", amount: 160 },
  { id: "ENG-010", name: "Thread Worker", nickname: "Thread Worker", subtitle: "THREAD WORKER", theme: "thread", strategy: "QUANT SHIELD", asset: "SOLUSDT", amount: 120 },
  { id: "ENG-011", name: "Bybit Slot 2", nickname: "Bybit Slot 2", subtitle: "Bybit Engine Slot 2", theme: "bybit", strategy: "FAST SCALPER", asset: "ETHUSDT", amount: 100 },
  { id: "ENG-012", name: "Bybit Slot 3", nickname: "Bybit Slot 3", subtitle: "Bybit Engine Slot 3", theme: "bybit", strategy: "TREND BALANCER", asset: "SOLUSDT", amount: 150 },
  { id: "MEMOBOT", name: "Decrypt Gateway", nickname: "MEMOBOT", subtitle: "DECRYPT GATEWAY", theme: "memobot", strategy: "AI NATURAL SENTIMENT", asset: "BTCUSDT", amount: 150 },
  { id: "MEMOCODEX", name: "Decrypt Codes", nickname: "MEMOCODEX", subtitle: "DECRYPT CODES", theme: "memocodex", strategy: "WORKSPACE BLOCKCHAIN", asset: "ETHUSDT", amount: 300 }
];

async function ensureEnginesSeeded(userId: string) {
  // 1. Seed memory db
  if (!memDb.engines) memDb.engines = {};
  if (!memDb.engines[userId] || Object.keys(memDb.engines[userId]).length === 0) {
    memDb.engines[userId] = {};
    SEED_ENGINES.forEach(eng => {
      memDb.engines[userId][eng.id] = {
        engine_id: eng.id,
        display_name: eng.name,
        nickname: eng.nickname,
        subtitle: eng.subtitle,
        theme: eng.theme,
        status: "Stopped",
        uptime_seconds: 0,
        current_stage_idx: 0,
        latency_ms: 12,
        cpu_load: 0,
        memory_mb: 20,
        strategy: eng.strategy,
        asset: eng.asset,
        amount: eng.amount,
        leverage: 1,
        runtime_hours: 0,
        last_tick: Date.now()
      };
    });
    saveDB();
  }

  // 2. Seed Drizzle DB
  try {
    const existing = await db.select().from(engines).where(eq(engines.userId, userId));
    if (existing.length === 0) {
      for (const eng of SEED_ENGINES) {
        await db.insert(engines).values({
          id: `${userId}_${eng.id}`,
          userId,
          engineId: eng.id,
          status: "Stopped",
          uptimeSeconds: 0,
          strategy: eng.strategy,
          asset: eng.asset,
          amount: eng.amount,
          leverage: 1
        }).catch(() => {});
      }
    }
  } catch (err) {
    console.warn("Failed to check or seed engines in Drizzle DB:", err);
  }
}

export function setupEngineRoutes(app: Application) {
  app.get("/api/v1/engine/status", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    await ensureEnginesSeeded(userId);
    
    // Check for any active exchange keys in memDb or DB vault
    const supportedExchanges = ["Binance", "KuCoin", "OKX", "Bybit"];
    let hasExchangeKeys = false;
    for (const ex of supportedExchanges) {
      if (memDb.vault[userId]?.[ex]?.apiKey) {
        hasExchangeKeys = true;
        break;
      }
    }

    if (!hasExchangeKeys) {
      try {
        const v = await db.select().from(vault).where(eq(vault.userId, userId));
        const activeExchanges = v.filter(item => supportedExchanges.includes(item.service) && item.apiKey);
        if (activeExchanges.length > 0) {
          hasExchangeKeys = true;
          if (!memDb.vault[userId]) memDb.vault[userId] = {};
          activeExchanges.forEach(item => {
            memDb.vault[userId][item.service] = { 
              apiKey: item.apiKey, 
              apiSecret: item.apiSecret, 
              apiPassphrase: item.apiPassphrase || "" 
            };
          });
        }
      } catch (e) {}
    }

    const settings = await db.select().from(userSettings).where(eq(userSettings.userId, userId));
    const s = settings[0];
    
    let mode = s?.executionMode || memDb.execution_mode[userId];
    if (!mode) {
      mode = hasExchangeKeys ? "Live" : "Paper";
    }

    const liveConfirmed = mode === "Live" ? true : Boolean(s?.liveModeConfirmed);

    res.json({
      status: "Running",
      mode: mode,
      live_mode_confirmed: liveConfirmed,
      compliance_mode: s?.complianceMode || memDb.compliance_mode[userId] || "Islamic"
    });
  });

  app.post("/api/v1/engine/status", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const { engine_id, status } = req.body;
    const cid = req.headers["x-correlation-id"] as string;

    const engine = await db.select().from(engines).where(and(eq(engines.userId, userId), eq(engines.engineId, engine_id)));
    
    if (engine.length > 0) {
      await db.update(engines).set({
        status: status,
        uptimeSeconds: status === "Running" ? 1 : 0
      }).where(and(eq(engines.userId, userId), eq(engines.engineId, engine_id)));

      broadcastEvent({
        event: "ENGINE_STATUS_CHANGED",
        engine_id,
        status,
        cid
      });
    }

    res.json({ success: true, engine_id, status });
  });

  app.post("/api/v1/engine/mode", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const { mode } = req.body;
    const cid = req.headers["x-correlation-id"] as string;

    const setObj: any = { executionMode: mode };
    if (mode === "Paper") {
      setObj.liveModeConfirmed = false;
    } else if (mode === "Live") {
      setObj.liveModeConfirmed = true;
    }

    await db.insert(userSettings).values({ userId, ...setObj }).onConflictDoUpdate({
      target: userSettings.userId,
      set: setObj
    });

    memDb.execution_mode[userId] = mode;
    saveDB();

    broadcastEvent({
      event: "ENGINE_MODE_CHANGED",
      mode,
      cid
    });

    const s = await db.select().from(userSettings).where(eq(userSettings.userId, userId));
    res.json({ success: true, mode, live_mode_confirmed: s[0]?.liveModeConfirmed ?? (mode === "Live") });
  });

  app.post("/api/v1/engine/compliance-mode", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const rawMode = req.body.mode || req.body.compliance_mode || req.body.complianceMode;
    const compliance_mode = rawMode === "Commercial" ? "Commercial" : "Islamic";
    const cid = req.headers["x-correlation-id"] as string;

    await db.insert(userSettings).values({ userId, complianceMode: compliance_mode }).onConflictDoUpdate({
      target: userSettings.userId,
      set: { complianceMode: compliance_mode }
    });

    if (!memDb.compliance_mode) {
      memDb.compliance_mode = {};
    }
    memDb.compliance_mode[userId] = compliance_mode;
    saveDB();

    broadcastEvent({
      event: "COMPLIANCE_MODE_CHANGED",
      compliance_mode,
      cid
    });

    res.json({
      status: "SUCCESS",
      active_framework: rawMode || compliance_mode,
      shariah_validator: compliance_mode === "Islamic" ? "AAOIFI_STANDARD_21_STRICT" : "UNRESTRICTED",
      compliance_mode
    });
  });

  app.post("/api/v1/engine/risk-parameters", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const maxRisk = req.body.max_risk ?? req.body.maxRisk ?? 1.0;
    const cid = (req.headers["x-correlation-id"] as string) || "CORR-RISK-PATCH";

    broadcastEvent({
      event: "RISK_PARAMETERS_PATCHED",
      max_risk: maxRisk,
      cid
    });

    res.json({
      status: "SUCCESS",
      applied_parameter: Number(maxRisk),
      pipeline_stage: "RSK_KERNEL_LOCK_ACTIVE",
      telemetry_verification: "VERIFIED"
    });
  });

  app.post("/api/v1/engine/confirm-live", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    await db.insert(userSettings).values({ userId, liveModeConfirmed: true }).onConflictDoUpdate({
        target: userSettings.userId,
        set: { liveModeConfirmed: true }
    });
    res.json({ success: true, live_mode_confirmed: true });
  });

  app.post("/api/v1/engine/kill", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const cid = req.headers["x-correlation-id"] as string;

    await db.update(engines).set({ status: "Stopped", uptimeSeconds: 0 }).where(eq(engines.userId, userId));
    
    broadcastEvent({
      event: "ENGINES_KILLED",
      cid
    });
    
    res.json({ success: true });
  });

  app.get("/api/v1/engine-monitoring/overview", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    await ensureEnginesSeeded(userId);
    const userEngines = await db.select().from(engines).where(eq(engines.userId, userId));
    const engMap: any = {};
    userEngines.forEach(e => engMap[e.engineId] = e);
    res.json({
      engines: engMap
    });
  });

  app.get("/api/v1/engine-monitoring/:engine_id/details", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    await ensureEnginesSeeded(userId);
    const engineId = req.params.engine_id;
    const engine = await db.select().from(engines).where(and(eq(engines.userId, userId), eq(engines.engineId, engineId)));
    
    if (engine.length === 0) {
      return res.status(404).json({ error: "Engine ID mismatch." });
    }
    res.json(engine[0]);
  });

  app.post("/api/v1/engine-monitoring/:engine_id/configure", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    await ensureEnginesSeeded(userId);
    const engineId = req.params.engine_id;
    const { strategy, asset, amount, leverage } = req.body;

    const engine = await db.select().from(engines).where(and(eq(engines.userId, userId), eq(engines.engineId, engineId)));
    if (engine.length === 0) {
      return res.status(404).json({ error: "Engine ID mismatch." });
    }

    if (engineId === "ENG-002") {
      return res.status(403).json({ error: "Configuration Rejected: Neural AI layer cannot be modified manually." });
    }

    const setObj: any = {};
    if (strategy !== undefined) setObj.strategy = strategy;
    if (asset !== undefined) setObj.asset = asset;
    if (amount !== undefined) setObj.amount = Number(amount);
    if (leverage !== undefined) setObj.leverage = Number(leverage);
    
    await db.update(engines).set(setObj).where(and(eq(engines.userId, userId), eq(engines.engineId, engineId)));
    
    const updatedEngine = await db.select().from(engines).where(and(eq(engines.userId, userId), eq(engines.engineId, engineId)));

    res.json({ success: true, engine: updatedEngine[0] });
  });
}
