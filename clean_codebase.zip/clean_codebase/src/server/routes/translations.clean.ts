import { Express, Request, Response } from "express";
import { db, saveDB } from "../db";
import { authenticateToken } from "../auth";

export function setupTranslationRoutes(app: Express) {
  // Get all custom translations
  app.get("/api/translations", (req: Request, res: Response) => {
    try {
      const translations = db.translations || {};
      return res.json({ success: true, data: translations });
    } catch (e: any) {
      return res.status(500).json({ success: false, message: e.message });
    }
  });

  // Save / update a single translation pair
  app.post("/api/translations", (req: Request, res: Response) => {
    try {
      const { english, arabic } = req.body;
      if (!english || !arabic) {
        return res.status(400).json({ success: false, message: "Both English and Arabic fields are required" });
      }

      if (!db.translations) {
        db.translations = {};
      }

      const cleanEn = String(english).trim();
      const cleanAr = String(arabic).trim();

      db.translations[cleanEn] = cleanAr;
      saveDB();

      return res.json({ success: true, message: "Translation saved", data: { english: cleanEn, arabic: cleanAr } });
    } catch (e: any) {
      return res.status(500).json({ success: false, message: e.message });
    }
  });

  // Delete a translation key
  app.delete("/api/translations/:key", (req: Request, res: Response) => {
    try {
      const key = decodeURIComponent(req.params.key || "").trim();
      if (!key) {
        return res.status(400).json({ success: false, message: "Key parameter is required" });
      }

      if (db.translations && db.translations[key]) {
        delete db.translations[key];
        saveDB();
      }

      return res.json({ success: true, message: "Translation removed" });
    } catch (e: any) {
      return res.status(500).json({ success: false, message: e.message });
    }
  });

  // Batch import translations
  app.post("/api/translations/import", (req: Request, res: Response) => {
    try {
      const { translations } = req.body;
      if (!translations || typeof translations !== "object") {
        return res.status(400).json({ success: false, message: "Invalid translations object" });
      }

      if (!db.translations) {
        db.translations = {};
      }

      let count = 0;
      for (const [k, v] of Object.entries(translations)) {
        if (typeof k === "string" && typeof v === "string" && k.trim() && v.trim()) {
          db.translations[k.trim()] = v.trim();
          count++;
        }
      }

      saveDB();
      return res.json({ success: true, count, message: `Successfully imported ${count} translations` });
    } catch (e: any) {
      return res.status(500).json({ success: false, message: e.message });
    }
  });

  // Reset all custom overrides
  app.post("/api/translations/reset", (req: Request, res: Response) => {
    try {
      db.translations = {};
      saveDB();
      return res.json({ success: true, message: "All custom translations reset" });
    } catch (e: any) {
      return res.status(500).json({ success: false, message: e.message });
    }
  });
}
