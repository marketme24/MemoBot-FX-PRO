import { Application, Request, Response } from "express";
import { db } from "../../db";
import { authenticateToken } from "../auth";
import { broadcastEvent } from "../websocket";
import { riskSettings, auditLogs } from "../../db/schema";
import { eq } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";

export function setupRiskRoutes(app: Application) {
  console.log("Registering risk routes");
  app.get("/api/v1/risk/settings", authenticateToken, async (req: Request, res: Response) => {
    const userId = req.body.authenticated_user_id;
    const settings = await db.select().from(riskSettings).where(eq(riskSettings.userId, userId));
    
    if (settings.length === 0) {
      const defaultSettings = {
        userId,
        maxDailyDrawdownPct: 25,
        maxPositionSizeUsdt: 1000,
        defaultStopLossPct: 1,
        defaultTakeProfitPct: 1,
        stealthMode: true,
        autoKillSwitchEnabled: true,
        shariahGuardEnabled: true
      };
      await db.insert(riskSettings).values(defaultSettings);
      return res.json(defaultSettings);
    }
    
    res.json(settings[0]);
  });

  app.post("/api/v1/risk/settings", authenticateToken, async (req: Request, res: Response) => {
    console.log("Risk route POST received");
    const userId = req.body.authenticated_user_id;
    console.log("Saving risk settings for userId:", userId);
    const {
      maxDailyDrawdownPct, max_daily_drawdown_pct,
      maxPositionSizeUsdt, max_position_size_usdt,
      defaultStopLossPct, default_stop_loss_pct,
      defaultTakeProfitPct, default_take_profit_pct,
      stealthMode, stealth_mode,
      autoKillSwitchEnabled, auto_kill_switch_enabled,
      shariahGuardEnabled, shariah_guard_enabled
    } = req.body;

    const valDrawdown = maxDailyDrawdownPct ?? max_daily_drawdown_pct;
    const valPosSize = maxPositionSizeUsdt ?? max_position_size_usdt;
    const valStopLoss = defaultStopLossPct ?? default_stop_loss_pct;
    const valTakeProfit = defaultTakeProfitPct ?? default_take_profit_pct;
    const valStealth = stealthMode ?? stealth_mode;
    const valKillSwitch = autoKillSwitchEnabled ?? auto_kill_switch_enabled;
    const valShariah = shariahGuardEnabled ?? shariah_guard_enabled;

    const values = {
      userId,
      maxDailyDrawdownPct: (valDrawdown !== undefined && isFinite(Number(valDrawdown))) ? Number(valDrawdown) : 25,
      maxPositionSizeUsdt: (valPosSize !== undefined && isFinite(Number(valPosSize))) ? Number(valPosSize) : 1000,
      defaultStopLossPct: (valStopLoss !== undefined && isFinite(Number(valStopLoss))) ? Number(valStopLoss) : 1,
      defaultTakeProfitPct: (valTakeProfit !== undefined && isFinite(Number(valTakeProfit))) ? Number(valTakeProfit) : 1,
      stealthMode: Boolean(valStealth),
      autoKillSwitchEnabled: Boolean(valKillSwitch),
      shariahGuardEnabled: Boolean(valShariah)
    };

    try {
      await db.insert(riskSettings).values(values).onConflictDoUpdate({
        target: riskSettings.userId,
        set: values
      });

      const cid = req.headers["x-correlation-id"] as string || "cid-risk-001";
      await db.insert(auditLogs).values({
        id: "AUD-" + uuidv4(),
        userId,
        action: "RISK_MATRIX_UPDATED",
        status: "SUCCESS",
        details: `Risk matrix reconfigured: Drawdown Limit ${valDrawdown}%, Max Pos $${valPosSize}`,
        correlationId: cid,
        integrityHash: "VERIFIED"
      });

      broadcastEvent({
        event: "RISK_SETTINGS_CHANGED",
        settings: values,
        cid
      });

      res.json({
        success: true,
        message: "Risk matrix protocols successfully saved and applied across engines.",
      });
    } catch (error: any) {
      console.error("Error saving risk settings:", error);
      res.status(500).json({ success: false, message: error.message || "Internal server error" });
    }
  });
}
