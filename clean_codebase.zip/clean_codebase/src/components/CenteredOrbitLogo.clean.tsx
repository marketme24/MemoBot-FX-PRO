import React from "react";
import { motion } from "motion/react";

export const CenteredOrbitLogo: React.FC = () => {
  // Rings scaled up by 15% (original: 160, 140, 120, 100, 80, 60)
  const rings = [
    { size: 184, duration: 35, color: "#ff006e", delay: 0, tilt: 15, opacity: 0.1 },
    { size: 161, duration: 22, color: "#00f2ff", delay: -2, tilt: -10, opacity: 0.15 },
    { size: 138, duration: 28, color: "#3a86ff", delay: -5, tilt: 25, opacity: 0.1 },
    { size: 115, duration: 18, color: "#a855f7", delay: -8, tilt: -20, opacity: 0.2 },
    { size: 92, duration: 25, color: "#00e676", delay: -10, tilt: 5, opacity: 0.15 },
    { size: 69, duration: 14, color: "#ff003c", delay: -12, tilt: 30, opacity: 0.2 },
  ];

  const particles = Array.from({ length: 12 }).map((_, i) => ({
    id: i,
    size: Math.random() * 2 + 1,
    x: Math.random() * 100,
    y: Math.random() * 100,
    duration: Math.random() * 10 + 10,
    delay: Math.random() * -20,
  }));

  return (
    <div className="relative flex items-center justify-center w-full h-[207px] overflow-hidden bg-transparent perspective-[1000px] my-4 select-none">
      {/* Dynamic Background Glow */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(250,31,78,0.06)_0%,transparent_70%)]" />

      {/* Floating Particles */}
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full bg-white/20"
          style={{
            width: p.size,
            height: p.size,
            left: `${p.x}%`,
            top: `${p.y}%`,
          }}
          animate={{
            opacity: [0.1, 0.4, 0.1],
            scale: [1, 1.5, 1],
            y: [0, -30, 0],
            x: [0, 10, 0],
          }}
          transition={{
            duration: p.duration,
            repeat: Infinity,
            delay: p.delay,
            ease: "easeInOut",
          }}
        />
      ))}

      {/* Scanning Laser Line */}
      <motion.div
        className="absolute w-full h-[1px] bg-[#FA1F4E]/25 z-20 shadow-[0_0_8px_rgba(250,31,78,0.4)]"
        animate={{
          top: ["10%", "90%", "10%"],
          opacity: [0.2, 0.5, 0.2],
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Orbit Container */}
      <div className="relative flex items-center justify-center w-full h-full preserve-3d">
        {rings.map((ring, i) => (
          <div 
            key={i} 
            className="absolute"
            style={{ transform: `rotateX(${ring.tilt}deg) rotateY(${ring.tilt / 2}deg)` }}
          >
            <motion.div
              className="relative rounded-full border border-white/5"
              style={{
                width: ring.size,
                height: ring.size,
                borderColor: `${ring.color}${Math.floor(ring.opacity * 255).toString(16).padStart(2, '0')}`,
              }}
              animate={{ rotate: 360 }}
              transition={{
                duration: ring.duration,
                repeat: Infinity,
                ease: "linear",
                delay: ring.delay,
              }}
            >
              {/* Orbital Node */}
              <div
                className="absolute w-1.5 h-1.5 rounded-full"
                style={{
                  top: "0%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  backgroundColor: ring.color,
                  boxShadow: `0 0 10px ${ring.color}, 0 0 20px ${ring.color}88`,
                }}
              />
              
              {/* Subtle Trailing Line Effect */}
              <div 
                className="absolute inset-0 rounded-full border-[0.5px] border-transparent border-t-inherit opacity-30"
                style={{ borderColor: ring.color }}
              />
            </motion.div>
          </div>
        ))}

        {/* Central Core Logo scaled up by 15% (h-20/80px * 1.15 = 92px) */}
        <motion.div 
          className="relative z-30 flex flex-col items-center justify-center"
          animate={{
            scale: [0.98, 1.02, 0.98],
            filter: ["drop-shadow(0 0 15px rgba(250,31,78,0.3))", "drop-shadow(0 0 25px rgba(250,31,78,0.5))", "drop-shadow(0 0 15px rgba(250,31,78,0.3))"]
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        >
          <div className="relative group cursor-pointer">
            <img 
              src="/MemoBot.png" 
              alt="MemoBot Logo" 
              className="h-[92px] w-auto object-contain mix-blend-screen relative z-10"
              referrerPolicy="no-referrer"
            />
            {/* Inner Glow Pulse */}
            <motion.div 
              className="absolute inset-0 bg-[#FA1F4E]/20 blur-2xl rounded-full -z-10"
              animate={{
                opacity: [0.2, 0.5, 0.2],
                scale: [0.8, 1.2, 0.8]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
};
