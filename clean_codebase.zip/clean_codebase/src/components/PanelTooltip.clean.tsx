import React, { useState } from "react";
import { HelpCircle } from "lucide-react";

interface PanelTooltipProps {
  title: string;
  description: string;
  tip?: string;
  position?: "top-right" | "top-left" | "bottom-right" | "bottom-left";
}

export const PanelTooltip: React.FC<PanelTooltipProps> = ({
  title,
  description,
  tip,
  position = "top-right"
}) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative inline-block text-left">
      <button
        type="button"
        onMouseEnter={() => setIsOpen(true)}
        onMouseLeave={() => setIsOpen(false)}
        onClick={() => setIsOpen(!isOpen)}
        aria-label={`Help for ${title}`}
        className="p-1 rounded-full text-[#FA1F4E] hover:text-white hover:bg-[#FA1F4E]/20 transition-all cursor-pointer focus:outline-none"
      >
        <HelpCircle className="w-4 h-4" />
      </button>

      {isOpen && (
        <div
          className={`absolute z-50 w-64 p-3 bg-[#0d0e12] border border-[#FA1F4E]/40 rounded-md shadow-2xl text-xs font-sans text-gray-200 transition-opacity duration-150 ${
            position === "top-right" ? "right-0 top-6" :
            position === "top-left" ? "left-0 top-6" :
            position === "bottom-right" ? "right-0 bottom-6" :
            "left-0 bottom-6"
          }`}
          onMouseEnter={() => setIsOpen(true)}
          onMouseLeave={() => setIsOpen(false)}
        >
          <div className="font-bold text-[#FA1F4E] border-b border-[#FA1F4E]/30 pb-1 mb-1.5 flex items-center justify-between">
            <span>{title}</span>
            <span className="text-[9px] uppercase tracking-wider text-gray-400 font-mono">Guide</span>
          </div>
          <p className="text-[11px] leading-relaxed text-gray-300">{description}</p>
          {tip && (
            <div className="mt-2 pt-1.5 border-t border-[#FA1F4E]/20 text-[10px] text-amber-400 italic">
              <strong>Quick Tip:</strong> {tip}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
