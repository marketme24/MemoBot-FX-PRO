import React from "react";
import { motion } from "motion/react";

interface OrbitEmblemProps {
  size?: number;
  className?: string;
}

export const OrbitEmblem: React.FC<OrbitEmblemProps> = ({ size = 64, className = "" }) => {
  const rings = [
    { sizePercent: 92, duration: 16, color: "#ff006e", delay: 0, tilt: 15 },
    { sizePercent: 74, duration: 10, color: "#00f2ff", delay: -2, tilt: -15 },
    { sizePercent: 56, duration: 14, color: "#00e676", delay: -4, tilt: 25 },
  ];

  return (
    <div 
      className={`relative flex items-center justify-center overflow-hidden rounded-xl bg-[#07090e] border border-[#1a1d26] shadow-2xl ${className}`}
      style={{ width: size, height: size }}
    >
      {/* Ambient Pulsing Core Glow */}
      <motion.div 
        className="absolute inset-0 bg-radial-gradient from-[#FA1F4E]/25 via-cyan-500/10 to-transparent blur-md pointer-events-none"
        animate={{
          opacity: [0.3, 0.7, 0.3],
          scale: [0.9, 1.1, 0.9]
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />

      {/* Orbital Rotating Rings */}
      <div className="relative flex items-center justify-center w-full h-full">
        {rings.map((ring, idx) => (
          <div
            key={idx}
            className="absolute flex items-center justify-center"
            style={{
              width: `${ring.sizePercent}%`,
              height: `${ring.sizePercent}%`,
              transform: `rotateX(${ring.tilt}deg) rotateY(${ring.tilt / 2}deg)`
            }}
          >
            <motion.div
              className="relative w-full h-full rounded-full border border-dashed"
              style={{
                borderColor: `${ring.color}60`
              }}
              animate={{ rotate: 360 }}
              transition={{
                duration: ring.duration,
                repeat: Infinity,
                ease: "linear",
                delay: ring.delay
              }}
            >
              {/* Glowing Orbit Node Particle */}
              <div 
                className="absolute w-2 h-2 rounded-full -top-1 left-1/2 -translate-x-1/2"
                style={{
                  backgroundColor: ring.color,
                  boxShadow: `0 0 8px ${ring.color}, 0 0 14px ${ring.color}`
                }}
              />
            </motion.div>
          </div>
        ))}

        {/* Central Core MemoBot Image */}
        <motion.div
          className="relative z-10 flex items-center justify-center p-1.5"
          animate={{
            scale: [0.95, 1.05, 0.95]
          }}
          transition={{
            duration: 3.5,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <img 
            src="/MemoBot.png" 
            alt="MemoBot Orbit Logo" 
            className="w-10 h-10 object-contain mix-blend-screen drop-shadow-[0_0_10px_rgba(250,31,78,0.6)]"
          />
        </motion.div>
      </div>

      {/* Scanning Laser Line */}
      <motion.div
        className="absolute w-full h-[1px] bg-[#FA1F4E]/40 shadow-[0_0_6px_#FA1F4E] z-20 pointer-events-none"
        animate={{
          top: ["5%", "95%", "5%"],
          opacity: [0.2, 0.8, 0.2]
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
    </div>
  );
};
