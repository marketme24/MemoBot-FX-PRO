import React, { useState, useMemo } from "react";
import {
  Search,
  ArrowUpDown,
  ArrowUp,
  ArrowDown,
  Printer,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  LayoutGrid,
  List,
  Sparkles,
  Zap,
  Activity,
  Layers,
  Check
} from "lucide-react";
import { useLanguage } from "../../components/LanguageProvider";
import { OrderAuditRecord } from "./auditTypes";

interface HybridOrderMatrixProps {
  orders: OrderAuditRecord[];
  onPrintOrder: (order: OrderAuditRecord) => void;
}

type SortField = "timestamp" | "orderNumber" | "rawValue" | "latencyMs" | "symbol" | "status";
type SortDirection = "asc" | "desc";

export const HybridOrderMatrix: React.FC<HybridOrderMatrixProps> = ({
  orders,
  onPrintOrder,
}) => {
  const { t } = useLanguage();
  const [viewMode, setViewMode] = useState<"GRID" | "LIST">("GRID");
  const [activeFilter, setActiveFilter] = useState<string>("ALL");
  const [activeExchange, setActiveExchange] = useState<string>("ALL");
  const [activeCurrency, setActiveCurrency] = useState<string>("ALL");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedOrder, setSelectedOrder] = useState<OrderAuditRecord>(orders[0]);

  // Sorting
  const [sortField, setSortField] = useState<SortField>("timestamp");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
  };

  const filteredAndSorted = useMemo(() => {
    return orders
      .filter((o) => {
        const matchesSearch =
          o.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
          o.correlationId.toLowerCase().includes(searchTerm.toLowerCase()) ||
          o.symbol.toLowerCase().includes(searchTerm.toLowerCase()) ||
          o.engine.toLowerCase().includes(searchTerm.toLowerCase()) ||
          o.exchange.toLowerCase().includes(searchTerm.toLowerCase());

        const matchesStatus =
          activeFilter === "ALL" ||
          (activeFilter === "APPROVED" && o.status === "APPROVED") ||
          (activeFilter === "REJECTED" && o.status === "REJECTED") ||
          (activeFilter === "BUY" && o.side === "BUY") ||
          (activeFilter === "SELL" && o.side === "SELL");

        const matchesExchange = activeExchange === "ALL" || o.exchange.includes(activeExchange);
        const matchesCurrency = activeCurrency === "ALL" || o.symbol.includes(activeCurrency);

        return matchesSearch && matchesStatus && matchesExchange && matchesCurrency;
      })
      .sort((a, b) => {
        let diff = 0;
        if (sortField === "rawValue") diff = a.rawValue - b.rawValue;
        else if (sortField === "latencyMs") diff = a.latencyMs - b.latencyMs;
        else if (sortField === "orderNumber") diff = a.orderNumber.localeCompare(b.orderNumber);
        else if (sortField === "symbol") diff = a.symbol.localeCompare(b.symbol);
        else if (sortField === "status") diff = a.status.localeCompare(b.status);
        else diff = a.timestamp.localeCompare(b.timestamp);
        return sortDirection === "asc" ? diff : -diff;
      });
  }, [orders, searchTerm, activeFilter, activeExchange, activeCurrency, sortField, sortDirection]);

  return (
    <div className="bg-[#090b11] border border-[#1b1f2e] rounded-2xl p-5 space-y-4 shadow-xl">
      {/* Control Bar: Search + Filters + Layout Toggle + Sort Controls */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 border-b border-[#141724] pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#FA1F4E]/10 rounded-xl text-[#FA1F4E]">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black text-white uppercase tracking-wider font-aquire">
              {t("HYBRID ORDER TELEMETRY MATRIX")}
            </h2>
            <p className="text-xs text-[#8a8d9a]">
              {t("Sort, filter, and inspect verified spot orders across all engines.")}
            </p>
          </div>
        </div>

        {/* View Mode Toggle */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[#05070a] p-1 border border-[#1e2336] rounded-xl">
            <button
              onClick={() => setViewMode("GRID")}
              className={`px-3 py-1 text-xs font-black uppercase rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === "GRID"
                  ? "bg-[#FA1F4E] text-white shadow-[0_0_10px_rgba(250,31,78,0.4)]"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>{t("CARD MATRIX")}</span>
            </button>
            <button
              onClick={() => setViewMode("LIST")}
              className={`px-3 py-1 text-xs font-black uppercase rounded-lg flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === "LIST"
                  ? "bg-[#38bdf8] text-black font-black shadow-[0_0_10px_rgba(56,189,248,0.4)]"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>{t("STREAM VIEW")}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter and Sort Chips Ribbon */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0c0f18] border border-[#1e2336] p-3 rounded-xl">
        {/* Status / Side Filter Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          {["ALL", "APPROVED", "REJECTED", "BUY", "SELL"].map((filter) => (
            <button
              key={filter}
              onClick={() => setActiveFilter(filter)}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold uppercase transition-all cursor-pointer ${
                activeFilter === filter
                  ? "bg-[#FA1F4E] text-white shadow-sm"
                  : "text-slate-400 hover:text-white bg-[#05070a] border border-[#1e2336]"
              }`}
            >
              {t(filter)}
            </button>
          ))}
        </div>

        {/* Dropdowns + Search */}
        <div className="flex items-center gap-2 flex-wrap flex-1 justify-end">
          <select
            value={activeExchange}
            onChange={(e) => setActiveExchange(e.target.value)}
            className="bg-[#05070a] border border-[#242a3d] rounded-lg px-2.5 py-1 text-xs text-slate-300 focus:outline-none"
          >
            <option value="ALL">{t("ALL EXCHANGES")}</option>
            <option value="BINANCE">BINANCE</option>
            <option value="OKX">OKX</option>
            <option value="BYBIT">BYBIT</option>
            <option value="LMAX">LMAX FIX</option>
            <option value="KUCOIN">KUCOIN</option>
          </select>

          <select
            value={activeCurrency}
            onChange={(e) => setActiveCurrency(e.target.value)}
            className="bg-[#05070a] border border-[#242a3d] rounded-lg px-2.5 py-1 text-xs text-slate-300 focus:outline-none"
          >
            <option value="ALL">{t("ALL ASSETS")}</option>
            <option value="BTC">BTC</option>
            <option value="ETH">ETH</option>
            <option value="SOL">SOL</option>
            <option value="XAU">XAU GOLD</option>
            <option value="EUR">EUR/USD</option>
            <option value="ADA">ADA</option>
          </select>

          <div className="relative min-w-[180px]">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder={t("Filter orders...")}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-[#05070a] border border-[#242a3d] rounded-lg pl-8 pr-2.5 py-1 text-xs text-white placeholder-slate-500 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* RENDER VIEW: CARD MATRIX OR STREAM LIST */}
      {viewMode === "GRID" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredAndSorted.map((ord) => {
            const isSelected = selectedOrder?.id === ord.id;
            return (
              <div
                key={ord.id}
                onClick={() => setSelectedOrder(ord)}
                className={`bg-[#0c0f18] border p-4 rounded-xl space-y-3 cursor-pointer transition-all relative overflow-hidden ${
                  isSelected
                    ? "border-[#FA1F4E] bg-[#140b10] shadow-[0_0_15px_rgba(250,31,78,0.2)]"
                    : "border-[#1e2336] hover:border-slate-600"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-white font-black text-xs">{ord.orderNumber}</span>
                    <span
                      className={`px-1.5 py-0.5 rounded text-[8.5px] font-black uppercase ${
                        ord.side === "BUY" ? "bg-emerald-500/20 text-emerald-300" : "bg-purple-500/20 text-purple-300"
                      }`}
                    >
                      {ord.side}
                    </span>
                  </div>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[8.5px] font-bold uppercase ${
                      ord.status === "APPROVED" ? "bg-emerald-500/15 text-emerald-400" : "bg-rose-500/15 text-rose-400"
                    }`}
                  >
                    {ord.status === "APPROVED" ? <Check className="w-2.5 h-2.5" /> : <XCircle className="w-2.5 h-2.5" />}
                    {ord.status}
                  </span>
                </div>

                <div className="flex items-baseline justify-between">
                  <div>
                    <div className="text-white font-black text-sm">{ord.symbol}</div>
                    <div className="text-[10px] text-slate-400">{ord.engine}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-white font-bold text-xs">{ord.price}</div>
                    <div className="text-[10px] text-amber-300 font-bold">{ord.totalValue}</div>
                  </div>
                </div>

                <div className="pt-2 border-t border-[#1a1f30] flex items-center justify-between text-[9.5px]">
                  <span className="text-slate-500 font-mono">{ord.latencyMs}ms &bull; {ord.exchange}</span>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onPrintOrder(ord);
                    }}
                    className="px-2 py-0.5 bg-[#1b2234] hover:bg-[#FA1F4E] text-slate-300 hover:text-white rounded text-[8.5px] font-bold uppercase flex items-center gap-1 transition-all"
                  >
                    <Printer className="w-2.5 h-2.5" />
                    <span>{t("PASSPORT")}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-[#1e2336] bg-[#05070a]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#0c0f18] text-[#8a8d9a] uppercase text-[9px] border-b border-[#1e2336]">
              <tr>
                <th onClick={() => handleSort("orderNumber")} className="py-2.5 px-3 cursor-pointer hover:text-white">
                  {t("ORDER / TIME")}
                </th>
                <th onClick={() => handleSort("symbol")} className="py-2.5 px-3 cursor-pointer hover:text-white">
                  {t("PAIR / ENGINE")}
                </th>
                <th onClick={() => handleSort("rawValue")} className="py-2.5 px-3 cursor-pointer hover:text-white">
                  {t("PRICE / VALUE")}
                </th>
                <th onClick={() => handleSort("latencyMs")} className="py-2.5 px-3 cursor-pointer hover:text-white">
                  {t("LATENCY")}
                </th>
                <th onClick={() => handleSort("status")} className="py-2.5 px-3 cursor-pointer hover:text-white">
                  {t("STATUS")}
                </th>
                <th className="py-2.5 px-3 text-right">{t("ACTION")}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#141724]">
              {filteredAndSorted.map((ord) => (
                <tr
                  key={ord.id}
                  onClick={() => setSelectedOrder(ord)}
                  className={`hover:bg-[#111420] cursor-pointer transition-colors ${
                    selectedOrder?.id === ord.id ? "bg-[#161a29]" : ""
                  }`}
                >
                  <td className="py-2.5 px-3">
                    <div className="font-bold text-white">{ord.orderNumber}</div>
                    <div className="text-[9px] text-slate-400">{ord.timestamp}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-bold text-white">{ord.symbol} ({ord.side})</div>
                    <div className="text-[9px] text-[#38bdf8]">{ord.engine}</div>
                  </td>
                  <td className="py-2.5 px-3">
                    <div className="font-bold text-white">{ord.price}</div>
                    <div className="text-[9.5px] text-amber-300 font-bold">{ord.totalValue}</div>
                  </td>
                  <td className="py-2.5 px-3 text-[10px] font-mono text-[#00e676]">{ord.latencyMs}ms</td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-1.5 py-0.5 rounded text-[8.5px] font-bold uppercase ${
                        ord.status === "APPROVED" ? "bg-emerald-500/20 text-emerald-400" : "bg-rose-500/20 text-rose-400"
                      }`}
                    >
                      {ord.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onPrintOrder(ord);
                      }}
                      className="px-2 py-1 bg-[#1e2436] hover:bg-[#FA1F4E] text-slate-300 hover:text-white rounded text-[9px] font-bold uppercase transition-all"
                    >
                      <Printer className="w-3 h-3 inline mr-1" />
                      {t("PRINT")}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Selected Order Micro-Inspection Panel */}
      {selectedOrder && (
        <div className="bg-[#05070a] border border-[#1e2336] p-3.5 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#FA1F4E]/15 text-[#FA1F4E] rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white">{selectedOrder.orderNumber}</span>
                <span className="text-slate-400 font-mono">[{selectedOrder.correlationId}]</span>
                <span className="text-emerald-400 font-bold text-[10px]">{selectedOrder.strategyName}</span>
              </div>
              <div className="text-slate-400 text-[10px] mt-0.5">
                {selectedOrder.riskGuard} &bull; Latency: {selectedOrder.latencyMs}ms &bull; Hash: {selectedOrder.hash.slice(0, 20)}...
              </div>
            </div>
          </div>

          <button
            onClick={() => onPrintOrder(selectedOrder)}
            className="px-3.5 py-1.5 bg-[#FA1F4E] hover:bg-[#FA1F4E]/90 text-white font-bold text-xs uppercase rounded-lg flex items-center gap-1.5 transition-all cursor-pointer shrink-0"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>{t("PRINT ORDER PASSPORT")}</span>
          </button>
        </div>
      )}
    </div>
  );
};
