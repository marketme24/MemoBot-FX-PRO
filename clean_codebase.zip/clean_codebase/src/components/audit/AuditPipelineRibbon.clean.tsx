import React from "react";
import { CheckCircle2, Zap, ArrowRight, ShieldCheck } from "lucide-react";
import { useLanguage } from "../../components/LanguageProvider";
import { NINE_STAGES } from "./auditTypes";

export const AuditPipelineRibbon: React.FC = () => {
  const { t } = useLanguage();

  return (
    <div className="bg-[#090b11] border border-[#1b1f2e] rounded-2xl p-4 space-y-3 shadow-lg">
      <div className="flex items-center justify-between text-xs font-black uppercase tracking-wider text-[#8a8d9a]">
        <div className="flex items-center gap-2">
          <Zap className="w-3.5 h-3.5 text-[#00e676]" />
          <span>{t("9-STAGE EXECUTION VERIFICATION PIPELINE")}</span>
        </div>
        <span className="text-[#00e676] font-mono text-[10px]">100% AUDITED SPOT SETTLEMENT</span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-2">
        {NINE_STAGES.map((stg, i) => (
          <div
            key={i}
            className="bg-[#0c0f18] border border-[#1e2336] p-2 rounded-xl flex flex-col justify-between hover:border-[#FA1F4E]/50 transition-all text-center group"
          >
            <div className="flex items-center justify-between text-[7.5px] text-[#8a8d9a] font-bold uppercase mb-1">
              <span>S{i + 1}</span>
              <CheckCircle2 className="w-2.5 h-2.5 text-[#00e676]" />
            </div>
            <div className="text-[8.5px] font-black text-white leading-snug truncate">
              {t(stg.replace(/^[0-9]\.\s*/, ""))}
            </div>
            <div className="mt-1 text-[7px] text-[#38bdf8] font-mono">0.02ms</div>
          </div>
        ))}
      </div>
    </div>
  );
};
