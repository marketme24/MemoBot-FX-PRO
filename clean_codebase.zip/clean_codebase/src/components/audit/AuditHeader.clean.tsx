import React from "react";
import {
  FileText,
  FileSpreadsheet,
  Printer,
  FileCode,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Layers,
  Sparkles,
  Download,
  Share2
} from "lucide-react";
import { useLanguage } from "../../components/LanguageProvider";
import { useNotification } from "../../components/NotificationProvider";
import { OrderAuditRecord } from "./auditTypes";
import { generateAndTriggerPrint } from "./PrintPassportModal";

interface AuditHeaderProps {
  orders: OrderAuditRecord[];
  complianceMode: "Islamic" | "Commercial";
  onUniversalPrint: () => void;
}

export const AuditHeader: React.FC<AuditHeaderProps> = ({
  orders,
  complianceMode,
  onUniversalPrint,
}) => {
  const { t } = useLanguage();
  const { showAlert } = useNotification();

  const handleExportWord = () => {
    const docContent = `
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head><title>MEMOBOT FX-PRO™ Auditing Report</title>
      <style>body{font-family:Arial;padding:20px;color:#111;} h1{color:#FA1F4E;} table{width:100%;border-collapse:collapse;} th,td{border:1px solid #ddd;padding:6px;font-size:10pt;} th{background:#f0f0f0;}</style>
      </head><body>
      <h1>MEMOBOT FX-PRO™ Verified Audit Statement</h1>
      <p>Mode: <strong>${complianceMode.toUpperCase()}</strong> | Timestamp: ${new Date().toUTCString()}</p>
      <table><thead><tr><th>Order</th><th>Timestamp</th><th>Engine</th><th>Pair</th><th>Side</th><th>Price</th><th>Value</th><th>Status</th></tr></thead>
      <tbody>${orders.map(o=>`<tr><td>${o.orderNumber}</td><td>${o.timestamp}</td><td>${o.engine}</td><td>${o.symbol}</td><td>${o.side}</td><td>${o.price}</td><td>${o.totalValue}</td><td>${o.status}</td></tr>`).join("")}</tbody></table>
      </body></html>`;
    const blob = new Blob(["\ufeff", docContent], { type: "application/msword" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `MEMOBOT_AUDIT_${new Date().toISOString().slice(0, 10)}.doc`;
    link.click();
    URL.revokeObjectURL(url);
    showAlert(t("Official Word Document Generated"));
  };

  const handleExportExcel = () => {
    const headers = ["Order #", "Correlation ID", "Timestamp", "Engine", "Exchange", "Pair", "Side", "Price", "Amount", "Total Value", "Stage", "Status", "Latency (ms)", "Hash"];
    const rows = orders.map((o) => [
      `"${o.orderNumber}"`, `"${o.correlationId}"`, `"${o.timestamp}"`, `"${o.engine}"`, `"${o.exchange}"`,
      `"${o.symbol}"`, `"${o.side}"`, `"${o.price}"`, `"${o.amount}"`, `"${o.totalValue}"`,
      `"${o.stage}"`, `"${o.status}"`, `"${o.latencyMs}"`, `"${o.hash}"`
    ]);
    const csvContent = "\ufeff" + [headers.join(","), ...rows.map((e) => e.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `MEMOBOT_AUDIT_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    showAlert(t("Excel Audit Spreadsheet Downloaded"));
  };

  const handleExportTXT = () => {
    let txt = `=== MEMOBOT FX-PRO™ AUDIT LOG ===\nMODE: ${complianceMode.toUpperCase()}\nTIME: ${new Date().toISOString()}\n\n`;
    orders.forEach((o, i) => {
      txt += `[${i+1}] ${o.orderNumber} | ${o.symbol} ${o.side} @ ${o.price} | VAL: ${o.totalValue} | ${o.engine} | ${o.exchange} | LATENCY: ${o.latencyMs}ms | HASH: ${o.hash}\n`;
    });
    const blob = new Blob([txt], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `MEMOBOT_AUDIT_${new Date().toISOString().slice(0, 10)}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    showAlert(t("Cryptographic TXT Log Exported"));
  };

  return (
    <div className="bg-[#090b11] border border-[#1b1f2e] rounded-2xl p-4 sm:p-5 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 shadow-xl">
      <div className="flex items-center gap-3.5">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#FA1F4E]/20 to-transparent border border-[#FA1F4E]/40 flex items-center justify-center text-[#FA1F4E] shadow-[0_0_15px_rgba(250,31,78,0.25)] shrink-0">
          <ShieldCheck className="w-6 h-6 animate-pulse" />
        </div>
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-base sm:text-lg font-black text-white uppercase tracking-wider font-aquire">
              {t("AUDITING HUB & COMPLIANCE LEDGER")}
            </h1>
            <span
              className={`px-2 py-0.5 text-[9px] font-black rounded uppercase border ${
                complianceMode === "Islamic"
                  ? "bg-[#00e676]/15 border-[#00e676]/50 text-[#00e676]"
                  : "bg-[#38bdf8]/15 border-[#38bdf8]/50 text-[#38bdf8]"
              }`}
            >
              {complianceMode === "Islamic" ? "AAOIFI-21 COMPLIANT" : "COMMERCIAL SPOT"}
            </span>
          </div>
          <p className="text-xs text-[#8a8d9a] mt-0.5">
            {t("Cryptographically signed orderbook telemetry with sub-millisecond execution verification.")}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-wrap w-full lg:w-auto">
        <button
          onClick={onUniversalPrint}
          className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 bg-[#FA1F4E] hover:bg-[#FA1F4E]/90 text-white font-black text-xs uppercase rounded-xl transition-all shadow-[0_0_15px_rgba(250,31,78,0.4)] cursor-pointer active:scale-95"
        >
          <Printer className="w-4 h-4" />
          <span>{t("UNIVERSAL PRINT / PDF")}</span>
        </button>

        <div className="flex items-center gap-1.5 bg-[#05070a] p-1 border border-[#1e2336] rounded-xl">
          <button
            onClick={handleExportExcel}
            className="p-1.5 text-slate-400 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-all cursor-pointer"
            title={t("Export Excel (.csv)")}
          >
            <FileSpreadsheet className="w-4 h-4" />
          </button>
          <button
            onClick={handleExportWord}
            className="p-1.5 text-slate-400 hover:text-blue-400 hover:bg-blue-500/10 rounded-lg transition-all cursor-pointer"
            title={t("Export Word (.doc)")}
          >
            <FileText className="w-4 h-4" />
          </button>
          <button
            onClick={handleExportTXT}
            className="p-1.5 text-slate-400 hover:text-amber-400 hover:bg-amber-500/10 rounded-lg transition-all cursor-pointer"
            title={t("Export TXT Log")}
          >
            <FileCode className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
