import React from "react";
import { OrderAuditRecord } from "./auditTypes";

export const generateAndTriggerPrint = (
  title: string,
  orders: OrderAuditRecord[],
  complianceMode: string,
  singleOrder?: OrderAuditRecord
) => {
  const printWindow = window.open("", "_blank");
  const recordsToPrint = singleOrder ? [singleOrder] : orders;
  const totalVolume = recordsToPrint.reduce((acc, o) => acc + o.rawValue, 0);
  const approvedCount = recordsToPrint.filter((o) => o.status === "APPROVED").length;
  const rejectedCount = recordsToPrint.filter((o) => o.status === "REJECTED").length;

  const html = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${title} - MEMOBOT FX-PRO™</title>
        <style>
          @media print {
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .no-print { display: none !important; }
          }
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            color: #0f172a;
            background: #ffffff;
            padding: 32px;
            margin: 0;
            line-height: 1.4;
          }
          .header-box {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #FA1F4E;
            padding-bottom: 16px;
            margin-bottom: 20px;
          }
          .title { font-size: 22px; font-weight: 900; color: #FA1F4E; letter-spacing: 0.5px; }
          .subtitle { font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase; margin-top: 2px; }
          .pill { background: #0f172a; color: #fff; padding: 4px 10px; border-radius: 4px; font-size: 10px; font-weight: bold; }
          .pill-halal { background: #059669; }
          .metrics-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px 16px;
            margin-bottom: 20px;
            font-size: 11px;
          }
          .metric-val { font-size: 14px; font-weight: 800; color: #0f172a; margin-top: 2px; }
          table { width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 10px; }
          th { background: #0f172a; color: #fff; text-align: left; padding: 8px 10px; font-weight: 700; text-transform: uppercase; }
          td { border-bottom: 1px solid #e2e8f0; padding: 7px 10px; }
          tr:nth-child(even) { background: #f8fafc; }
          .status-approved { color: #059669; font-weight: bold; }
          .status-rejected { color: #dc2626; font-weight: bold; }
          .side-buy { color: #0284c7; font-weight: bold; }
          .side-sell { color: #7c3aed; font-weight: bold; }
          .footer {
            margin-top: 30px;
            padding-top: 12px;
            border-top: 1px solid #cbd5e1;
            font-size: 9px;
            color: #64748b;
            display: flex;
            justify-content: space-between;
          }
          .btn-print {
            background: #FA1F4E;
            color: #fff;
            border: none;
            padding: 8px 18px;
            font-weight: bold;
            border-radius: 6px;
            cursor: pointer;
            margin-bottom: 16px;
          }
        </style>
      </head>
      <body>
        <div class="no-print">
          <button class="btn-print" onclick="window.print()">🖨️ PRINT VERIFIED AUDIT / SAVE TO PDF</button>
        </div>
        <div class="header-box">
          <div>
            <div class="title">MEMOBOT FX-PRO™</div>
            <div class="subtitle">${title}</div>
          </div>
          <div style="text-align: right;">
            <span class="pill ${complianceMode === "Islamic" ? "pill-halal" : ""}">
              PROTOCOL: ${complianceMode.toUpperCase()}
            </span>
            <div style="font-size: 9px; color: #64748b; margin-top: 4px;">
              UTC: ${new Date().toUTCString()}
            </div>
          </div>
        </div>

        <div class="metrics-grid">
          <div>
            <span style="color:#64748b;">RECORD COUNT</span>
            <div class="metric-val">${recordsToPrint.length} Orders</div>
          </div>
          <div>
            <span style="color:#059669;">APPROVED GATES</span>
            <div class="metric-val">${approvedCount} Executed</div>
          </div>
          <div>
            <span style="color:#dc2626;">REJECTED RISKS</span>
            <div class="metric-val">${rejectedCount} Blocked</div>
          </div>
          <div>
            <span style="color:#d97706;">TOTAL EXECUTED VOL</span>
            <div class="metric-val">$${totalVolume.toLocaleString("en-US", { minimumFractionDigits: 2 })}</div>
          </div>
        </div>

        <table>
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Timestamp</th>
              <th>Engine & Exchange</th>
              <th>Pair / Side</th>
              <th>Price & Value</th>
              <th>Latency</th>
              <th>Stage & Strategy</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${recordsToPrint
              .map(
                (o) => `
              <tr>
                <td><strong>${o.orderNumber}</strong><br/><span style="font-size:8px;color:#64748b;">${o.correlationId}</span></td>
                <td>${o.timestamp}</td>
                <td><strong>${o.engine}</strong><br/><span style="color:#0284c7;">${o.exchange}</span></td>
                <td><strong>${o.symbol}</strong><br/><span class="${o.side === "BUY" ? "side-buy" : "side-sell"}">${o.side}</span></td>
                <td><strong>${o.price}</strong><br/><span style="color:#b45309;">${o.totalValue}</span></td>
                <td>${o.latencyMs}ms</td>
                <td><strong>${o.stage}</strong><br/><span style="font-size:8px;color:#059669;">${o.strategyName}</span></td>
                <td><span class="${o.status === "APPROVED" ? "status-approved" : "status-rejected"}">${o.status}</span></td>
              </tr>
            `
              )
              .join("")}
          </tbody>
        </table>

        <div class="footer">
          <div><strong>Ledger Hash:</strong> ${singleOrder ? singleOrder.hash : "0x8f7a90b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9"}</div>
          <div>Verification Mode: Cryptographic SHA-256 &bull; Strict Spot Settlement</div>
        </div>
      </body>
    </html>
  `;

  if (printWindow) {
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => printWindow.print(), 350);
  } else {
    window.print();
  }
};
