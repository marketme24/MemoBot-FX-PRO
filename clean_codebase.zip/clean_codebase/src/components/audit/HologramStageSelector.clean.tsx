import React from "react";
import { Layers, CheckCircle2, Circle } from "lucide-react";
import { useLanguage } from "../../components/LanguageProvider";
import { NINE_STAGES } from "./auditTypes";

interface HologramStageSelectorProps {
  enabledStages: number[];
  onToggleStage: (stageNum: number) => void;
  onSelectAllStages: () => void;
  accentColor?: string;
}

export const HologramStageSelector: React.FC<HologramStageSelectorProps> = ({
  enabledStages,
  onToggleStage,
  onSelectAllStages,
  accentColor = "#FA1F4E",
}) => {
  const { t } = useLanguage();

  return (
    <div 
      className="relative z-10 bg-[#080a12]/90 border border-[#181d2a] rounded-2xl p-3.5 space-y-2.5 font-mono shadow-lg"
      style={{
        boxShadow: `0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)`,
      }}
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#181d2a] pb-2">
        <div className="flex items-center gap-2">
          <Layers className="w-3.5 h-3.5" style={{ color: accentColor }} />
          <span className="text-[11px] font-black uppercase tracking-wider text-white">
            {t("TAILOR THE 9 EXECUTION STAGES")}
          </span>
          <span className="text-[9.5px] text-[#717688]">
            ({t("Toggle stage nodes ON/OFF")})
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onSelectAllStages}
            className="text-[9px] px-2 py-0.5 border text-slate-300 hover:text-white rounded-lg font-bold uppercase transition-all cursor-pointer"
            style={{
              borderColor: `${accentColor}60`,
              backgroundColor: `${accentColor}10`,
            }}
          >
            {t("SELECT ALL 9 STAGES")}
          </button>
          <span className="text-[10px] font-bold font-mono" style={{ color: accentColor }}>
            {enabledStages.length} / 9 {t("ACTIVE")}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-1.5 pt-0.5">
        {NINE_STAGES.map((stg, i) => {
          const stageNumber = i + 1;
          const isEnabled = enabledStages.includes(stageNumber);
          return (
            <button
              key={stageNumber}
              onClick={() => onToggleStage(stageNumber)}
              className={`py-1.5 px-2 rounded-xl border text-center flex flex-col justify-between transition-all duration-150 cursor-pointer active:scale-95 min-h-[50px] ${
                isEnabled
                  ? "bg-gradient-to-b from-[#141926] to-[#0d101a] text-white"
                  : "bg-[#06080e] border-[#151926] text-slate-500 opacity-60 hover:opacity-100"
              }`}
              style={{
                borderColor: isEnabled ? accentColor : undefined,
                boxShadow: isEnabled
                  ? `0 0 10px ${accentColor}30, inset 0 1px 0 rgba(255,255,255,0.08)`
                  : "none",
              }}
            >
              <div className="flex items-center justify-between text-[8px] font-black mb-0.5 w-full">
                <span style={{ color: isEnabled ? accentColor : "#5a6175" }}>S0{stageNumber}</span>
                {isEnabled ? (
                  <CheckCircle2 className="w-2.5 h-2.5" style={{ color: accentColor }} />
                ) : (
                  <Circle className="w-2.5 h-2.5 text-slate-600" />
                )}
              </div>
              <div 
                className="text-[8.5px] font-bold leading-tight uppercase line-clamp-2"
                style={{
                  textShadow: isEnabled ? "0 1px 2px rgba(0,0,0,0.8)" : "none",
                }}
              >
                {t(stg.replace(/^[0-9]\.\s*/, ""))}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
