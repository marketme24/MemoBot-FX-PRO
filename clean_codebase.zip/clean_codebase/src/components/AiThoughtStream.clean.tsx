import React from "react";
import { Brain, Sparkles, Cpu, ShieldCheck, Zap, Activity } from "lucide-react";

interface AiThoughtStreamProps {
  activeMode: "QUANT" | "SHARIAH" | "MICROSTRUCTURE" | "ARBITRAGE";
  onSelectMode: (mode: "QUANT" | "SHARIAH" | "MICROSTRUCTURE" | "ARBITRAGE") => void;
  isThinking: boolean;
  confidenceScore?: number;
}

export const AiThoughtStream: React.FC<AiThoughtStreamProps> = ({
  activeMode,
  onSelectMode,
  isThinking,
  confidenceScore = 98.4
}) => {
  const modes = [
    { id: "QUANT", label: "QUANT SYNTHESIZER", icon: Cpu, color: "#3b82f6" },
    { id: "SHARIAH", label: "SHARIAH SPOT AUDITOR", icon: ShieldCheck, color: "#00e676" },
    { id: "MICROSTRUCTURE", label: "ORDER BOOK RADAR", icon: Activity, color: "#FA1F4E" },
    { id: "ARBITRAGE", label: "ARBITRAGE CASCADE", icon: Zap, color: "#ffb800" },
  ] as const;

  return (
    <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded-lg space-y-3 font-mono text-xs select-none panel-glow">
      {/* Modes Navigation Header */}
      <div className="flex items-center justify-between border-b border-[#11131c] pb-2">
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4 text-[#FA1F4E] animate-pulse" />
          <span className="text-[10px] text-white font-bold uppercase tracking-wider">
            ORBIT-ME AI CO-PILOT MODES
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-[9px] text-[#8a8d9a]">
          <Sparkles className="w-3 h-3 text-[#3b82f6]" />
          <span>QUANT CONFIDENCE: <strong className="text-white">{confidenceScore}%</strong></span>
        </div>
      </div>

      {/* Interactive Mode Chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {modes.map((m) => {
          const IconComponent = m.icon;
          const isActive = activeMode === m.id;
          return (
            <button
              key={m.id}
              onClick={() => onSelectMode(m.id)}
              className={`p-2.5 rounded border text-left transition-all flex flex-col gap-1.5 ${
                isActive
                  ? "bg-[#12161f] border-[#3b82f6] text-white shadow-[0_0_12px_rgba(59,130,246,0.2)]"
                  : "bg-[#06070a] border-[#1a1d26] text-[#8a8d9a] hover:text-white hover:border-[#8a8d9a]"
              }`}
            >
              <div className="flex items-center justify-between">
                <IconComponent className="w-3.5 h-3.5" style={{ color: isActive ? m.color : "#8a8d9a" }} />
                <span className={`w-1.5 h-1.5 rounded-full ${isActive ? "animate-ping" : "opacity-30"}`} style={{ backgroundColor: m.color }} />
              </div>
              <span className="text-[9px] font-bold uppercase tracking-wider block truncate">
                {m.label}
              </span>
            </button>
          );
        })}
      </div>

      {/* Real-time Telemetry Bar */}
      <div className="bg-[#06070a] border border-[#11131c] p-2.5 rounded flex items-center justify-between text-[10px] text-[#8a8d9a]">
        <div className="flex items-center gap-2">
          <span className={`w-2 h-2 rounded-full ${isThinking ? "bg-[#FA1F4E] animate-ping" : "bg-[#00e676]"}`} />
          <span>STATUS: <strong className={isThinking ? "text-[#FA1F4E]" : "text-white"}>{isThinking ? "SYNTHESIZING MATRIX" : "READY FOR DIRECTIVE"}</strong></span>
        </div>
        <div className="flex items-center gap-4">
          <span>GEMINI MODEL: <strong className="text-[#3b82f6]">GEMINI 2.5 FLASH</strong></span>
          <span>LATENCY: <strong className="text-white">18ms</strong></span>
        </div>
      </div>
    </div>
  );
};
