import React, { createContext, useContext, useState, useEffect, useRef } from "react";
import { 
  transformToLiteralArabic, 
  transformArabicToEnglish, 
  convertDigitsToArabic,
  ARABIC_DICTIONARY 
} from "../config/arabicDictionary";
import { STORAGE_KEYS } from "../config/constants";

interface LanguageContextType {
  language: "en" | "ar";
  isArabic: boolean;
  toggleLanguage: () => void;
  setLanguage: (lang: "en" | "ar") => void;
  t: (text: string) => string;
  forceRetranslateAll: () => void;
  translateElement: (el: HTMLElement) => void;
}

const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  isArabic: false,
  toggleLanguage: () => {},
  setLanguage: () => {},
  t: (text: string) => text,
  forceRetranslateAll: () => {},
  translateElement: () => {},
});

function getInitialLanguage(): "en" | "ar" {
  try {
    // 1. Direct explicit keys
    const stored = 
      localStorage.getItem(STORAGE_KEYS.LANGUAGE) ||
      localStorage.getItem(STORAGE_KEYS.USER_LANG) ||
      localStorage.getItem("memobot_lang") ||
      localStorage.getItem("MEMOBOT_USER_LANG");
    
    if (stored === "ar" || stored === "en") return stored;

    // 2. User preferences object
    const prefsStr = localStorage.getItem(STORAGE_KEYS.USER_PREFS);
    if (prefsStr) {
      try {
        const prefs = JSON.parse(prefsStr);
        if (prefs.language === "ar" || prefs.language === "en") return prefs.language;
      } catch (e) {}
    }

    // 3. Session storage
    const sessionLang = sessionStorage.getItem("memobot_lang");
    if (sessionLang === "ar" || sessionLang === "en") return sessionLang;

    // 4. Browser locale detection
    if (typeof navigator !== "undefined" && navigator.languages) {
      const isArabicBrowser = navigator.languages.some(l => l.toLowerCase().startsWith("ar"));
      if (isArabicBrowser) return "ar";
    }
  } catch (e) {
    console.warn("Error detecting language:", e);
  }
  return "en";
}

function persistLanguageGlobally(lang: "en" | "ar") {
  try {
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, lang);
    localStorage.setItem(STORAGE_KEYS.USER_LANG, lang);
    localStorage.setItem("memobot_lang", lang);
    localStorage.setItem("MEMOBOT_USER_LANG", lang);
    sessionStorage.setItem("memobot_lang", lang);

    // Update user preferences object
    const prefsStr = localStorage.getItem(STORAGE_KEYS.USER_PREFS);
    let prefs: Record<string, any> = {};
    if (prefsStr) {
      try { prefs = JSON.parse(prefsStr); } catch (e) {}
    }
    prefs.language = lang;
    localStorage.setItem(STORAGE_KEYS.USER_PREFS, JSON.stringify(prefs));

    // Global window context
    if (typeof window !== "undefined") {
      (window as any).__MEMOBOT_CURRENT_LANG = lang;
      (window as any).__MEMOBOT_IS_ARABIC = lang === "ar";
    }
  } catch (e) {
    console.error("Failed to persist language globally:", e);
  }
}

function applyHtmlDirection(isArabic: boolean) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const body = document.body;

  if (isArabic) {
    root.dir = "rtl";
    root.lang = "ar";
    root.classList.add("rtl", "lang-ar");
    root.classList.remove("ltr", "lang-en");
    if (body) {
      body.dir = "rtl";
      body.classList.add("rtl", "lang-ar");
      body.classList.remove("ltr", "lang-en");
    }
  } else {
    root.dir = "ltr";
    root.lang = "en";
    root.classList.add("ltr", "lang-en");
    root.classList.remove("rtl", "lang-ar");
    if (body) {
      body.dir = "ltr";
      body.classList.add("ltr", "lang-en");
      body.classList.remove("rtl", "lang-ar");
    }
  }
}

// Immediately apply on module load
applyHtmlDirection(getInitialLanguage() === "ar");

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<"en" | "ar">(getInitialLanguage);

  const isArabic = language === "ar";
  const origTextMapRef = useRef<WeakMap<Node, string>>(new WeakMap());

  const setLanguage = (lang: "en" | "ar") => {
    setLanguageState(lang);
    persistLanguageGlobally(lang);
    applyHtmlDirection(lang === "ar");
    window.dispatchEvent(new CustomEvent("memobot:lang_change", { detail: { lang, isArabic: lang === "ar" } }));
  };

  const toggleLanguage = () => {
    const next = language === "en" ? "ar" : "en";
    setLanguage(next);
  };

  const t = (text: string): string => {
    if (!text || typeof text !== "string") return text;
    if (!isArabic) return text;
    return transformToLiteralArabic(text);
  };

  // Sync across storage events from other tabs
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEYS.LANGUAGE || e.key === "memobot_lang" || e.key === "MEMOBOT_USER_LANG") {
        if (e.newValue === "ar" || e.newValue === "en") {
          setLanguageState(e.newValue);
          applyHtmlDirection(e.newValue === "ar");
        }
      }
    };

    window.addEventListener("storage", handleStorageChange);
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []);

  // Sync HTML & Body root attributes and classes
  useEffect(() => {
    applyHtmlDirection(isArabic);
    persistLanguageGlobally(language);
  }, [language, isArabic]);

  const translateDomNode = (node: Node) => {
    const origMap = origTextMapRef.current;
    if (node.nodeType === Node.TEXT_NODE && node.nodeValue) {
      const parent = node.parentElement;
      if (
        parent &&
        parent.tagName !== "SCRIPT" &&
        parent.tagName !== "STYLE" &&
        !parent.dataset.noTranslate
      ) {
        const currentVal = node.nodeValue;
        if (!currentVal.trim()) return;

        let original = origMap.get(node) || (node as any).__origText;
        if (!original) {
          original = currentVal;
          origMap.set(node, original);
          (node as any).__origText = original;
        }

        const leadingSpace = original.match(/^\s*/)?.[0] || "";
        const trailingSpace = original.match(/\s*$/)?.[0] || "";
        const transformedCore = transformToLiteralArabic(original.trim());
        const transformed = leadingSpace + transformedCore + trailingSpace;
        
        if (transformed !== currentVal) {
          node.nodeValue = transformed;
        }
      }
    } else if (node.nodeType === Node.ELEMENT_NODE) {
      const el = node as HTMLElement;
      if (el.tagName !== "SCRIPT" && el.tagName !== "STYLE" && !el.dataset.noTranslate) {
        // Translate placeholder
        const ph = el.getAttribute("placeholder");
        if (ph && (/[a-zA-Z]/.test(ph) || !el.getAttribute("data-orig-placeholder"))) {
          if (!el.getAttribute("data-orig-placeholder")) {
            el.setAttribute("data-orig-placeholder", ph);
          }
          el.setAttribute("placeholder", transformToLiteralArabic(ph));
        }
        // Translate title
        const title = el.getAttribute("title");
        if (title && (/[a-zA-Z]/.test(title) || !el.getAttribute("data-orig-title"))) {
          if (!el.getAttribute("data-orig-title")) {
            el.setAttribute("data-orig-title", title);
          }
          el.setAttribute("title", transformToLiteralArabic(title));
        }
        // Translate aria-label
        const ariaLabel = el.getAttribute("aria-label");
        if (ariaLabel && (/[a-zA-Z]/.test(ariaLabel) || !el.getAttribute("data-orig-aria-label"))) {
          if (!el.getAttribute("data-orig-aria-label")) {
            el.setAttribute("data-orig-aria-label", ariaLabel);
          }
          el.setAttribute("aria-label", transformToLiteralArabic(ariaLabel));
        }
        node.childNodes.forEach(translateDomNode);
      }
    }
  };

  const forceRetranslateAll = () => {
    const rootElement = document.getElementById("root") || document.body;
    if (rootElement && isArabic) {
      translateDomNode(rootElement);
    }
  };

  const translateElement = (el: HTMLElement) => {
    if (el) {
      translateDomNode(el);
    }
  };

  // Listen for permanent custom translation saves/removals
  useEffect(() => {
    const handleTranslationUpdate = () => {
      if (isArabic) {
        forceRetranslateAll();
      }
    };
    window.addEventListener("memobot:translation_updated", handleTranslationUpdate);
    return () => window.removeEventListener("memobot:translation_updated", handleTranslationUpdate);
  }, [isArabic]);

  // Handle Full DOM Translation (English -> Arabic) and Instant Restoration (Arabic -> English)
  useEffect(() => {
    const rootElement = document.getElementById("root") || document.body;
    const origMap = origTextMapRef.current;

    if (!isArabic) {
      // ----------------------------------------------------
      // REVERT TO ENGLISH PASS: Instantly restore all text nodes
      // ----------------------------------------------------
      const restoreNode = (node: Node) => {
        if (node.nodeType === Node.TEXT_NODE && node.nodeValue) {
          if (origMap.has(node)) {
            node.nodeValue = origMap.get(node)!;
            origMap.delete(node);
          } else if ((node as any).__origText) {
            node.nodeValue = (node as any).__origText;
            delete (node as any).__origText;
          } else if (/[\u0600-\u06FF]/.test(node.nodeValue)) {
            node.nodeValue = transformArabicToEnglish(node.nodeValue);
          }
        } else if (node.nodeType === Node.ELEMENT_NODE) {
          const el = node as HTMLElement;
          // Restore placeholders
          if (el.getAttribute("data-orig-placeholder")) {
            el.setAttribute("placeholder", el.getAttribute("data-orig-placeholder")!);
            el.removeAttribute("data-orig-placeholder");
          }
          // Restore titles
          if (el.getAttribute("data-orig-title")) {
            el.setAttribute("title", el.getAttribute("data-orig-title")!);
            el.removeAttribute("data-orig-title");
          }
          // Restore aria-labels
          if (el.getAttribute("data-orig-aria-label")) {
            el.setAttribute("aria-label", el.getAttribute("data-orig-aria-label")!);
            el.removeAttribute("data-orig-aria-label");
          }
          node.childNodes.forEach(restoreNode);
        }
      };

      if (rootElement) {
        restoreNode(rootElement);
      }
      return;
    }

    // ----------------------------------------------------
    // TRANSLATE TO ARABIC PASS (Zero English Leftovers)
    // ----------------------------------------------------
    if (rootElement) {
      translateDomNode(rootElement);
    }

    // Observe subsequent dynamic mutations while in Arabic mode (e.g. WebSocket ticks, log streams)
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === "childList") {
          mutation.addedNodes.forEach((node) => translateDomNode(node));
        } else if (mutation.type === "characterData" && mutation.target) {
          translateDomNode(mutation.target);
        }
      });
    });

    if (rootElement) {
      observer.observe(rootElement, {
        childList: true,
        subtree: true,
        characterData: true,
      });
    }

    return () => {
      observer.disconnect();
    };
  }, [isArabic]);

  return (
    <LanguageContext.Provider value={{ 
      language, 
      isArabic, 
      toggleLanguage, 
      setLanguage, 
      t, 
      forceRetranslateAll, 
      translateElement 
    }}>
      <div key={language} id="app-language-boundary" className={`contents ${isArabic ? 'rtl' : 'ltr'}`}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);


