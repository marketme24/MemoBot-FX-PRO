import React, { useEffect, useState } from "react";
import { useLanguage } from "./LanguageProvider";
import { identityStore, TIER_PROFILES } from "../services/identityStore";
import { IdentityService } from "../services/identityService";
import { TierId } from "../types";
import { Shield, Key, Cpu, Zap, Lock, CheckCircle2, X, RefreshCw, Layers, Sliders, Globe, Server, Hash } from "lucide-react";

export const IdentityMatrixDrawer: React.FC = () => {
  const { isArabic, t } = useLanguage();
  const [identity, setIdentity] = useState(identityStore.getState());

  useEffect(() => {
    const unsub = identityStore.subscribe((state) => setIdentity({ ...state }));
    return () => unsub();
  }, []);

  if (!identity.isIdentityModalOpen) return null;

  const currentTier = identity.tierProfile;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn font-mono">
      <div 
        className="w-full max-w-4xl bg-[#0a0c10] border border-[#1e2330] rounded-xl shadow-[0_25px_60px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col max-h-[90vh]"
        style={{ direction: isArabic ? "rtl" : "ltr" }}
      >
        {/* Header */}
        <div className="px-6 py-4 bg-[#0e1117] border-b border-[#1e2330] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div 
              className="w-10 h-10 rounded-lg flex items-center justify-center shadow-lg"
              style={{ backgroundColor: `${currentTier.colorAccent}20`, border: `1px solid ${currentTier.colorAccent}` }}
            >
              <Shield className="w-5 h-5" style={{ color: currentTier.colorAccent }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white tracking-wider">
                  {t("IDENTITY MATRIX & DYNAMIC ROLE PROVISIONING")}
                </h3>
                <span 
                  className="px-2 py-0.5 rounded text-[10px] font-bold"
                  style={{ backgroundColor: `${currentTier.colorAccent}25`, color: currentTier.colorAccent }}
                >
                  {isArabic ? currentTier.nameAr : currentTier.name}
                </span>
              </div>
              <p className="text-[11px] text-[#8a8d9a]">
                {t("Decrypted JWT Token claims, active engine resource bounds, and real-time security telemetry.")}
              </p>
            </div>
          </div>

          <button
            onClick={() => IdentityService.toggleIdentityDrawer(false)}
            className="p-1.5 rounded-lg bg-[#161a23] hover:bg-[#222838] text-[#8a8d9a] hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {/* Tier Switcher Cards */}
          <div>
            <h4 className="text-[11px] font-bold text-[#8a8d9a] uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              {t("SELECT PROVISIONING TIER")}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {(Object.keys(TIER_PROFILES) as TierId[]).map((tierKey) => {
                const profile = TIER_PROFILES[tierKey];
                const isActive = identity.activeTier === tierKey;
                return (
                  <button
                    key={tierKey}
                    onClick={() => IdentityService.switchTier(tierKey)}
                    className={`p-3.5 rounded-lg border text-left flex flex-col justify-between transition-all cursor-pointer ${
                      isActive 
                        ? "bg-[#121622] shadow-[0_0_20px_rgba(0,0,0,0.5)]" 
                        : "bg-[#0c0e14] hover:bg-[#12151e] border-[#1a1d28] opacity-75 hover:opacity-100"
                    }`}
                    style={isActive ? { borderColor: profile.colorAccent } : {}}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1.5">
                        <span 
                          className="text-[9px] font-bold px-1.5 py-0.5 rounded"
                          style={{ backgroundColor: `${profile.colorAccent}20`, color: profile.colorAccent }}
                        >
                          {isArabic ? profile.resourceBoundAr : profile.resourceBound}
                        </span>
                        {isActive && <CheckCircle2 className="w-3.5 h-3.5" style={{ color: profile.colorAccent }} />}
                      </div>
                      <h5 className="font-bold text-white text-xs mb-1">
                        {isArabic ? profile.nameAr : profile.name}
                      </h5>
                      <p className="text-[10px] text-[#717684] line-clamp-2">
                        {isArabic ? profile.categoryAr : profile.category}
                      </p>
                    </div>

                    <div className="mt-3 pt-2 border-t border-[#1a1e2a] flex items-center justify-between text-[9px] text-[#8a8d9a]">
                      <span>{profile.latencySla}</span>
                      <span className="font-bold text-white">{profile.maxEngines} {t("ENGINES")}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Decrypted JWT & Active Telemetry Specs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Decrypted Claims */}
            <div className="bg-[#0c0e14] border border-[#1a1e28] rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-[#1a1e28] pb-2">
                <h5 className="font-bold text-white text-xs flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-amber-400" />
                  {t("DECRYPTED JWT MATRIX")}
                </h5>
                <span className="text-[9px] text-emerald-400 bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/50">
                  Ed25519 VERIFIED
                </span>
              </div>

              <div className="space-y-1.5 text-[10px]">
                <div className="flex justify-between py-1 border-b border-[#141722]">
                  <span className="text-[#8a8d9a]">{t("SUBJECT (SUB)")}:</span>
                  <span className="text-white font-mono">{identity.jwtPayload.sub}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#141722]">
                  <span className="text-[#8a8d9a]">{t("ISSUER (ISS)")}:</span>
                  <span className="text-cyan-400 font-mono">{identity.jwtPayload.iss}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-[#141722]">
                  <span className="text-[#8a8d9a]">{t("MAX ENGINES")}:</span>
                  <span className="text-white font-bold">{identity.jwtPayload.max_engines} {t("ENGINES")}</span>
                </div>
                {identity.jwtPayload.tenant_id && (
                  <div className="flex justify-between py-1 border-b border-[#141722]">
                    <span className="text-[#8a8d9a]">{t("TENANT ID")}:</span>
                    <span className="text-purple-400 font-bold">{identity.jwtPayload.tenant_id}</span>
                  </div>
                )}
                <div className="pt-1">
                  <span className="text-[#8a8d9a] block mb-1">{t("ASSIGNED SCOPES")}:</span>
                  <div className="flex flex-wrap gap-1">
                    {identity.jwtPayload.scopes.map((s) => (
                      <span key={s} className="px-2 py-0.5 rounded bg-[#161a26] text-white border border-[#242b3d] text-[9px]">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Hardware & Governance Enclave */}
            <div className="bg-[#0c0e14] border border-[#1a1e28] rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between border-b border-[#1a1e28] pb-2">
                <h5 className="font-bold text-white text-xs flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-rose-400" />
                  {t("PROVISIONING GOVERNANCE")}
                </h5>
                <span className="text-[9px] text-cyan-400 bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/50">
                  {currentTier.latencySla}
                </span>
              </div>

              <div className="space-y-2 text-[10px]">
                <div className="p-2 rounded bg-[#131620] border border-[#1c2232]">
                  <span className="text-[#8a8d9a] block text-[9px] mb-0.5">{t("AUTH METHOD")}:</span>
                  <span className="text-white font-semibold">{isArabic ? currentTier.authMethodAr : currentTier.authMethod}</span>
                </div>

                <div className="p-2 rounded bg-[#131620] border border-[#1c2232]">
                  <span className="text-[#8a8d9a] block text-[9px] mb-0.5">{t("RISK CLAMP")}:</span>
                  <span className="text-rose-400 font-semibold">{isArabic ? currentTier.riskClampAr : currentTier.riskClamp}</span>
                </div>

                <div className="p-2 rounded bg-[#131620] border border-[#1c2232]">
                  <span className="text-[#8a8d9a] block text-[9px] mb-0.5">{t("INTERFACE HUD")}:</span>
                  <span className="text-emerald-400 font-semibold">{isArabic ? currentTier.interfaceHudAr : currentTier.interfaceHud}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-3.5 bg-[#0e1117] border-t border-[#1e2330] flex items-center justify-between">
          <div className="text-[10px] text-[#8a8d9a] flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>{t("RUNTIME CLUSTER READY")} • {identity.user.organization}</span>
          </div>

          <button
            onClick={() => IdentityService.toggleIdentityDrawer(false)}
            className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-colors cursor-pointer"
          >
            {t("CONFIRM & APPLY PROVISIONING")}
          </button>
        </div>
      </div>
    </div>
  );
};
