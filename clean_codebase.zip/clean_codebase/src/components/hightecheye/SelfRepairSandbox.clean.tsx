import React, { useState } from "react";
import { Play, ShieldCheck, RefreshCw, AlertCircle, CheckCircle2, Sliders, Cpu, Activity } from "lucide-react";

interface SelfRepairSandboxProps {
  onShowAlert: (msg: string) => void;
}

export const SelfRepairSandbox: React.FC<SelfRepairSandboxProps> = ({ onShowAlert }) => {
  // Sandbox State
  const [simAmount, setSimAmount] = useState<number>(2500);
  const [simPair, setSimPair] = useState<string>("BTC/USDT");
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simOutput, setSimOutput] = useState<{
    status: string;
    route: string;
    slippage: string;
    shariahCheck: string;
    latency: string;
    correlationId: string;
  } | null>({
    status: "READY FOR EXECUTION",
    route: "VAULT_SPOT_1X → L2_POOL → ZERO_RIBA",
    slippage: "0.000%",
    shariahCheck: "100% PASSED (AAOIFI STANDARD NO. 21)",
    latency: "0.18ms",
    correlationId: "CORR-SIM-829104",
  });

  // Repair State
  const [isRepairing, setIsRepairing] = useState<boolean>(false);
  const [repairStep, setRepairStep] = useState<string>("");
  const [lastRepairReport, setLastRepairReport] = useState<{
    action: string;
    status: string;
    correlationId: string;
    timestamp: string;
  }>({
    action: "STANDBY",
    status: "SYSTEM HEALTH NOMINAL",
    correlationId: "CORR-REPAIR-771290",
    timestamp: "STANDBY",
  });

  // Stress Mode State
  const [activeStress, setActiveStress] = useState<string>("IDLE");

  const runSimulation = () => {
    setIsSimulating(true);
    const corr = `CORR-SIM-${Math.floor(100000 + Math.random() * 900000)}`;

    setTimeout(() => {
      setIsSimulating(false);
      setSimOutput({
        status: "APPROVED — ROUTE VERIFIED",
        route: `SPOT_1X → DIRECT_BOOK[${simPair}] → SETTLED`,
        slippage: "0.000%",
        shariahCheck: "100% PASSED (PHYSICAL QABD CONFIRMED)",
        latency: `${(0.12 + Math.random() * 0.1).toFixed(2)}ms`,
        correlationId: corr,
      });
      onShowAlert(`[SANDBOX SIMULATION] Transaction validated with 0 slippage. ID: ${corr}`);
    }, 700);
  };

  const runRepairAction = (actionName: string) => {
    setIsRepairing(true);
    setRepairStep(`Diagnosing subsystem for ${actionName}...`);
    const corr = `CORR-FIX-${Math.floor(100000 + Math.random() * 900000)}`;

    setTimeout(() => {
      setRepairStep("Flushing cached RPC sockets & optimizing worker threads...");
    }, 400);

    setTimeout(() => {
      setIsRepairing(false);
      setRepairStep("");
      const now = new Date().toLocaleTimeString();
      setLastRepairReport({
        action: actionName,
        status: "SUCCESSFUL // 0 ANOMALIES DETECTED",
        correlationId: corr,
        timestamp: now,
      });
      onShowAlert(`[SELF-REPAIR ENGINE] ${actionName} executed successfully. Correlation ID: ${corr}`);
    }, 1100);
  };

  const toggleStressMode = (mode: string) => {
    if (activeStress === mode) {
      setActiveStress("IDLE");
      onShowAlert("[STRESS TEST] Deactivated stress protocol. System returned to default state.");
    } else {
      setActiveStress(mode);
      onShowAlert(`[STRESS TEST] Activated ${mode} protocol. Injecting simulated volume test.`);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 font-mono">
      {/* 1. TRANSACTION SIMULATION SANDBOX */}
      <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 shadow-[0_4px_24px_rgba(0,0,0,0.5)] flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2.5">
            <span className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#3b82f6]" />
              TRANSACTION SIMULATOR
            </span>
            <span className="px-2 py-0.5 rounded bg-[#1e293b] text-[#93c5fd] text-[9px] font-bold">
              ZERO RISK
            </span>
          </div>

          <div className="mt-3 space-y-2.5 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[8px] text-[#64748b] uppercase block">ASSET PAIR</label>
                <select
                  value={simPair}
                  onChange={(e) => setSimPair(e.target.value)}
                  className="w-full bg-[#080d16] border border-[#1e293b] rounded p-1.5 text-[11px] text-white focus:outline-none focus:border-[#3b82f6]"
                >
                  <option value="BTC/USDT">BTC/USDT (SPOT)</option>
                  <option value="ETH/USDT">ETH/USDT (SPOT)</option>
                  <option value="SOL/USDT">SOL/USDT (SPOT)</option>
                  <option value="XRP/USDT">XRP/USDT (SPOT)</option>
                </select>
              </div>
              <div>
                <label className="text-[8px] text-[#64748b] uppercase block">NOTIONAL SIZE (USDT)</label>
                <input
                  type="number"
                  value={simAmount}
                  onChange={(e) => setSimAmount(Number(e.target.value))}
                  className="w-full bg-[#080d16] border border-[#1e293b] rounded p-1.5 text-[11px] text-white focus:outline-none focus:border-[#3b82f6]"
                />
              </div>
            </div>

            {/* Results Display */}
            {simOutput && (
              <div className="bg-[#080d16] border border-[#1e293b] rounded-lg p-2.5 space-y-1.5 text-[10px]">
                <div className="flex justify-between">
                  <span className="text-[#64748b]">STATUS:</span>
                  <span className="text-white font-bold">{simOutput.status}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#64748b]">ROUTE:</span>
                  <span className="text-[#93c5fd] font-bold truncate max-w-[170px]">{simOutput.route}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#64748b]">SLIPPAGE AUDIT:</span>
                  <span className="text-white font-bold">{simOutput.slippage}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#64748b]">TRACE ID:</span>
                  <span className="text-white font-bold">{simOutput.correlationId}</span>
                </div>
              </div>
            )}
          </div>
        </div>

        <button
          onClick={runSimulation}
          disabled={isSimulating}
          className="mt-3 w-full py-2 bg-[#3b82f6] hover:bg-[#2563eb] text-white font-black text-xs uppercase tracking-wider rounded transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(59,130,246,0.3)] disabled:opacity-50"
        >
          {isSimulating ? (
            <>
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>SIMULATING ROUTE...</span>
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>EXECUTE SANDBOX TEST</span>
            </>
          )}
        </button>
      </div>

      {/* 2. AUTONOMOUS SELF-REPAIR & FIXING ENGINE */}
      <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 shadow-[0_4px_24px_rgba(0,0,0,0.5)] flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2.5">
            <span className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#3b82f6]" />
              SELF-REPAIR ENGINE
            </span>
            <span className="px-2 py-0.5 rounded bg-[#1e293b] text-[#93c5fd] text-[9px] font-bold">
              AUTONOMOUS
            </span>
          </div>

          {/* Action Quick Buttons */}
          <div className="mt-3 space-y-2">
            <div className="text-[8px] text-[#64748b] uppercase">SELECT REPAIR PROTOCOL:</div>
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { name: "RESTART ENDPOINTS", id: "RESTART_ENDPOINTS" },
                { name: "FLUSH RPC CACHE", id: "FLUSH_RPC_CACHE" },
                { name: "RECALIBRATE RISK", id: "RECALIBRATE_RISK" },
                { name: "RESYNC LEDGER", id: "RESYNC_LEDGER" },
              ].map((act) => (
                <button
                  key={act.id}
                  onClick={() => runRepairAction(act.name)}
                  disabled={isRepairing}
                  className="p-2 bg-[#080d16] hover:bg-[#131d31] border border-[#1e293b] hover:border-[#3b82f6] text-white rounded text-[9px] font-bold uppercase transition-all text-left disabled:opacity-50"
                >
                  {act.name}
                </button>
              ))}
            </div>

            {/* In-Flight Diagnosis Banner */}
            {isRepairing && (
              <div className="p-2.5 bg-[#131d31] border border-[#3b82f6] rounded text-[10px] text-white flex items-center gap-2 animate-pulse">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#3b82f6]" />
                <span>{repairStep}</span>
              </div>
            )}

            {/* Diagnostic Report Card */}
            <div className="bg-[#080d16] border border-[#1e293b] rounded-lg p-2.5 space-y-1 text-[10px]">
              <div className="flex justify-between">
                <span className="text-[#64748b]">LAST ACTION:</span>
                <span className="text-white font-bold">{lastRepairReport.action}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#64748b]">STATUS:</span>
                <span className="text-white font-bold">{lastRepairReport.status}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#64748b]">TRACE REF:</span>
                <span className="text-white font-bold">{lastRepairReport.correlationId}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3 pt-2 border-t border-[#1e293b] text-[8px] text-[#64748b] flex justify-between">
          <span>AI REPAIR ACCURACY: 100%</span>
          <span>LATENCY IMPACT: 0.00ms</span>
        </div>
      </div>

      {/* 3. SYSTEM STRESS TEST MODE */}
      <div className="bg-[#0b101b] border border-[#1e293b] rounded-lg p-4 shadow-[0_4px_24px_rgba(0,0,0,0.5)] flex flex-col justify-between">
        <div>
          <div className="flex items-center justify-between border-b border-[#1e293b] pb-2.5">
            <span className="text-xs font-black text-white uppercase tracking-widest flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#3b82f6]" />
              LOAD & STRESS TEST
            </span>
            <span className="px-2 py-0.5 rounded bg-[#1e293b] text-white text-[9px] font-bold uppercase">
              {activeStress}
            </span>
          </div>

          <div className="mt-3 space-y-2">
            <div className="text-[8px] text-[#64748b] uppercase">SELECT LOAD STRESS PROFILE:</div>
            <div className="space-y-1.5">
              {[
                { id: "BURST_TEST", label: "BURST TEST (50k RPS BURST)" },
                { id: "CORRIDOR_OVERLOAD", label: "CORRIDOR CONGESTION SIM" },
                { id: "SLIPPAGE_STRESS", label: "HIGH VOLATILITY SLIPPAGE SPIKE" },
              ].map((st) => (
                <button
                  key={st.id}
                  onClick={() => toggleStressMode(st.id)}
                  className={`w-full p-2 rounded text-[10px] font-bold uppercase border transition-all flex items-center justify-between ${
                    activeStress === st.id
                      ? "bg-[#3b82f6] text-white border-[#3b82f6] shadow-[0_0_12px_rgba(59,130,246,0.4)]"
                      : "bg-[#080d16] text-[#94a3b8] border-[#1e293b] hover:text-white hover:border-[#3b82f6]/50"
                  }`}
                >
                  <span>{st.label}</span>
                  <span className="text-[8px] opacity-80">{activeStress === st.id ? "ACTIVE" : "ARM"}</span>
                </button>
              ))}
            </div>

            <div className="bg-[#080d16] border border-[#1e293b] rounded-lg p-2.5 space-y-1 text-[10px] mt-2">
              <div className="flex justify-between">
                <span className="text-[#64748b]">PACKET RESILIENCE:</span>
                <span className="text-white font-bold">100.00% (0 LOST)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#64748b]">MEM BUFFER STABILITY:</span>
                <span className="text-white font-bold">LOCKED NOMINAL</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-3 pt-2 border-t border-[#1e293b] text-[8px] text-[#64748b] flex justify-between">
          <span>FAILOVER DURATION: 0.00s</span>
          <span>AUTO ROLLBACK: ACTIVE</span>
        </div>
      </div>
    </div>
  );
};
