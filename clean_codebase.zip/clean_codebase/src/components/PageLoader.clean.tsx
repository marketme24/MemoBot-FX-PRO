import React from "react";
import { RefreshCw } from "lucide-react";

interface PageLoaderProps {
  message?: string;
  subMessage?: string;
}

export function PageLoader({
  message = "SYNCHRONIZING WITH IMMUTABLE EXCHANGE LEDGER...",
  subMessage = "Deterministic MemoCore Cluster Active"
}: PageLoaderProps) {
  return (
    <div className="flex-1 min-h-[60vh] bg-[#06070a] flex flex-col items-center justify-center p-6 select-none relative overflow-hidden">
      {/* Subtle Background Radial Glow */}
      <div className="absolute w-96 h-96 rounded-full bg-[#FA1F4E]/5 blur-3xl pointer-events-none" />
      <div className="absolute w-64 h-64 rounded-full bg-cyan-500/5 blur-2xl pointer-events-none" />

      {/* Center Brand & Spinner Animation */}
      <div className="relative flex flex-col items-center justify-center z-10">
        {/* MemoBot Logo with Ambient Aura & Dual Orbiting Spinner */}
        <div className="relative flex items-center justify-center mb-5">
          {/* Outer Cyan Ring */}
          <div className="absolute w-20 h-20 rounded-full border border-cyan-500/20 border-t-cyan-400 animate-spin" />
          
          {/* Inner Red / Crimson Ring */}
          <div className="absolute w-16 h-16 rounded-full border border-[#FA1F4E]/20 border-b-[#FA1F4E] animate-spin" style={{ animationDirection: "reverse", animationDuration: "1.5s" }} />

          {/* Glowing MemoBot Emblem Logo */}
          <div className="relative h-11 w-11 flex items-center justify-center">
            <img
              src="/MemoBot.png"
              alt="MemoBot Brand"
              className="h-9 w-auto object-contain mix-blend-screen filter drop-shadow-[0_0_14px_rgba(250,31,78,0.9)] animate-pulse"
            />
          </div>
        </div>

        {/* Primary Status Text */}
        <div className="flex items-center gap-2.5 text-[#FA1F4E] font-mono text-[11px] font-bold tracking-[0.18em] uppercase drop-shadow-[0_0_10px_rgba(250,31,78,0.4)]">
          <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#FA1F4E]" />
          <span>{message}</span>
        </div>

        {/* Sub-label */}
        {subMessage && (
          <span className="text-[9px] font-mono text-cyan-400/80 tracking-[0.2em] uppercase font-semibold mt-2">
            {subMessage}
          </span>
        )}
      </div>
    </div>
  );
}
