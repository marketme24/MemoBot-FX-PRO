import React, { useState } from "react";
import { 
  CreditCard, 
  Wallet, 
  QrCode, 
  Copy, 
  CheckCircle2, 
  Zap, 
  ShieldCheck, 
  Cpu, 
  Lock, 
  Sparkles,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  DollarSign
} from "lucide-react";

interface MemoCorePaymentBenchProps {
  /** Target USDT TRC-20 Address for receiving payments */
  trc20Address?: string;
  /** Target USDT ERC-20 / BSC Address */
  erc20Address?: string;
  /** Callback when user completes subscription */
  onSuccess?: (plan: string, txHash: string) => void;
}

export const MemoCorePaymentBench: React.FC<MemoCorePaymentBenchProps> = ({
  trc20Address = "TQn9Y2khEsLJW1ChVWFMSMeRDow5KcbLSE",
  erc20Address = "0x71C...849dF",
  onSuccess
}) => {
  const [selectedPlan, setSelectedPlan] = useState<"daily" | "weekly" | "monthly">("weekly");
  const [paymentMethod, setPaymentMethod] = useState<"card" | "apple" | "gpay" | "paypal" | "crypto">("crypto");
  const [copied, setCopied] = useState<boolean>(false);
  const [txHash, setTxHash] = useState<string>("");
  const [isVerifying, setIsVerifying] = useState<boolean>(false);
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [selectedNetwork, setSelectedNetwork] = useState<"TRC20" | "ERC20" | "BEP20">("TRC20");

  const plans = {
    daily: { name: "DAILY", price: "$3", subtitle: "Billed Daily", tag: "", amount: 3 },
    weekly: { name: "WEEKLY", price: "$18", subtitle: "Billed Weekly", tag: "POPULAR", amount: 18 },
    monthly: { name: "MONTHLY", price: "$50", subtitle: "Billed Monthly", tag: "BEST VALUE", amount: 50 }
  };

  const currentPlan = plans[selectedPlan];
  const activeAddress = selectedNetwork === "TRC20" ? trc20Address : erc20Address;

  const handleCopy = () => {
    navigator.clipboard.writeText(activeAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleVerifyPayment進 = () => {
    if (paymentMethod === "crypto" && !txHash.trim()) {
      alert("Please enter the blockchain Transaction Hash (TXID) to verify.");
      return;
    }
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setIsSuccess(true);
      if (onSuccess) onSuccess(selectedPlan, txHash);
    }, 1800);
  };

  return (
    <div className="w-full max-w-4xl mx-auto font-mono text-xs text-[#8a8d9a] select-none">
      {/* Outer Cyberpunk Frame */}
      <div className="relative bg-[#06080e]/95 border border-[#FA1F4E]/40 rounded-xl p-5 sm:p-6 shadow-[0_0_40px_rgba(250,31,78,0.15)] overflow-hidden backdrop-blur-xl">
        {/* Ambient Corner Neon Grid */}
        <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-[#FA1F4E]/20 to-transparent pointer-events-none rounded-tl-xl blur-xl" />
        <div className="absolute bottom-0 right-0 w-32 h-32 bg-gradient-to-tl from-cyan-500/20 to-transparent pointer-events-none rounded-br-xl blur-xl" />

        {/* Bench Header */}
        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#1b1f2e] pb-4 mb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#FA1F4E]/10 border border-[#FA1F4E]/40 flex items-center justify-center text-[#FA1F4E] shadow-[0_0_10px_rgba(250,31,78,0.3)]">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-white uppercase tracking-widest font-sans">
                  MEMO CORE QUICK PAYMENT BENCH
                </h3>
                <span className="px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 text-[9px] font-bold">
                  CORE_ONLINE
                </span>
              </div>
              <p className="text-[10px] text-[#717684] mt-0.5">
                Instant encrypted provisioning • Sub-millisecond quant nodes • 0% Platform markup
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[10px] text-[#555] font-mono">
            <Lock className="w-3.5 h-3.5 text-[#FA1F4E]" />
            <span>[ FOLD - SECURE ]</span>
          </div>
        </div>

        {/* Plan Selectors (Daily, Weekly, Monthly) */}
        <div className="relative z-10 grid grid-cols-1 sm:grid-cols-3 gap-3 mb-5">
          {(["daily", "weekly", "monthly"] as const).map((key) => {
            const plan = plans[key];
            const isSelected進 = selectedPlan === key;
            return (
              <button
                key={key}
                onClick={() => {
                  setSelectedPlan(key);
                  setIsSuccess(false);
                }}
                className={`relative p-4 rounded-lg border text-center transition-all cursor-pointer ${
                  isSelected進
                    ? "bg-[#FA1F4E]/15 border-[#FA1F4E] shadow-[0_0_20px_rgba(250,31,78,0.3)] ring-1 ring-[#FA1F4E]/50"
                    : "bg-[#090b12] border-[#181c2b] hover:border-[#333b52] text-[#8a8d9a]"
                }`}
              >
                {plan.tag && (
                  <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider bg-[#FA1F4E] text-white shadow-[0_0_10px_#FA1F4E]">
                    {plan.tag}
                  </span>
                )}
                <div className={`text-[11px] font-black uppercase tracking-wider ${isSelected進 ? "text-[#FA1F4E]" : "text-[#717684]"}`}>
                  {plan.name}
                </div>
                <div className="text-2xl font-black text-white my-1 font-sans">
                  {plan.price}
                </div>
                <div className="text-[10px] text-[#717684]">
                  {plan.subtitle}
                </div>
              </button>
            );
          })}
        </div>

        {/* Payment Method Selector */}
        <div className="relative z-10 space-y-3 mb-5">
          <div className="flex items-center justify-between text-[10px]">
            <span className="font-bold text-white uppercase tracking-wider">
              SELECT PAYMENT METHOD:
            </span>
            <span className="text-[#00e676] font-bold">
              {paymentMethod.toUpperCase()} ACTIVE
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {[
              { id: "card" as const, label: "CARD", icon: CreditCard },
              { id: "apple" as const, label: "APPLE", icon: Zap },
              { id: "gpay" as const, label: "G-PAY", icon: Sparkles },
              { id: "paypal" as const, label: "PAYPAL", icon: DollarSign },
              { id: "crypto" as const, label: "CRYPTO (USDT)", icon: Wallet },
            ].map((m) => {
              const Icon = m.icon;
              const isSelected = paymentMethod === m.id;
              return (
                <button
                  key={m.id}
                  onClick={() => {
                    setPaymentMethod(m.id);
                    setIsSuccess(false);
                  }}
                  className={`p-2.5 rounded border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                    isSelected
                      ? "bg-[#FA1F4E]/20 border-[#FA1F4E] text-white shadow-[0_0_12px_rgba(250,31,78,0.3)]"
                      : "bg-[#090b12] border-[#181c2b] text-[#717684] hover:text-white hover:border-[#333b52]"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-[9px] font-black uppercase tracking-wider">{m.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dynamic Payment Details Area */}
        <div className="relative z-10 bg-[#080a10] border border-[#161a26] rounded-lg p-4 space-y-4">
          {/* Crypto USDT Flow */}
          {paymentMethod === "crypto" && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#141824] pb-3">
                <div>
                  <span className="text-[11px] text-white font-bold block">
                    Direct USDT Payment Vault ({currentPlan.amount} USDT)
                  </span>
                  <span className="text-[9px] text-[#717684]">
                    Send exactly {currentPlan.amount} USDT to activate {currentPlan.name} license immediately.
                  </span>
                </div>

                <div className="flex items-center gap-1.5 bg-[#0e111a] p-1 rounded border border-[#1c2234] text-[9px]">
                  {(["TRC20", "ERC20", "BEP20"] as const).map((net) => (
                    <button
                      key={net}
                      onClick={() => setSelectedNetwork(net)}
                      className={`px-2 py-0.5 rounded font-bold transition-all cursor-pointer ${
                        selectedNetwork === net
                          ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/40"
                          : "text-[#717684] hover:text-white"
                      }`}
                    >
                      {net}
                    </button>
                  ))}
                </div>
              </div>

              {/* Wallet Address Box */}
              <div className="space-y-1.5">
                <span className="text-[9px] text-[#717684] uppercase block">
                  Official MemoCore Receiving Address ({selectedNetwork}):
                </span>
                <div className="flex items-center gap-2 bg-[#0c0f17] border border-[#1c2234] rounded-lg p-2.5">
                  <Wallet className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="text-white font-mono text-[11px] select-all break-all flex-1">
                    {activeAddress}
                  </span>
                  <button
                    onClick={handleCopy}
                    className="px-3 py-1 bg-cyan-500/15 border border-cyan-500/40 text-cyan-400 hover:bg-cyan-500 hover:text-black rounded text-[9px] font-black uppercase transition-all flex items-center gap-1 shrink-0 cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span>COPIED!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>COPY ADDRESS</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* TX Hash Confirmation Input */}
              <div className="space-y-1.5">
                <span className="text-[9px] text-[#717684] uppercase block">
                  Paste Blockchain Transaction Hash (TXID / Hash):
                </span>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={txHash}
                    onChange={(e) => setTxHash(e.target.value)}
                    placeholder="e.g. 8f4b2e9a1c6d7e3f0b4a5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f"
                    className="flex-1 bg-[#0c0f17] border border-[#1c2234] rounded-lg px-3 py-2 text-white text-[10px] font-mono focus:border-cyan-400 focus:outline-none placeholder-[#3b4256]"
                  />
                  <button
                    onClick={handleVerifyPayment進}
                    disabled={isVerifying || isSuccess}
                    className="px-5 py-2 rounded-lg text-white font-black text-[10px] uppercase tracking-wider bg-[#FA1F4E] hover:bg-[#ff3360] disabled:opacity-50 transition-all flex items-center gap-1.5 shadow-[0_0_15px_rgba(250,31,78,0.4)] cursor-pointer shrink-0"
                  >
                    {isVerifying ? (
                      <span className="animate-pulse">VERIFYING ON-CHAIN...</span>
                    ) : isSuccess ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                        <span>ACTIVATED!</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5" />
                        <span>SUBMIT & ACTIVATE</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {isSuccess && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-500/50 rounded-lg text-emerald-400 text-[10px] flex items-center gap-2 animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>
                    Payment verified successfully! {currentPlan.name} tier license is now active for this node.
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Standard Card / Apple / GPay / PayPal Fallbacks */}
          {paymentMethod !== "crypto" && (
            <div className="p-4 text-center space-y-3">
              <div className="text-white font-bold text-xs">
                Pay with {paymentMethod.toUpperCase()} — {currentPlan.price} {currentPlan.subtitle}
              </div>
              <p className="text-[10px] text-[#717684] max-w-md mx-auto">
                Encrypted checkout via Merchant of Record gateway with zero chargeback risk and instant license generation.
              </p>
              <button
                onClick={() => {
                  alert(`Redirecting to secure ${paymentMethod.toUpperCase()} checkout session...`);
                }}
                className="px-6 py-2.5 rounded-lg text-white font-black text-[10px] uppercase tracking-wider bg-[#FA1F4E] hover:bg-[#ff3360] transition-all shadow-[0_0_15px_rgba(250,31,78,0.4)] cursor-pointer inline-flex items-center gap-2"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>CHECKOUT WITH {paymentMethod.toUpperCase()} ({currentPlan.price})</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
