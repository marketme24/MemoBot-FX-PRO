import React, { useState, useEffect, useRef } from "react";
import { useTheme, COLOR_OPTIONS } from "./ThemeProvider";
import { PageElementsManifest } from "./inspector/PageElementsManifest";
import { 
  X, Trash2, Type, Paintbrush, Layers, ChevronUp, Check, 
  MousePointerClick, Palette, EyeOff, Sparkles, HelpCircle,
  Undo2, Redo2, LogOut, Sliders, Shield, ShieldAlert, Lock,
  Unlock, RotateCcw, Box, Eye, CheckCircle2, ChevronRight
} from "lucide-react";

// Types for the undo/redo stack
interface ColorStyles {
  color: string;
  backgroundColor: string;
  borderColor: string;
  borderWidth: string;
  borderStyle: string;
  fontSize?: string;
  padding?: string;
  borderRadius?: string;
  boxShadow?: string;
  opacity?: string;
}

interface InspectorAction {
  type: "text" | "color" | "delete" | "geometry";
  target: HTMLElement;
  oldText?: string;
  newText?: string;
  targetProperty?: "text" | "bg" | "border" | "glow";
  oldStyles?: ColorStyles;
  newStyles?: ColorStyles;
  parent?: HTMLElement;
  nextSibling?: Node | null;
}

// Preset color options for styling (deduplicated)
const RAW_INSPECTOR_COLORS = [
  ...COLOR_OPTIONS,
  { id: "#06070a", name: "Pitch Black" },
  { id: "#0d0e12", name: "Deep Charcoal" },
  { id: "#161822", name: "Border Gray" },
  { id: "#8a8d9a", name: "Text Muted" },
  { id: "#ffffff", name: "Solid White" },
  { id: "#00ffcc", name: "Cyan Glow" },
  { id: "#10b981", name: "Emerald Halal" },
  { id: "#f59e0b", name: "Amber Gold" },
  { id: "transparent", name: "Transparent" }
];

// Ensure all IDs are strictly unique
const INSPECTOR_COLORS = Array.from(
  new Map(RAW_INSPECTOR_COLORS.map(c => [c.id.toLowerCase(), c])).values()
);

export const ElementInspector: React.FC = () => {
  const { inspectorActive, setInspectorActive, accentColor } = useTheme();

  // Mode: "POINTER" for clicking on elements, "MANIFEST" for browsing all standing page elements
  const [viewMode, setViewMode] = useState<"POINTER" | "MANIFEST">("POINTER");

  // Active hover element tracking
  const [hoveredEl, setHoveredEl] = useState<HTMLElement | null>(null);
  const [hoverRect, setHoverRect] = useState<DOMRect | null>(null);

  // Selected element for editing
  const [selectedEl, setSelectedEl] = useState<HTMLElement | null>(null);
  const [selectedRect, setSelectedRect] = useState<DOMRect | null>(null);

  // Editable properties
  const [textVal, setTextVal] = useState("");
  const [customColor, setCustomColor] = useState("");
  const [activeColorTarget, setActiveColorTarget] = useState<"text" | "bg" | "border" | "glow">("border");

  // Geometry and typography tweaks
  const [fontSizeVal, setFontSizeVal] = useState<string>("12px");
  const [paddingVal, setPaddingVal] = useState<string>("8px");
  const [radiusVal, setRadiusVal] = useState<string>("6px");
  const [borderWidthVal, setBorderWidthVal] = useState<string>("1px");
  const [activeTabSub, setActiveTabSub] = useState<"colors" | "typography" | "telemetry">("colors");

  // Backup of element state when modal opens (for "Do Not Change / Revert")
  const initialElementBackup = useRef<{
    text: string;
    styles: ColorStyles;
  } | null>(null);

  // Keep a ref to the original text before edits started
  const originalTextRef = useRef<string>("");

  // Undo and Redo stacks
  const [undoStack, setUndoStack] = useState<InspectorAction[]>([]);
  const [redoStack, setRedoStack] = useState<InspectorAction[]>([]);

  // Keep a ref to the inspector panels so we don't inspect our own elements
  const inspectorPanelRef = useRef<HTMLDivElement>(null);
  const editorPanelRef = useRef<HTMLDivElement>(null);
  const closeBarRef = useRef<HTMLDivElement>(null);

  // Helpers to identify protected elements
  const isProtected = (el: HTMLElement | null): boolean => {
    if (!el) return true;
    
    // Do not inspect the sidebar
    if (el.id === "sidebar-panel" || el.closest("#sidebar-panel")) return true;
    
    // Do not inspect inspector panels
    if (
      inspectorPanelRef.current?.contains(el) || 
      editorPanelRef.current?.contains(el) ||
      closeBarRef.current?.contains(el) ||
      el.closest(".inspector-exclude")
    ) {
      return true;
    }

    // Do not inspect top-level document html or body
    if (el.tagName === "BODY" || el.tagName === "HTML" || el.id === "root") return true;

    return false;
  };

  // Helper to find parent interactive element or container (buttons, cards, inputs) for automated snapping
  const getSnappedTarget = (el: HTMLElement | null): HTMLElement | null => {
    if (!el) return null;
    
    // Walk up the DOM tree up to body, searching for common interactive / layout targets
    let current: HTMLElement | null = el;
    while (current && current.tagName !== "BODY" && current.tagName !== "HTML" && current.id !== "root") {
      const tag = current.tagName.toLowerCase();
      const classes = current.className || "";
      
      const isClassInteractive = typeof classes === "string" && (
        classes.includes("card") || 
        classes.includes("btn") || 
        classes.includes("panel") || 
        classes.includes("item") || 
        classes.includes("button") ||
        classes.includes("clickable") ||
        classes.includes("widget")
      );
      
      if (
        tag === "button" || 
        tag === "input" || 
        tag === "select" || 
        tag === "textarea" || 
        tag === "a" || 
        current.getAttribute("role") === "button" ||
        current.getAttribute("role") === "link" ||
        isClassInteractive
      ) {
        if (!isProtected(current)) {
          return current;
        }
      }
      current = current.parentElement;
    }
    
    return el;
  };

  // Setup Global Event Listeners for Pointer Mode
  useEffect(() => {
    if (!inspectorActive || viewMode !== "POINTER") {
      setHoveredEl(null);
      setHoverRect(null);
      return;
    }

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (isProtected(target)) {
        setHoveredEl(null);
        setHoverRect(null);
        return;
      }
      
      // Auto snap to nearest interactive parent node if available
      const snapped = getSnappedTarget(target) || target;
      setHoveredEl(snapped);
      setHoverRect(snapped.getBoundingClientRect());
    };

    const handleMouseOut = () => {
      setHoveredEl(null);
      setHoverRect(null);
    };

    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (isProtected(target)) {
        return;
      }

      // Block default actions and bubbling
      e.preventDefault();
      e.stopPropagation();

      const snapped = getSnappedTarget(target) || target;
      openElementEditor(snapped);

      setHoveredEl(null);
      setHoverRect(null);
    };

    window.addEventListener("mouseover", handleMouseOver, true);
    window.addEventListener("mouseout", handleMouseOut, true);
    window.addEventListener("click", handleClick, true);

    return () => {
      window.removeEventListener("mouseover", handleMouseOver, true);
      window.removeEventListener("mouseout", handleMouseOut, true);
      window.removeEventListener("click", handleClick, true);
    };
  }, [inspectorActive, viewMode]);

  // Open Element in Editor and backup initial styles
  const openElementEditor = (el: HTMLElement) => {
    setSelectedEl(el);
    setSelectedRect(el.getBoundingClientRect());

    const currentText = el.textContent?.trim() || "";
    setTextVal(currentText);
    originalTextRef.current = currentText;

    const compStyles = window.getComputedStyle(el);
    initialElementBackup.current = {
      text: currentText,
      styles: {
        color: el.style.color || compStyles.color,
        backgroundColor: el.style.backgroundColor || compStyles.backgroundColor,
        borderColor: el.style.borderColor || compStyles.borderColor,
        borderWidth: el.style.borderWidth || compStyles.borderWidth,
        borderStyle: el.style.borderStyle || compStyles.borderStyle,
        fontSize: el.style.fontSize || compStyles.fontSize,
        padding: el.style.padding || compStyles.padding,
        borderRadius: el.style.borderRadius || compStyles.borderRadius,
        boxShadow: el.style.boxShadow || compStyles.boxShadow,
        opacity: el.style.opacity || compStyles.opacity
      }
    };

    setFontSizeVal(compStyles.fontSize || "12px");
    setPaddingVal(compStyles.padding || "8px");
    setRadiusVal(compStyles.borderRadius || "6px");
    setBorderWidthVal(compStyles.borderWidth || "1px");
  };

  // Handle keyboard shortcuts (Ctrl+Z and Ctrl+Y, plus Escape to deactivate)
  useEffect(() => {
    if (!inspectorActive) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        setInspectorActive(false);
        setSelectedEl(null);
        setSelectedRect(null);
        return;
      }

      const targetTag = (e.target as HTMLElement)?.tagName;
      const isInputFocused = targetTag === "INPUT" || targetTag === "TEXTAREA";

      if (isInputFocused && e.key.toLowerCase() === "z") {
        return;
      }

      if ((e.ctrlKey || e.metaKey) && !e.shiftKey && e.key.toLowerCase() === "z") {
        e.preventDefault();
        handleUndo();
      } else if (
        (e.ctrlKey || e.metaKey) && 
        (e.key.toLowerCase() === "y" || (e.shiftKey && e.key.toLowerCase() === "z"))
      ) {
        e.preventDefault();
        handleRedo();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [inspectorActive, undoStack, redoStack, selectedEl]);

  // Handle window resize or scroll to reposition overlays
  useEffect(() => {
    const handleUpdate = () => {
      if (hoveredEl) {
        setHoverRect(hoveredEl.getBoundingClientRect());
      }
      if (selectedEl) {
        setSelectedRect(selectedEl.getBoundingClientRect());
      }
    };

    window.addEventListener("resize", handleUpdate);
    window.addEventListener("scroll", handleUpdate, true);
    return () => {
      window.removeEventListener("resize", handleUpdate);
      window.removeEventListener("scroll", handleUpdate, true);
    };
  }, [hoveredEl, selectedEl]);

  if (!inspectorActive) return null;

  // Global Undo Execution
  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const action = undoStack[undoStack.length - 1];
    
    if (action.type === "text" && action.target) {
      const target = action.target;
      const oldText = action.oldText || "";
      if (target.childNodes.length === 1 && target.childNodes[0].nodeType === Node.TEXT_NODE) {
        target.childNodes[0].textContent = oldText;
      } else {
        target.textContent = oldText;
      }
      if (selectedEl === target) {
        setTextVal(oldText);
      }
    } else if (action.type === "color" && action.target && action.oldStyles) {
      const target = action.target;
      target.style.color = action.oldStyles.color;
      target.style.backgroundColor = action.oldStyles.backgroundColor;
      target.style.borderColor = action.oldStyles.borderColor;
      target.style.borderWidth = action.oldStyles.borderWidth;
      target.style.borderStyle = action.oldStyles.borderStyle;
      if (action.oldStyles.boxShadow) target.style.boxShadow = action.oldStyles.boxShadow;
    } else if (action.type === "delete" && action.target && action.parent) {
      const parent = action.parent;
      const nextSibling = action.nextSibling;
      if (nextSibling && nextSibling.parentNode === parent) {
        parent.insertBefore(action.target, nextSibling);
      } else {
        parent.appendChild(action.target);
      }
    }

    setUndoStack(prev => prev.slice(0, -1));
    setRedoStack(prev => [...prev, action]);

    setTimeout(() => {
      if (selectedEl) setSelectedRect(selectedEl.getBoundingClientRect());
    }, 40);
  };

  // Global Redo Execution
  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const action = redoStack[redoStack.length - 1];

    if (action.type === "text" && action.target) {
      const target = action.target;
      const newText = action.newText || "";
      if (target.childNodes.length === 1 && target.childNodes[0].nodeType === Node.TEXT_NODE) {
        target.childNodes[0].textContent = newText;
      } else {
        target.textContent = newText;
      }
      if (selectedEl === target) {
        setTextVal(newText);
      }
    } else if (action.type === "color" && action.target && action.newStyles) {
      const target = action.target;
      target.style.color = action.newStyles.color;
      target.style.backgroundColor = action.newStyles.backgroundColor;
      target.style.borderColor = action.newStyles.borderColor;
      target.style.borderWidth = action.newStyles.borderWidth;
      target.style.borderStyle = action.newStyles.borderStyle;
      if (action.newStyles.boxShadow) target.style.boxShadow = action.newStyles.boxShadow;
    } else if (action.type === "delete" && action.target) {
      action.target.remove();
      if (selectedEl === action.target) {
        setSelectedEl(null);
        setSelectedRect(null);
      }
    }

    setRedoStack(prev => prev.slice(0, -1));
    setUndoStack(prev => [...prev, action]);

    setTimeout(() => {
      if (selectedEl) setSelectedRect(selectedEl.getBoundingClientRect());
    }, 40);
  };

  // Helper to push text edits into undo stack cleanly
  const pushTextAction = (element: HTMLElement, oldText: string, newText: string) => {
    setUndoStack(prev => {
      if (prev.length > 0) {
        const last = prev[prev.length - 1];
        if (last.type === "text" && last.target === element) {
          const updated = [...prev];
          updated[updated.length - 1] = { ...last, newText };
          return updated;
        }
      }
      return [...prev, { type: "text", target: element, oldText, newText }];
    });
    setRedoStack([]);
  };

  // Live Property Modifications
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    setTextVal(val);
    if (selectedEl) {
      if (selectedEl.childNodes.length === 1 && selectedEl.childNodes[0].nodeType === Node.TEXT_NODE) {
        selectedEl.childNodes[0].textContent = val;
      } else {
        selectedEl.textContent = val;
      }
      selectedEl.setAttribute("data-inspector-modified", "true");
      pushTextAction(selectedEl, originalTextRef.current, val);
    }
  };

  const applyColor = (color: string) => {
    if (!selectedEl) return;
    
    const oldStyles: ColorStyles = {
      color: selectedEl.style.color || "",
      backgroundColor: selectedEl.style.backgroundColor || "",
      borderColor: selectedEl.style.borderColor || "",
      borderWidth: selectedEl.style.borderWidth || "",
      borderStyle: selectedEl.style.borderStyle || "",
      boxShadow: selectedEl.style.boxShadow || ""
    };

    if (activeColorTarget === "text") {
      selectedEl.style.color = color;
    } else if (activeColorTarget === "bg") {
      selectedEl.style.backgroundColor = color;
    } else if (activeColorTarget === "border") {
      selectedEl.style.borderColor = color;
      selectedEl.style.borderWidth = color === "transparent" ? "0px" : borderWidthVal || "1px";
      selectedEl.style.borderStyle = color === "transparent" ? "none" : "solid";
    } else if (activeColorTarget === "glow") {
      selectedEl.style.boxShadow = color === "transparent" ? "none" : `0 0 20px ${color}50`;
    }

    selectedEl.setAttribute("data-inspector-modified", "true");

    const newStyles: ColorStyles = {
      color: selectedEl.style.color || "",
      backgroundColor: selectedEl.style.backgroundColor || "",
      borderColor: selectedEl.style.borderColor || "",
      borderWidth: selectedEl.style.borderWidth || "",
      borderStyle: selectedEl.style.borderStyle || "",
      boxShadow: selectedEl.style.boxShadow || ""
    };

    setUndoStack(prev => [...prev, {
      type: "color",
      target: selectedEl,
      targetProperty: activeColorTarget,
      oldStyles,
      newStyles
    }]);
    setRedoStack([]);

    setSelectedRect(selectedEl.getBoundingClientRect());
  };

  const handleCustomColorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (/^#([0-9A-F]{3}){1,2}$/i.test(customColor) || customColor === "transparent") {
      applyColor(customColor);
    }
  };

  // OPTION 1: APPLY CHANGES & CONFIRM
  const handleApplyChanges = () => {
    if (selectedEl) {
      selectedEl.setAttribute("data-inspector-modified", "true");
    }
    setSelectedEl(null);
    setSelectedRect(null);
  };

  // OPTION 2: DO NOT CHANGE / REVERT ORIGINAL
  const handleDiscardAndRevert = () => {
    if (selectedEl && initialElementBackup.current) {
      const { text, styles } = initialElementBackup.current;
      selectedEl.textContent = text;
      selectedEl.style.color = styles.color;
      selectedEl.style.backgroundColor = styles.backgroundColor;
      selectedEl.style.borderColor = styles.borderColor;
      selectedEl.style.borderWidth = styles.borderWidth;
      selectedEl.style.borderStyle = styles.borderStyle;
      if (styles.fontSize) selectedEl.style.fontSize = styles.fontSize;
      if (styles.padding) selectedEl.style.padding = styles.padding;
      if (styles.borderRadius) selectedEl.style.borderRadius = styles.borderRadius;
      if (styles.boxShadow) selectedEl.style.boxShadow = styles.boxShadow;
      selectedEl.removeAttribute("data-inspector-modified");
    }
    setSelectedEl(null);
    setSelectedRect(null);
  };

  const deleteElement = () => {
    if (!selectedEl) return;
    if (window.confirm(`Are you sure you want to delete this <${selectedEl.tagName.toLowerCase()}> element?`)) {
      const parent = selectedEl.parentElement;
      const nextSibling = selectedEl.nextSibling;

      setUndoStack(prev => [...prev, {
        type: "delete",
        target: selectedEl,
        parent: parent || undefined,
        nextSibling: nextSibling || null
      }]);
      setRedoStack([]);

      selectedEl.remove();
      setSelectedEl(null);
      setSelectedRect(null);
    }
  };

  const selectParent = () => {
    if (!selectedEl) return;
    const parent = selectedEl.parentElement;
    if (isProtected(parent)) {
      alert("Cannot select parent element because it is part of a protected layout (sidebar, root, or body).");
      return;
    }
    openElementEditor(parent);
  };

  const getElementClassString = (el: HTMLElement) => {
    const classes = Array.from(el.classList).filter(c => !c.startsWith("inspector-"));
    if (classes.length === 0) return "";
    return "." + classes.slice(0, 3).join(".");
  };

  return (
    <div className="inspector-exclude fixed inset-0 z-[9999] pointer-events-none text-xs font-mono">
      
      {/* Prominent floating Top Control Bar */}
      <div 
        ref={closeBarRef}
        className="pointer-events-auto fixed top-4 left-1/2 -translate-x-1/2 bg-[#0d0e12]/95 backdrop-blur-md border border-[#23273a] rounded-full px-5 py-2 shadow-[0_10px_35px_rgba(0,0,0,0.8)] flex items-center gap-4 text-white z-[99999]"
      >
        <div className="flex items-center gap-2">
          <span className="flex h-2.5 w-2.5 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
          </span>
          <span className="text-[10px] uppercase font-black tracking-widest text-[#FA1F4E] font-sans">
            MODIFIER CORE ACTIVE
          </span>
        </div>

        {/* View Switcher: Pointer vs Standing Page Manifest */}
        <div className="flex items-center bg-[#06070a] p-0.5 rounded-full border border-[#1a1d26]">
          <button
            onClick={() => {
              setViewMode("POINTER");
              setSelectedEl(null);
            }}
            className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase transition-all flex items-center gap-1.5 ${
              viewMode === "POINTER"
                ? "bg-[#FA1F4E] text-white shadow-sm"
                : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            <MousePointerClick className="w-3 h-3" />
            <span>Pointer Select</span>
          </button>
          <button
            onClick={() => {
              setViewMode("MANIFEST");
              setSelectedEl(null);
            }}
            className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase transition-all flex items-center gap-1.5 ${
              viewMode === "MANIFEST"
                ? "bg-[#FA1F4E] text-white shadow-sm"
                : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            <Layers className="w-3 h-3" />
            <span>Standing Page Elements</span>
          </button>
        </div>

        <div className="h-4 w-[1px] bg-[#23273a]" />

        {/* Exit button */}
        <button
          onClick={() => {
            setInspectorActive(false);
            setSelectedEl(null);
            setSelectedRect(null);
          }}
          className="px-3.5 py-1 bg-red-600 hover:bg-red-500 text-white font-black uppercase text-[10px] tracking-wider rounded-full transition-all active:scale-95 flex items-center gap-1 shadow-[0_0_15px_rgba(250,31,78,0.4)]"
          title="Exit and Deactivate Modifier Core"
        >
          <X className="w-3.5 h-3.5" />
          <span>Exit (ESC)</span>
        </button>
      </div>

      {/* Manifest View Modal */}
      {viewMode === "MANIFEST" && !selectedEl && (
        <PageElementsManifest
          accentColor={accentColor}
          onSelectElement={(el) => {
            openElementEditor(el);
          }}
          onHighlightElement={(el) => {
            if (el) {
              setHoveredEl(el);
              setHoverRect(el.getBoundingClientRect());
            } else {
              setHoveredEl(null);
              setHoverRect(null);
            }
          }}
          onClose={() => setViewMode("POINTER")}
        />
      )}

      {/* Floating HUD Card for Pointer Mode */}
      {viewMode === "POINTER" && !selectedEl && (
        <div 
          ref={inspectorPanelRef}
          style={{ borderColor: `${accentColor}40` }}
          className="pointer-events-auto fixed top-20 right-4 bg-[#0a0c10] border rounded-lg p-3.5 w-72 shadow-2xl space-y-3 font-mono text-white"
        >
          <div className="flex items-center justify-between border-b border-[#161822] pb-1.5">
            <div className="flex items-center gap-1.5 font-bold uppercase tracking-wider">
              <MousePointerClick className="w-4 h-4 animate-pulse" style={{ color: accentColor }} />
              <span style={{ color: accentColor }}>POINTER INSPECTOR</span>
            </div>
            <button 
              onClick={() => setInspectorActive(false)}
              className="p-1 hover:bg-[#1c1f2b] rounded text-[#8a8d9a] hover:text-white transition-all"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 gap-1.5 bg-[#050608] p-1 border border-[#161822] rounded">
            <button
              onClick={handleUndo}
              disabled={undoStack.length === 0}
              className={`py-1 rounded text-[10px] font-bold uppercase flex items-center justify-center gap-1 transition-all ${
                undoStack.length === 0 
                  ? "text-[#444] bg-transparent cursor-not-allowed" 
                  : "text-white bg-[#12141a] hover:bg-[#1d212b]"
              }`}
            >
              <Undo2 className="w-3 h-3 text-amber-500" />
              Undo ({undoStack.length})
            </button>
            <button
              onClick={handleRedo}
              disabled={redoStack.length === 0}
              className={`py-1 rounded text-[10px] font-bold uppercase flex items-center justify-center gap-1 transition-all ${
                redoStack.length === 0 
                  ? "text-[#444] bg-transparent cursor-not-allowed" 
                  : "text-white bg-[#12141a] hover:bg-[#1d212b]"
              }`}
            >
              <Redo2 className="w-3 h-3 text-emerald-500" />
              Redo ({redoStack.length})
            </button>
          </div>

          <div className="text-[10px] text-[#8a8d9a] leading-relaxed space-y-1.5 bg-[#06070a] p-2.5 rounded border border-[#141722]">
            <p>🎯 <span className="text-white font-bold">Pointer Snap:</span> Active</p>
            <p>👉 Left-Click any element on the current screen to modify colors, borders, and text.</p>
            <button
              onClick={() => setViewMode("MANIFEST")}
              className="w-full mt-2 py-1.5 bg-[#141722] hover:bg-[#1f2438] text-white rounded text-[10px] font-bold uppercase flex items-center justify-center gap-1 border border-[#23273a]"
            >
              <Layers className="w-3 h-3 text-[#FA1F4E]" />
              <span>View All Elements List</span>
            </button>
          </div>
        </div>
      )}

      {/* Hover Outline Overlay */}
      {hoverRect && hoveredEl && (
        <div 
          style={{
            position: "absolute",
            left: `${hoverRect.left + window.scrollX}px`,
            top: `${hoverRect.top + window.scrollY}px`,
            width: `${hoverRect.width}px`,
            height: `${hoverRect.height}px`,
            borderColor: accentColor,
            boxShadow: `0 0 15px ${accentColor}50, inset 0 0 12px ${accentColor}25`,
            backgroundColor: `${accentColor}08`
          }}
          className="border-2 rounded transition-all pointer-events-none duration-75 flex items-start"
        >
          <div 
            style={{ backgroundColor: accentColor }}
            className="absolute -top-5 left-0 px-1.5 py-0.5 text-[8px] text-black font-extrabold rounded-r uppercase tracking-wider whitespace-nowrap shadow-md flex items-center gap-1"
          >
            <span className="bg-black/20 px-1 rounded font-black">SNAP</span>
            {hoveredEl.tagName.toLowerCase()}
            <span className="text-[7px] text-black/70 font-mono">
              {getElementClassString(hoveredEl)} ({Math.round(hoverRect.width)}×{Math.round(hoverRect.height)})
            </span>
          </div>
        </div>
      )}

      {/* Selected Element Overlay */}
      {selectedRect && selectedEl && (
        <div 
          style={{
            position: "absolute",
            left: `${selectedRect.left + window.scrollX}px`,
            top: `${selectedRect.top + window.scrollY}px`,
            width: `${selectedRect.width}px`,
            height: `${selectedRect.height}px`,
            borderColor: "#eab308",
            boxShadow: `0 0 25px rgba(234, 179, 8, 0.6), inset 0 0 15px rgba(234, 179, 8, 0.3)`
          }}
          className="border-2 border-dashed rounded transition-all pointer-events-none"
        >
          <div className="absolute -top-5 left-0 bg-[#eab308] px-1.5 py-0.5 text-[8px] text-black font-extrabold rounded-r uppercase tracking-wider whitespace-nowrap shadow-md">
            EDITING: {selectedEl.tagName.toLowerCase()}
          </div>
        </div>
      )}

      {/* Enhanced MODIFIER CORE Floating Dialog with TWO EXPLICIT OPTIONS */}
      {selectedEl && (
        <div 
          ref={editorPanelRef}
          style={{ borderColor: `${accentColor}50` }}
          className="pointer-events-auto fixed bottom-4 left-1/2 -translate-x-1/2 w-full max-w-4xl bg-[#08090d] border p-4 sm:p-5 rounded-xl shadow-[0_0_60px_rgba(0,0,0,0.95)] flex flex-col gap-4 font-mono text-white text-xs z-[99999] max-h-[85vh] overflow-y-auto animate-in fade-in slide-in-from-bottom-5 duration-150"
        >
          
          {/* Header with Element Tag, Parent Button & Close */}
          <div className="flex items-center justify-between border-b border-[#161822] pb-3">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 text-[#eab308] animate-pulse" />
              <h3 className="font-extrabold text-[#eab308] text-sm uppercase tracking-wider">
                MODIFIER CORE • &lt;{selectedEl.tagName.toLowerCase()}&gt;
              </h3>
              <span className="text-[9px] bg-[#12141a] px-2 py-0.5 rounded border border-[#222] text-[#8a8d9a]">
                {selectedEl.id ? `#${selectedEl.id}` : "No ID attribute"}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={selectParent}
                className="py-1 px-2.5 bg-[#12141f] hover:bg-[#1a1e30] border border-[#23273a] rounded text-[9px] font-bold uppercase text-white flex items-center gap-1"
                title="Select parent layer"
              >
                <ChevronUp className="w-3 h-3 text-[#eab308]" />
                Select Parent
              </button>
              <button
                onClick={deleteElement}
                className="py-1 px-2.5 bg-red-950/40 hover:bg-red-900/40 border border-red-900/50 rounded text-[9px] font-bold uppercase text-red-400 flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" />
                Delete
              </button>
            </div>
          </div>

          {/* Main 2-Column Editor Body */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            
            {/* Left Column: Text and Typography Tweaks (5 cols) */}
            <div className="md:col-span-6 space-y-3">
              <div className="space-y-1">
                <label className="text-[9px] text-[#8a8d9a] font-bold uppercase flex items-center gap-1">
                  <Type className="w-3 h-3 text-[#eab308]" />
                  EDIT INNER TEXT CONTENT
                </label>
                <textarea
                  value={textVal}
                  onChange={handleTextChange}
                  placeholder="Type here to live modify text on this element..."
                  className="w-full h-24 bg-[#040507] border border-[#161822] focus:border-[#eab308] text-white p-2.5 rounded text-[11px] outline-none resize-none font-mono"
                />
              </div>

              {/* Undo / Redo Row */}
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={handleUndo}
                  disabled={undoStack.length === 0}
                  className={`py-1 rounded text-[10px] font-bold uppercase flex items-center justify-center gap-1.5 transition-all border ${
                    undoStack.length === 0 
                      ? "text-[#444] bg-transparent border-transparent cursor-not-allowed" 
                      : "text-white bg-[#12141a] border-[#222] hover:bg-[#1d212b]"
                  }`}
                >
                  <Undo2 className="w-3.5 h-3.5 text-amber-500" />
                  Undo ({undoStack.length})
                </button>
                <button
                  onClick={handleRedo}
                  disabled={redoStack.length === 0}
                  className={`py-1 rounded text-[10px] font-bold uppercase flex items-center justify-center gap-1.5 transition-all border ${
                    redoStack.length === 0 
                      ? "text-[#444] bg-transparent border-transparent cursor-not-allowed" 
                      : "text-white bg-[#12141a] border-[#222] hover:bg-[#1d212b]"
                  }`}
                >
                  <Redo2 className="w-3.5 h-3.5 text-emerald-500" />
                  Redo ({redoStack.length})
                </button>
              </div>

              {/* Computed Telemetry Badge */}
              <div className="bg-[#040507] p-2.5 rounded border border-[#141722] space-y-1 text-[9px] text-[#777]">
                <span className="text-white font-bold block uppercase">CURRENT COMPUTED STYLES:</span>
                <div className="grid grid-cols-2 gap-1 text-[9px]">
                  <span>COLOR: <strong className="text-white">{selectedEl.style.color || window.getComputedStyle(selectedEl).color}</strong></span>
                  <span>BG: <strong className="text-white">{selectedEl.style.backgroundColor || window.getComputedStyle(selectedEl).backgroundColor}</strong></span>
                  <span>BORDER: <strong className="text-white">{selectedEl.style.borderColor || window.getComputedStyle(selectedEl).borderColor}</strong></span>
                  <span>SIZE: <strong className="text-white">{Math.round(selectedEl.getBoundingClientRect().width)}×{Math.round(selectedEl.getBoundingClientRect().height)}px</strong></span>
                </div>
              </div>
            </div>

            {/* Right Column: Color Swapper & Geometry (6 cols) */}
            <div className="md:col-span-6 space-y-3 md:border-l border-[#161822] md:pl-5">
              <span className="font-extrabold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5" style={{ color: accentColor }} />
                SWAP STYLE COLORS
              </span>

              {/* Target Selector Tabs: Text, BG, Border, Glow */}
              <div className="grid grid-cols-4 gap-1">
                {(["text", "bg", "border", "glow"] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setActiveColorTarget(t)}
                    style={activeColorTarget === t ? { backgroundColor: `${accentColor}25`, borderColor: accentColor, color: "#fff" } : {}}
                    className="py-1 text-[9px] uppercase rounded border border-transparent font-black tracking-wider text-[#8a8d9a] bg-[#11131c] hover:border-[#333]"
                  >
                    {t === "text" && "TEXT"}
                    {t === "bg" && "BG FILL"}
                    {t === "border" && "BORDER"}
                    {t === "glow" && "GLOW"}
                  </button>
                ))}
              </div>

              {/* Color Presets Grid */}
              <div className="grid grid-cols-5 gap-1.5">
                {INSPECTOR_COLORS.map((color) => (
                  <button
                    key={color.id}
                    onClick={() => applyColor(color.id)}
                    className="h-7 rounded border border-white/15 hover:border-white transition-all flex items-center justify-center relative group"
                    style={{ 
                      backgroundColor: color.id === "transparent" ? undefined : color.id,
                      background: color.id === "transparent" ? "repeating-linear-gradient(45deg, #111, #111 2px, #333 2px, #333 4px)" : undefined
                    }}
                    title={color.name}
                  >
                    <span className="hidden group-hover:block absolute bottom-full bg-black text-[7px] text-white px-1 py-0.5 rounded -mb-1 z-10 whitespace-nowrap shadow">
                      {color.name}
                    </span>
                  </button>
                ))}
              </div>

              {/* Custom Hex Color Input Form */}
              <form onSubmit={handleCustomColorSubmit} className="flex gap-1.5 pt-1">
                <input
                  type="text"
                  placeholder="#00FFCC or transparent"
                  value={customColor}
                  onChange={(e) => setCustomColor(e.target.value)}
                  className="flex-1 bg-[#040507] border border-[#161822] focus:border-[#eab308] text-white px-2 py-1 rounded text-[10px] outline-none font-mono"
                />
                <button
                  type="submit"
                  style={{ backgroundColor: accentColor }}
                  className="px-3 py-1 rounded text-[9px] font-bold text-white uppercase hover:brightness-110"
                >
                  APPLY HEX
                </button>
              </form>
            </div>
          </div>

          {/* Bottom Action Footer with TWO CLEAR OPTIONS */}
          <div className="pt-3 border-t border-[#161822] grid grid-cols-1 sm:grid-cols-2 gap-3">
            
            {/* OPTION 1: APPLY CHANGES */}
            <button
              onClick={handleApplyChanges}
              style={{ backgroundColor: accentColor }}
              className="py-2.5 px-4 rounded font-black text-[11px] uppercase tracking-wider text-white hover:opacity-95 transition-all shadow-[0_0_20px_rgba(250,31,78,0.35)] flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>OPTION 1: APPLY CHANGES & SAVE</span>
            </button>

            {/* OPTION 2: DO NOT CHANGE / DISCARD */}
            <button
              onClick={handleDiscardAndRevert}
              className="py-2.5 px-4 rounded font-bold text-[11px] uppercase tracking-wider bg-[#141722] hover:bg-[#202538] border border-[#272c40] text-slate-300 hover:text-white transition-all flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4 text-amber-400" />
              <span>OPTION 2: DO NOT CHANGE (DISCARD)</span>
            </button>
          </div>

        </div>
      )}
    </div>
  );
};
