import React from "react";
import { Clock, Send, CheckCircle, AlertTriangle, Trash2, Globe } from "lucide-react";
import { ActivityQueueItem } from "../../types";

interface ActivityQueueListProps {
  queue: ActivityQueueItem[];
  onClear: (id: string) => void;
}

export const ActivityQueueList: React.FC<ActivityQueueListProps> = ({
  queue,
  onClear
}) => {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Sent":
        return (
          <span className="flex items-center gap-1 text-[6.5px] font-mono font-black text-emerald-400 uppercase bg-emerald-950/20 border border-emerald-500/20 px-1.5 py-0.2 rounded">
            <CheckCircle className="w-2 h-2 text-emerald-400" /> SENT
          </span>
        );
      case "Failed":
        return (
          <span className="flex items-center gap-1 text-[6.5px] font-mono font-black text-red-400 uppercase bg-red-950/20 border border-red-500/20 px-1.5 py-0.2 rounded animate-pulse">
            <AlertTriangle className="w-2 h-2 text-red-400" /> FAILED
          </span>
        );
      default:
        return (
          <span className="flex items-center gap-1 text-[6.5px] font-mono font-black text-amber-400 uppercase bg-amber-950/20 border border-amber-500/20 px-1.5 py-0.2 rounded">
            <Clock className="w-2 h-2 text-amber-400 animate-pulse" /> PENDING
          </span>
        );
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#02050e]/95 border border-slate-900 rounded-lg p-3 font-mono text-[8px] text-[#22d3ee] shadow-[inset_0_0_12px_rgba(0,0,0,0.95)]">
      {/* List Header */}
      <div className="flex items-center justify-between border-b border-slate-900/60 pb-1.5 mb-1.5 font-bold tracking-wider text-slate-400 uppercase">
        <span className="flex items-center gap-1">
          <Globe className="w-2.5 h-2.5 text-red-500 animate-spin" /> ORGANIC DAILY OUTBOUND QUEUE
        </span>
        <span className="text-slate-500 font-mono text-[7px] font-bold">TOTAL OUTBOX: {queue.length}</span>
      </div>

      {/* Queue items */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 max-h-[175px]">
        {queue.length === 0 ? (
          <div className="h-full flex items-center justify-center text-slate-500 uppercase tracking-widest text-center py-8">
            NO ACTIVE OUTBOUND APPROACHES SCHEDULED. GENERATE TO SEED THE PROTOCOL.
          </div>
        ) : (
          queue.map((item) => (
            <div 
              key={item.id} 
              className="flex items-start justify-between bg-black/50 border border-slate-900 rounded p-2 gap-2 hover:bg-slate-950/40 transition-all"
            >
              <div className="flex-1 min-w-0">
                {/* Meta details */}
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-[7.5px] font-black text-white uppercase tracking-wider">
                    {item.platform}
                  </span>
                  <span className="text-[6px] text-slate-500 uppercase truncate max-w-[120px]">
                    CAMP: {item.campaignName}
                  </span>
                  <span className="text-[6.5px] text-[#22d3ee] font-bold">
                    TO: {item.recipient}
                  </span>
                </div>

                {/* Simulated Content Bubble */}
                <p className="text-slate-300 leading-relaxed break-words pl-1.5 border-l border-slate-900 font-sans text-[9px]">
                  {item.content}
                </p>

                {/* Optional Attached Picture / Mockup Card */}
                {item.imageUrl && (
                  <div className="mt-2 relative max-w-[200px] border border-slate-800/80 rounded overflow-hidden shadow-inner bg-black/40">
                    <img 
                      src={item.imageUrl} 
                      alt="Campaign Attachment" 
                      className="w-full h-20 object-cover opacity-85 hover:opacity-100 transition-opacity"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-1 right-1 bg-black/80 px-1 py-0.2 rounded text-[5px] font-mono text-[#00ffcc]">
                      AI DYNAMIC VISUAL
                    </div>
                  </div>
                )}

                {/* Scheduled time details */}
                <div className="text-[5.5px] text-slate-500 uppercase tracking-widest mt-1">
                  SCHEDULED AT: {new Date(item.scheduledAt).toLocaleTimeString()}
                </div>
              </div>

              {/* Status & actions */}
              <div className="flex flex-col items-end justify-between gap-2 self-stretch">
                {getStatusBadge(item.status)}
                
                {/* Action clear */}
                <button
                  onClick={() => onClear(item.id)}
                  className="text-slate-500 hover:text-red-400 transition-colors cursor-pointer p-0.5"
                  title="Remove Outbound Approach"
                >
                  <Trash2 className="w-2.5 h-2.5" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
export default ActivityQueueList;
