import React, { useState, useRef, useEffect } from "react";
import { Mic, MicOff, Square, Loader2 } from "lucide-react";
import { ApiClient } from "../services/api";

interface VoiceInputButtonProps {
  onTranscribe: (text: string) => void;
  disabled?: boolean;
  className?: string;
  buttonLabel?: string;
  compact?: boolean;
}

export const VoiceInputButton: React.FC<VoiceInputButtonProps> = ({
  onTranscribe,
  disabled = false,
  className = "",
  buttonLabel,
  compact = false
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [recordDuration, setRecordDuration] = useState(0);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const startRecording = async () => {
    setErrorMsg(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        setErrorMsg("Microphone access is not supported in this browser environment.");
        return;
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      let mimeType = "audio/webm;codecs=opus";
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        if (MediaRecorder.isTypeSupported("audio/webm")) {
          mimeType = "audio/webm";
        } else if (MediaRecorder.isTypeSupported("audio/mp4")) {
          mimeType = "audio/mp4";
        } else if (MediaRecorder.isTypeSupported("audio/ogg")) {
          mimeType = "audio/ogg";
        } else {
          mimeType = "";
        }
      }

      const mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: mimeType || "audio/webm"
        });
        
        // Stop audio tracks
        if (streamRef.current) {
          streamRef.current.getTracks().forEach((track) => track.stop());
          streamRef.current = null;
        }

        if (audioBlob.size === 0) {
          setIsTranscribing(false);
          return;
        }

        setIsTranscribing(true);
        try {
          // Convert Blob to Base64
          const reader = new FileReader();
          reader.readAsDataURL(audioBlob);
          reader.onloadend = async () => {
            try {
              const base64Audio = reader.result as string;
              const response = await ApiClient.post("/ai/transcribe", {
                audio: base64Audio,
                mimeType: audioBlob.type || "audio/webm"
              });

              if (response && response.text) {
                onTranscribe(response.text);
              } else {
                setErrorMsg("No speech detected.");
              }
            } catch (err: any) {
              console.error("Transcription API failure:", err);
              setErrorMsg(err.message || "Failed to transcribe audio.");
            } finally {
              setIsTranscribing(false);
            }
          };
        } catch (err: any) {
          console.error("Blob read error:", err);
          setIsTranscribing(false);
          setErrorMsg("Audio processing error.");
        }
      };

      mediaRecorder.start(250);
      setIsRecording(true);
      setRecordDuration(0);

      timerRef.current = setInterval(() => {
        setRecordDuration((prev) => prev + 1);
      }, 1000);
    } catch (err: any) {
      console.error("Microphone capture failed:", err);
      setIsRecording(false);
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        setErrorMsg("Microphone permission denied.");
      } else {
        setErrorMsg("Unable to access microphone.");
      }
    }
  };

  const stopRecording = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    setIsRecording(false);
  };

  const toggleRecording = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isTranscribing || disabled) return;

    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins}:${rem < 10 ? "0" : ""}${rem}`;
  };

  return (
    <div className="relative inline-flex items-center">
      <button
        type="button"
        onClick={toggleRecording}
        disabled={disabled || isTranscribing}
        title={
          isRecording
            ? "Click to stop recording & transcribe with Gemini 3.5"
            : "Click to record voice input (Microphone Transcription via Gemini 3.5 Transcribe)"
        }
        className={`relative flex items-center justify-center font-mono font-bold transition-all cursor-pointer select-none ${
          isRecording
            ? "bg-red-500/20 border border-red-500 text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.4)] animate-pulse"
            : isTranscribing
            ? "bg-amber-500/20 border border-amber-500/40 text-amber-300"
            : "bg-[#0e1118] hover:bg-[#161a24] border border-[#1a1e2b] hover:border-[#FA1F4E]/60 text-slate-300 hover:text-white"
        } ${
          compact
            ? "p-2 rounded-lg text-xs"
            : "px-3 py-2 rounded-lg gap-2 text-xs"
        } ${className}`}
      >
        {isTranscribing ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
            {!compact && <span className="text-[10px] tracking-wider uppercase">Transcribing...</span>}
          </>
        ) : isRecording ? (
          <>
            <span className="relative flex h-2 w-2 mr-0.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
            </span>
            <Square className="w-3.5 h-3.5 fill-current text-red-400" />
            <span className="text-[10px] font-bold font-mono text-red-400">
              {formatTime(recordDuration)}
            </span>
            {!compact && <span className="text-[9px] uppercase tracking-wider text-red-300 ml-1">STOP</span>}
          </>
        ) : (
          <>
            <Mic className="w-4 h-4 text-[#FA1F4E]" />
            {!compact && <span>{buttonLabel || "VOICE INPUT"}</span>}
          </>
        )}
      </button>

      {errorMsg && (
        <div className="absolute -top-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-red-950/90 border border-red-500/50 text-red-200 text-[9px] px-2 py-0.5 rounded shadow-lg z-50 animate-fade-in">
          {errorMsg}
        </div>
      )}
    </div>
  );
};
