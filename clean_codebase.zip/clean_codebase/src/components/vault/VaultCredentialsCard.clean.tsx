import React from "react";
import { Shield, CheckCircle, AlertTriangle, RefreshCw, Activity } from "lucide-react";

export interface ServiceCredentialConfig {
  id: string;
  label: string;
  fields: string[];
  help: string;
}

interface TestResult {
  status: "idle" | "testing" | "success" | "error";
  message?: string;
  latency_ms?: number;
  timestamp?: string;
}

interface VaultCredentialsCardProps {
  service: ServiceCredentialConfig;
  isConfigured: boolean;
  formValues: { api_key: string; api_secret: string; api_passphrase?: string };
  onInputChange: (field: "api_key" | "api_secret" | "api_passphrase", value: string) => void;
  onSave: () => void;
  onTest: () => void;
  isSaving: boolean;
  testResult?: TestResult;
  saveMessage?: { type: "success" | "error"; text: string } | null;
  // Slots support
  isExchange?: boolean;
  activeSlot?: number;
  unlockedSlots?: number[];
  onSelectSlot?: (slot: number) => void;
  onAddSlot?: () => void;
  slotConfiguredStates?: Record<number, boolean>;
}

export const VaultCredentialsCard: React.FC<VaultCredentialsCardProps> = ({
  service,
  isConfigured,
  formValues,
  onInputChange,
  onSave,
  onTest,
  isSaving,
  testResult,
  saveMessage,
  isExchange = false,
  activeSlot = 1,
  unlockedSlots = [1],
  onSelectSlot,
  onAddSlot,
  slotConfiguredStates = {},
}) => {
  const isTesting = testResult?.status === "testing";

  const renderServiceLogo = () => {
    switch (service.id) {
      case "Binance":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2.5L15.5 6L12 9.5L8.5 6L12 2.5Z" fill="#F0B90B" />
            <path d="M6 8.5L9.5 12L6 15.5L2.5 12L6 8.5Z" fill="#F0B90B" />
            <path d="M18 8.5L21.5 12L18 15.5L14.5 12L18 8.5Z" fill="#F0B90B" />
            <path d="M12 14.5L15.5 18L12 21.5L8.5 18L12 14.5Z" fill="#F0B90B" />
            <path d="M12 7.5L16.5 12L12 16.5L7.5 12L12 7.5Z" fill="#F0B90B" />
          </svg>
        );
      case "KuCoin":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="3" y="3" width="7" height="18" rx="1.5" fill="#00e676" />
            <path d="M11 3H16.5C18.43 3 20 4.57 20 6.5C20 8.43 18.43 10 16.5 10H11V3Z" fill="#00b0ff" />
            <path d="M11 11H15.5C17.99 11 20 13.01 20 15.5C20 17.99 17.99 20 15.5 20H11V11Z" fill="#00e676" />
          </svg>
        );
      case "OKX":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect x="2" y="2" width="6" height="6" rx="1" fill="#FFFFFF" />
            <rect x="10" y="2" width="6" height="6" rx="1" fill="#FFFFFF" />
            <rect x="2" y="10" width="6" height="6" rx="1" fill="#FFFFFF" />
            <rect x="10" y="10" width="6" height="6" rx="1" fill="#FFFFFF" />
            <rect x="18" y="10" width="4" height="4" rx="1" fill="#FFFFFF" />
            <rect x="10" y="18" width="6" height="6" rx="1" fill="#FFFFFF" />
            <rect x="2" y="18" width="6" height="6" rx="1" fill="#FFFFFF" />
          </svg>
        );
      case "Bybit":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6 3H10L14 12L10 21H6L10 12L6 3Z" fill="#F0A500" />
            <path d="M14 3H18L22 12L18 21H14L18 12L14 3Z" fill="#FFB11A" />
          </svg>
        );
      case "Telegram":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="11" fill="#229ED9" />
            <path d="M17.5 8L6.5 12.2L10.2 13.7L11.4 17.5L13.2 14.5L16.5 15.8L17.5 8Z" fill="white" />
          </svg>
        );
      case "WhatsApp":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="12" cy="12" r="11" fill="#25D366" />
            <path d="M12 6C8.69 6 6 8.69 6 12C6 13.28 6.4 14.47 7.09 15.45L6.3 18L8.94 17.48C9.88 18.12 11.02 18.5 12 18.5C15.31 18.5 18 15.81 18 12.5C18 9.19 15.31 6 12 6ZM14.85 14.2C14.65 14.4 14.2 14.5 13.9 14.5C13.6 14.5 13.2 14.4 12.5 14.1C11 13.5 10 11.8 9.9 11.6C9.8 11.4 9.15 10.5 9.15 9.6C9.15 8.7 9.6 8.25 9.8 8.05C10 7.85 10.25 7.8 10.45 7.8H10.9C11.1 7.8 11.3 7.8 11.45 8.15C11.65 8.6 11.95 9.4 12 9.5C12.05 9.6 12.05 9.75 11.95 9.95C11.85 10.15 11.75 10.25 11.6 10.4C11.45 10.55 11.3 10.75 11.15 10.9C11.3 11.15 11.65 11.55 12.15 12C12.8 12.6 13.3 12.8 13.55 12.95C13.8 13.1 13.95 13.05 14.1 12.9C14.25 12.75 14.65 12.25 14.85 11.95C15.05 11.65 15.25 11.7 15.45 11.8C15.65 11.9 16.7 12.4 16.8 12.5C16.9 12.6 17 12.65 17 12.75C17 13.1 15.8 14.1 14.85 14.2Z" fill="white" />
          </svg>
        );
      case "Gemini":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 2C12 7.5 7.5 12 2 12C7.5 12 12 16.5 12 22C12 16.5 16.5 12 22 12C16.5 12 12 7.5 12 2Z" fill="url(#geminiGrad)" />
            <path d="M18 4C18 6 16 7.5 14 7.5C16 7.5 18 9 18 11C18 9 20 7.5 22 7.5C20 7.5 18 6 18 4Z" fill="#00f2ff" />
            <defs>
              <linearGradient id="geminiGrad" x1="2" y1="2" x2="22" y2="22" gradientUnits="userSpaceOnUse">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#0052ff" />
              </linearGradient>
            </defs>
          </svg>
        );
      case "OpenAI":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="24" height="24" rx="5" fill="#10A37F" />
            <path d="M16.5 11.2C16.8 11.4 17 11.8 17 12.2C17 12.6 16.8 13 16.5 13.2L13.8 14.8C13.5 15 13.1 15 12.8 14.8L10.1 13.2C9.8 13 9.6 12.6 9.6 12.2C9.6 11.8 9.8 11.4 10.1 11.2L12.8 9.6C13.1 9.4 13.5 9.4 13.8 9.6L16.5 11.2Z" fill="white" />
          </svg>
        );
      case "Anthropic":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="24" height="24" rx="5" fill="#E0B8A5" />
            <path d="M12 5L7 17H9.5L10.5 14.5H13.5L14.5 17H17L12 5ZM11.1 12L12 9.5L12.9 12H11.1Z" fill="#1E1E1C" />
          </svg>
        );
      case "DeepSeek":
        return (
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="24" height="24" rx="5" fill="#3D5afe" />
            <path d="M12 4C7.58 4 4 7.58 4 12C4 16.42 7.58 20 12 20C16.42 20 20 16.42 20 12C20 7.58 16.42 4 12 4ZM10 15V9L15 12L10 15Z" fill="white" />
          </svg>
        );
      default:
        return <Shield className="w-4 h-4 text-[#FA1F4E] shrink-0" />;
    }
  };

  return (
    <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-3 font-mono text-xs">
      <div className="flex justify-between items-center border-b border-[#11131c] pb-2">
        <div className="flex items-center gap-2">
          {renderServiceLogo()}
          <span className="text-white font-bold uppercase tracking-wide">
            {service.label} API Panel {isExchange && `(Slot #${activeSlot})`}
          </span>
        </div>
        <span className={`px-2 py-0.5 rounded text-[9px] font-bold border ${
          isConfigured
            ? "bg-[rgba(0,230,118,0.1)] text-[#00e676] border-[#00e676]"
            : "bg-[rgba(245,158,11,0.1)] text-[#f59e0b] border-[#f59e0b]"
        }`}>
          {isConfigured ? "SECURED" : "PENDING SETUP"}
        </span>
      </div>

      <p className="text-[10px] text-[#8a8d9a] leading-normal">{service.help}</p>

      {/* Slots Selection Bar for Exchanges */}
      {isExchange && onSelectSlot && onAddSlot && (
        <div className="flex items-center gap-1.5 bg-[#06070a] border border-[#1a1d26] p-2 rounded flex-wrap">
          <span className="text-[9px] font-black text-[#8a8d9a] uppercase tracking-wider">Configure Slots (Up to 4):</span>
          <div className="flex items-center gap-1.5 flex-wrap">
            {unlockedSlots.map((slotNum) => {
              const isSlotConfigured = slotConfiguredStates[slotNum];
              return (
                <button
                  key={slotNum}
                  onClick={() => onSelectSlot(slotNum)}
                  className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all border ${
                    activeSlot === slotNum
                      ? "border-[#00f2ff] bg-[#00f2ff]/10 text-white"
                      : isSlotConfigured
                      ? "border-[#00e676]/30 bg-[#00e676]/5 text-[#00e676]"
                      : "border-[#1a1d26] bg-black/40 text-[#8a8d9a] hover:border-[#3b82f6]/50"
                  }`}
                >
                  Slot #{slotNum} {isSlotConfigured && "✓"}
                </button>
              );
            })}
            {unlockedSlots.length < 4 && (
              <button
                onClick={onAddSlot}
                className="px-2 py-1 rounded text-[9px] font-black border border-dashed border-[#FA1F4E]/40 hover:border-[#FA1F4E] bg-transparent text-[#FA1F4E] hover:bg-[#FA1F4E]/5 transition-all uppercase flex items-center gap-0.5"
              >
                + Add Key
              </button>
            )}
          </div>
        </div>
      )}

      <div className={`grid grid-cols-1 ${service.fields.length === 3 ? "md:grid-cols-3" : service.fields.length === 2 ? "md:grid-cols-2" : "md:grid-cols-1"} gap-3 pt-1`}>
        <div>
          <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">{service.fields[0]}</label>
          <input
            type="password"
            placeholder={isConfigured ? "••••••••••••••••••••••••" : "Enter API key / token"}
            value={formValues.api_key}
            onChange={(e) => onInputChange("api_key", e.target.value)}
            className="w-full bg-[#06070a] border border-[#1a1d26] hover:border-[#00e5ff] focus:border-[#00e5ff] text-white p-2 rounded outline-none font-mono"
          />
        </div>
        {service.fields[1] && (
          <div>
            <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">{service.fields[1]}</label>
            <input
              type="password"
              placeholder={isConfigured ? "••••••••••••••••••••••••" : "Enter API secret / Chat ID"}
              value={formValues.api_secret}
              onChange={(e) => onInputChange("api_secret", e.target.value)}
              className="w-full bg-[#06070a] border border-[#1a1d26] hover:border-[#3b82f6] focus:border-[#3b82f6] text-white p-2 rounded outline-none font-mono"
            />
          </div>
        )}
        {service.fields[2] && (
          <div>
            <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">{service.fields[2]}</label>
            <input
              type="password"
              placeholder={isConfigured ? "••••••••••••••••••••••••" : "Enter Passphrase"}
              value={formValues.api_passphrase || ""}
              onChange={(e) => onInputChange("api_passphrase", e.target.value)}
              className="w-full bg-[#06070a] border border-[#1a1d26] hover:border-[#a855f7] focus:border-[#a855f7] text-white p-2 rounded outline-none font-mono"
            />
          </div>
        )}
      </div>

      {/* Inline Diagnostic Result Banner */}
      {testResult && testResult.status !== "idle" && (
        <div className={`p-2.5 rounded border text-[10px] flex items-center justify-between gap-2 ${
          testResult.status === "testing"
            ? "bg-[#3b82f6]/5 border-[#3b82f6]/30 text-[#3b82f6]"
            : testResult.status === "success"
            ? "bg-[#00e676]/10 border-[#00e676]/40 text-[#00e676]"
            : "bg-[#ef4444]/10 border-[#ef4444]/40 text-[#ef4444]"
        }`}>
          <div className="flex items-center gap-2">
            {testResult.status === "testing" ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin shrink-0" />
            ) : testResult.status === "success" ? (
              <CheckCircle className="w-3.5 h-3.5 shrink-0" />
            ) : (
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
            )}
            <span className="font-bold">{testResult.message}</span>
          </div>

          {testResult.latency_ms !== undefined && (
            <span className="font-mono text-[9px] px-1.5 py-0.5 bg-black/40 rounded border border-current shrink-0">
              {testResult.latency_ms}ms | {testResult.timestamp}
            </span>
          )}
        </div>
      )}

      {/* Inline Save Feedback Message */}
      {saveMessage && (
        <div className={`p-2 rounded border text-[10px] font-bold flex items-center gap-2 ${
          saveMessage.type === "success"
            ? "bg-[#00e676]/10 border-[#00e676]/40 text-[#00e676]"
            : "bg-[#ef4444]/10 border-[#ef4444]/40 text-[#ef4444]"
        }`}>
          {saveMessage.type === "success" ? (
            <CheckCircle className="w-3.5 h-3.5 shrink-0" />
          ) : (
            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          )}
          <span>{saveMessage.text}</span>
        </div>
      )}

      {/* Card Action Controls */}
      <div className="flex justify-end items-center gap-2 pt-2 border-t border-[#1a1d26]">
        <button
          onClick={onTest}
          disabled={isTesting || isSaving}
          className="px-3.5 py-1.5 border border-[#3b82f6] bg-transparent text-[#3b82f6] hover:bg-[#3b82f6] hover:text-white rounded text-[10px] font-extrabold uppercase transition-all flex items-center gap-1.5 disabled:opacity-50"
        >
          {isTesting ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Activity className="w-3 h-3" />}
          {isTesting ? "TESTING..." : "TEST API ENTRY"}
        </button>

        <button
          onClick={onSave}
          disabled={isSaving}
          className="px-4 py-1.5 bg-[#3b82f6] hover:bg-[#2563eb] text-white rounded text-[10px] font-extrabold uppercase transition-all flex items-center gap-1.5 disabled:opacity-50"
        >
          {isSaving && <RefreshCw className="w-3 h-3 animate-spin" />}
          {isSaving ? "SAVING..." : "SAVE CREDENTIALS"}
        </button>
      </div>
    </div>
  );
};
