import React, { useState } from "react";
import { VaultSecurityManager, VaultSecurityConfig, DecoyTheme } from "../../services/vaultSecurity";
import { Shield, Lock, Unlock, Key, Settings, Trash2, CheckCircle2, Eye, EyeOff, Zap } from "lucide-react";

interface VaultSecurityBarProps {
  isLocked: boolean;
  onLock: () => void;
  onConfigChange: () => void;
}

export const VaultSecurityBar: React.FC<VaultSecurityBarProps> = ({
  isLocked,
  onLock,
  onConfigChange,
}) => {
  const [showModal, setShowModal] = useState(false);
  const config = VaultSecurityManager.getConfig();

  // Modal Form State
  const [newPasscode, setNewPasscode] = useState("");
  const [confirmPasscode, setConfirmPasscode] = useState("");
  const [decoyTheme, setDecoyTheme] = useState<DecoyTheme>(config.decoyTheme || "matrix");
  const [autoLockOnLeave, setAutoLockOnLeave] = useState(config.autoLockOnLeave);
  const [modalMsg, setModalMsg] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [showPass, setShowPass] = useState(false);

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    setModalMsg(null);

    if (newPasscode) {
      if (newPasscode !== confirmPasscode) {
        setModalMsg({ type: "error", text: "Passcodes do not match." });
        return;
      }
      VaultSecurityManager.setPasscode(newPasscode, decoyTheme);
      setModalMsg({ type: "success", text: "Passcode and Stealth Cover saved & locked!" });
    } else {
      // Just update theme and autolock
      const updatedConfig: VaultSecurityConfig = {
        ...config,
        decoyTheme,
        autoLockOnLeave,
      };
      VaultSecurityManager.saveConfig(updatedConfig);
      setModalMsg({ type: "success", text: "Vault stealth options updated successfully!" });
    }

    setNewPasscode("");
    setConfirmPasscode("");
    onConfigChange();
    setTimeout(() => {
      setShowModal(false);
      setModalMsg(null);
    }, 1200);
  };

  const handleRemovePasscode = () => {
    if (window.confirm("Are you sure you want to remove passcode protection? The vault will remain freely accessible without a lock.")) {
      VaultSecurityManager.removePasscode();
      setNewPasscode("");
      setConfirmPasscode("");
      setModalMsg({ type: "success", text: "Passcode protection completely removed." });
      onConfigChange();
      setTimeout(() => {
        setShowModal(false);
        setModalMsg(null);
      }, 1000);
    }
  };

  return (
    <>
      <div className="bg-[#0b0d12] border border-[#1a1d28] p-3 rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-3 font-mono text-xs">
        <div className="flex items-center gap-3">
          <div className={`p-2 rounded border ${
            isLocked
              ? "bg-[#FA1F4E]/10 border-[#FA1F4E]/40 text-[#FA1F4E]"
              : config.hasPasscode
              ? "bg-[#00e676]/10 border-[#00e676]/40 text-[#00e676]"
              : "bg-[#00f2ff]/10 border-[#00f2ff]/40 text-[#00f2ff]"
          }`}>
            {isLocked ? <Lock className="w-4 h-4" /> : config.hasPasscode ? <Unlock className="w-4 h-4" /> : <Shield className="w-4 h-4" />}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-white font-extrabold uppercase tracking-wider text-[11px]">
                VAULT STEALTH & FREEDOM MATRIX
              </span>
              <span className={`px-2 py-0.5 rounded text-[8.5px] font-bold border ${
                isLocked
                  ? "bg-[#FA1F4E]/20 text-[#FA1F4E] border-[#FA1F4E]/50"
                  : config.hasPasscode
                  ? "bg-[#00e676]/20 text-[#00e676] border-[#00e676]/50"
                  : "bg-[#00f2ff]/20 text-[#00f2ff] border-[#00f2ff]/50"
              }`}>
                {isLocked ? "LOCKED (MASKED)" : config.hasPasscode ? "PASSCODE ACTIVE" : "FREEDOM MODE (NO LOCK)"}
              </span>
            </div>
            <p className="text-[10px] text-[#8a8d9a] mt-0.5">
              {config.hasPasscode
                ? `Protected with custom passcode. Stealth theme: ${config.decoyTheme.toUpperCase()}`
                : "No passcode set. You have full freedom to add or remove access locks anytime."}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {config.hasPasscode && !isLocked && (
            <button
              onClick={onLock}
              className="px-3 py-1.5 bg-[#FA1F4E]/15 hover:bg-[#FA1F4E] text-[#FA1F4E] hover:text-white border border-[#FA1F4E]/50 rounded text-[10px] font-extrabold uppercase transition-all flex items-center gap-1.5"
            >
              <Lock className="w-3.5 h-3.5" />
              LOCK VAULT NOW
            </button>
          )}

          <button
            onClick={() => setShowModal(true)}
            className="px-3 py-1.5 bg-[#141824] hover:bg-[#1a2030] text-white border border-[#242a3e] rounded text-[10px] font-bold uppercase transition-all flex items-center gap-1.5"
          >
            <Settings className="w-3.5 h-3.5 text-[#00f2ff]" />
            {config.hasPasscode ? "CONFIGURE PASSCODE & DECOY" : "ADD PASSCODE & STEALTH COVER"}
          </button>
        </div>
      </div>

      {/* Settings Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 font-mono text-xs">
          <div className="bg-[#0b0d12] border border-[#FA1F4E]/40 rounded-lg max-w-lg w-full p-6 space-y-5 shadow-2xl relative">
            <div className="flex justify-between items-center border-b border-[#181c2b] pb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-[#FA1F4E]" />
                <h3 className="text-sm font-extrabold text-white uppercase tracking-wider">
                  MEMOBOT VAULT™ SECURITY MATRIX
                </h3>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-[#8a8d9a] hover:text-white text-base font-bold"
              >
                ✕
              </button>
            </div>

            {modalMsg && (
              <div className={`p-2.5 rounded border text-[10px] font-bold flex items-center gap-2 ${
                modalMsg.type === "success"
                  ? "bg-[#00e676]/10 border-[#00e676]/40 text-[#00e676]"
                  : "bg-[#ef4444]/10 border-[#ef4444]/40 text-[#ef4444]"
              }`}>
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{modalMsg.text}</span>
              </div>
            )}

            <form onSubmit={handleSaveSecurity} className="space-y-4">
              {/* Passcode Fields */}
              <div className="space-y-3 bg-[#06070a] p-3.5 rounded border border-[#161a28]">
                <div className="flex justify-between items-center">
                  <label className="text-[10px] text-white font-bold uppercase flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-[#00f2ff]" />
                    {config.hasPasscode ? "CHANGE PASSCODE OR PIN" : "SET NEW VAULT PASSCODE / COMBINATION"}
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="text-[9px] text-[#8a8d9a] hover:text-white flex items-center gap-1"
                  >
                    {showPass ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    {showPass ? "HIDE" : "SHOW"}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-[9px] text-[#8a8d9a] block mb-1">Passcode / Combination:</span>
                    <input
                      type={showPass ? "text" : "password"}
                      value={newPasscode}
                      onChange={(e) => setNewPasscode(e.target.value)}
                      placeholder={config.hasPasscode ? "Enter new passcode..." : "Enter numbers/letters..."}
                      className="w-full bg-[#0a0c10] border border-[#1a1d28] hover:border-[#00f2ff] focus:border-[#00f2ff] text-white p-2 rounded text-xs outline-none"
                    />
                  </div>
                  <div>
                    <span className="text-[9px] text-[#8a8d9a] block mb-1">Confirm Passcode:</span>
                    <input
                      type={showPass ? "text" : "password"}
                      value={confirmPasscode}
                      onChange={(e) => setConfirmPasscode(e.target.value)}
                      placeholder="Re-enter passcode..."
                      className="w-full bg-[#0a0c10] border border-[#1a1d28] hover:border-[#00f2ff] focus:border-[#00f2ff] text-white p-2 rounded text-xs outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Decoy Theme Selection */}
              <div className="space-y-2">
                <label className="text-[10px] text-white font-bold uppercase block">
                  SELECT STEALTH DECOY MASK THEME
                </label>
                <div className="grid grid-cols-2 gap-2 text-[10px]">
                  {[
                    { id: "matrix", label: "Quantum Matrix Stream", desc: "Live green code stream" },
                    { id: "maintenance", label: "System Maintenance", desc: "Channel offline banner" },
                    { id: "ticker", label: "Ticker Price Shield", desc: "Encrypted market feed" },
                    { id: "stealth_black", label: "Stealth Dark Shield", desc: "Minimalist black mask" },
                  ].map((theme) => (
                    <button
                      key={theme.id}
                      type="button"
                      onClick={() => setDecoyTheme(theme.id as DecoyTheme)}
                      className={`p-2.5 rounded text-left border transition-all ${
                        decoyTheme === theme.id
                          ? "bg-[#00f2ff]/10 border-[#00f2ff] text-white"
                          : "bg-[#06070a] border-[#181c28] text-[#8a8d9a] hover:border-[#333]"
                      }`}
                    >
                      <div className="font-bold text-[10px] text-white">{theme.label}</div>
                      <div className="text-[9px] opacity-70">{theme.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex justify-between items-center pt-3 border-t border-[#181c2b]">
                {config.hasPasscode ? (
                  <button
                    type="button"
                    onClick={handleRemovePasscode}
                    className="px-3 py-2 bg-[#ef4444]/10 hover:bg-[#ef4444] text-[#ef4444] hover:text-white border border-[#ef4444]/40 rounded text-[10px] font-extrabold uppercase transition-all flex items-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    REMOVE PASSCODE
                  </button>
                ) : (
                  <span className="text-[9px] text-[#8a8d9a]">Freedom Mode: Passcode optional.</span>
                )}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="px-3 py-2 bg-[#141824] hover:bg-[#1a2030] text-[#8a8d9a] hover:text-white rounded text-[10px] font-bold uppercase"
                  >
                    CANCEL
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#00f2ff] hover:bg-[#00cce6] text-black rounded text-[10px] font-extrabold uppercase transition-all flex items-center gap-1.5"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    SAVE SECURITY SETTINGS
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
