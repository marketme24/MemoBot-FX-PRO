import React from "react";
import { motion } from "motion/react";
import { ShieldCheck, XCircle, RefreshCw } from "lucide-react";

interface MemocoreHubProps {
  globalMode: "Paper" | "Live";
  complianceMode: "Islamic" | "Commercial";
  onToggleGlobalMode: () => void;
  onToggleComplianceMode: () => void;
  onKillSwitch: () => void;
  equity: number;
  lockedMargin: number;
  connectionStatus: boolean;
}

export const MemocoreHub: React.FC<MemocoreHubProps> = ({
  globalMode,
  complianceMode,
  onToggleGlobalMode,
  onToggleComplianceMode,
  onKillSwitch,
  equity,
  lockedMargin,
  connectionStatus,
}) => {
  const isIslamic = complianceMode === "Islamic";
  const accentColor = isIslamic ? "#10b981" : "#FA1F4E"; // Emerald vs Laser Red

  return (
    <div id="memocore-hub" className="flex flex-col items-center justify-center p-6 bg-[#030406]/90 border border-[#161822] rounded-xl relative overflow-hidden backdrop-blur-md">
      {/* Decorative cyber backdrop grid line */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(22,24,34,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(22,24,34,0.1)_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />

      {/* Orbit Rings and Glowing Logo */}
      <div className="relative w-48 h-48 flex items-center justify-center select-none mb-4">
        {/* Animated Outer Ring */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute inset-0 rounded-full border border-dashed opacity-30"
          style={{ borderColor: accentColor }}
        />

        {/* Animated Middle Ring */}
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="absolute inset-2 rounded-full border border-double opacity-50"
          style={{ borderColor: accentColor }}
        />

        {/* Animated Pulsing Inner Ring */}
        <motion.div
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
          className="absolute inset-6 rounded-full border border-opacity-70 flex items-center justify-center bg-black/60 shadow-[inset_0_0_20px_rgba(0,0,0,0.8)]"
          style={{ borderColor: accentColor }}
        >
          {/* Neon Logo Shield */}
          <div className="flex flex-col items-center justify-center text-center">
            <motion.div
              animate={connectionStatus ? { filter: ["drop-shadow(0 0 4px var(--glow))", "drop-shadow(0 0 12px var(--glow))", "drop-shadow(0 0 4px var(--glow))"] } : {}}
              transition={{ duration: 2, repeat: Infinity }}
              style={{ "--glow": accentColor } as React.CSSProperties}
              className="text-2xl font-black tracking-widest font-mono select-none"
            >
              <span style={{ color: accentColor }}>M</span>
              <span className="text-white">E</span>
              <span style={{ color: accentColor }}>M</span>
              <span className="text-white">O</span>
            </motion.div>
            <span className="text-[7px] text-[#8a8d9a] font-mono tracking-widest uppercase mt-1">CORE SHIELD</span>
            <span className={`text-[8px] font-mono font-bold mt-0.5 uppercase ${isIslamic ? "text-emerald-400" : "text-rose-400"}`}>
              {complianceMode}
            </span>
          </div>
        </motion.div>
      </div>

      {/* Quick Stats Panel */}
      <div className="w-full grid grid-cols-2 gap-3 text-center border-t border-[#1a1d26] pt-4 mb-4">
        <div>
          <span className="text-[8px] text-[#6b6f77] block font-bold uppercase tracking-wider">NET WORTH</span>
          <span className="text-sm font-black font-mono text-white">${equity.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
        </div>
        <div>
          <span className="text-[8px] text-[#6b6f77] block font-bold uppercase tracking-wider">LOCKED MARGIN</span>
          <span className={`text-sm font-black font-mono ${isIslamic ? "text-emerald-400" : "text-white"}`}>
            ${lockedMargin.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </span>
        </div>
      </div>

      {/* Core Settings and Toggles */}
      <div className="w-full space-y-3">
        {/* Sandbox vs Live */}
        <div className="flex items-center justify-between bg-black/40 border border-[#1a1d26] p-2 rounded">
          <span className="text-[9px] text-[#8a8d9a] font-bold uppercase">EXECUTION LAYER</span>
          <button
            onClick={onToggleGlobalMode}
            className={`px-3 py-1 text-[9px] font-mono font-bold rounded transition-all uppercase ${
              globalMode === "Live"
                ? "bg-rose-500/10 text-rose-500 border border-rose-500/30"
                : "bg-cyan-500/10 text-cyan-400 border border-cyan-500/30"
            }`}
          >
            {globalMode} Mode
          </button>
        </div>

        {/* Shariah Switch */}
        <div className="flex items-center justify-between bg-black/40 border border-[#1a1d26] p-2 rounded">
          <span className="text-[9px] text-[#8a8d9a] font-bold uppercase">POLICY GUIDELINE</span>
          <button
            onClick={onToggleComplianceMode}
            className={`px-3 py-1 text-[9px] font-mono font-bold rounded transition-all uppercase ${
              isIslamic
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/30"
                : "bg-amber-500/10 text-amber-500 border border-amber-500/30"
            }`}
          >
            {complianceMode} Mode
          </button>
        </div>

        {/* Kill Switch */}
        <button
          onClick={onKillSwitch}
          className="w-full flex items-center justify-center gap-1.5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-mono font-bold uppercase rounded transition-all tracking-wider"
        >
          <XCircle className="w-3.5 h-3.5" />
          SYSTEM KILL SWITCH
        </button>
      </div>
    </div>
  );
};
