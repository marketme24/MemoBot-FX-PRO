import React, { useState } from "react";
import { Play, Square, RefreshCw, Send, ShieldAlert, Cpu } from "lucide-react";
import { Engine } from "../../services/engineStore";

interface EngineCommandDeskProps {
  engineId: string;
  engine: Engine;
  localConfig: { strategy: string; asset: string; amount: number; leverage: number };
  onUpdateConfig: (field: string, value: any) => void;
  onApplyConfig: () => void;
  onStartStop: () => void;
  onTriggerManualOrder: (side: "BUY" | "SELL") => void;
  savingState: boolean;
  saveMessage: string | null;
  complianceMode: "Islamic" | "Commercial";
  vaultStatus: { Binance: boolean; KuCoin: boolean; OKX: boolean; Bybit: boolean };
}

export const EngineCommandDesk: React.FC<EngineCommandDeskProps> = ({
  engineId,
  engine,
  localConfig,
  onUpdateConfig,
  onApplyConfig,
  onStartStop,
  onTriggerManualOrder,
  savingState,
  saveMessage,
  complianceMode,
  vaultStatus,
}) => {
  const isRunning = engine.status === "Running";
  const isIslamic = complianceMode === "Islamic";
  const [activeExchange, setActiveExchange] = useState<"Binance" | "KuCoin" | "OKX" | "Bybit">("Binance");

  const pipelineStages = [
    { code: "1.SG", label: "Signal Generation" },
    { code: "2.FI", label: "Pre-Trade Filters" },
    { code: "3.SHA", label: "Shariah Audit" },
    { code: "4.RSK", label: "Risk Management" },
    { code: "5.SIZE", label: "Position Sizing" },
    { code: "6.PLC", label: "Placement/Route" },
    { code: "7.CNF", label: "Order Confirmation" },
    { code: "8.REC", label: "Ledger Recording" },
    { code: "9.MON", label: "Post-Trade Monitoring" }
  ];

  const exchangesList: ("Binance" | "KuCoin" | "OKX" | "Bybit")[] = ["Binance", "KuCoin", "OKX", "Bybit"];

  return (
    <div id={`command-desk-${engineId}`} className="p-6 bg-[#030406]/95 border border-[#161822] rounded-2xl relative overflow-hidden shadow-2xl">
      {/* Visual cyber highlights */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#a855f7] to-transparent opacity-50" />

      {/* Header and Start/Stop toggle */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-[#1a1d26] pb-4 mb-4">
        <div>
          <h3 className="text-sm font-black text-white tracking-widest uppercase flex items-center gap-2">
            <Cpu className="w-4 h-4 text-[#a855f7]" />
            {engine.nickname || engine.display_name} COMMAND BOARD
          </h3>
          <span className="text-[9px] text-[#6b6f77] font-bold block uppercase mt-0.5">
            Operational Desk • Code: {engineId}
          </span>
        </div>

        <button
          onClick={onStartStop}
          className={`px-4 py-2 text-[10px] font-mono font-black uppercase rounded transition-all flex items-center gap-1.5 border ${
            isRunning
              ? "border-rose-500 text-rose-500 bg-rose-500/10 hover:bg-rose-500 hover:text-white"
              : "border-[#a855f7] text-[#a855f7] bg-[#a855f7]/5 hover:bg-[#a855f7] hover:text-white"
          }`}
        >
          {isRunning ? (
            <>
              <Square className="w-3.5 h-3.5 fill-current" />
              HALT CORE
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5 fill-current" />
              DEPLOY CORE
            </>
          )}
        </button>
      </div>

      {/* Exchange Selection */}
      <div className="mb-4">
        <label className="text-[8px] text-[#6b6f77] font-black uppercase block mb-1.5 tracking-wider">BIND TO ROUTING EXCHANGE</label>
        <div className="grid grid-cols-4 gap-2">
          {exchangesList.map((ex) => {
            const isConfigured = vaultStatus[ex];
            const isActive = activeExchange === ex;
            return (
              <button
                key={ex}
                disabled={isRunning}
                onClick={() => setActiveExchange(ex)}
                className={`p-2 rounded border font-mono text-[9px] font-bold transition-all relative ${
                  isActive
                    ? "bg-[#a855f7]/10 border-[#a855f7] text-[#a855f7]"
                    : "bg-black/40 border-[#1a1d26] text-[#8a8d9a] hover:border-[#2f354a]"
                } ${!isConfigured ? "opacity-60" : ""}`}
              >
                <span>{ex}</span>
                {/* Visual LED status */}
                <span className={`absolute top-1 right-1 w-1.5 h-1.5 rounded-full ${isConfigured ? "bg-emerald-500" : "bg-zinc-700"}`} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Pipeline Indicators */}
      <div className="mb-4 bg-black/40 p-3 rounded-lg border border-[#161822]">
        <span className="text-[8px] text-[#6b6f77] font-black uppercase block mb-2 tracking-wider">LIVE DATA PIPELINE FLOW</span>
        <div className="flex gap-1 w-full overflow-x-auto pb-1">
          {pipelineStages.map((stage, idx) => {
            const isActive = isRunning && engine.current_stage_idx === idx;
            const isDone = isRunning && idx < engine.current_stage_idx;
            return (
              <div
                key={stage.code}
                className={`text-[8px] font-bold p-1 rounded border text-center flex-1 min-w-[50px] truncate transition-all ${
                  isActive
                    ? "bg-[#a855f7]/20 border-[#a855f7] text-white"
                    : isDone
                    ? "bg-[#a855f7]/5 border-[#a855f7]/20 text-[#a855f7]"
                    : "bg-zinc-900/20 border-[#1a1d26] text-[#6b6f77]"
                }`}
                title={stage.label}
              >
                {stage.code.split(".")[1]}
              </div>
            );
          })}
        </div>
      </div>

      {/* Main Configurations Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        {/* Left configurations fields */}
        <div className="space-y-3">
          <div className="space-y-1">
            <label className="text-[8px] text-[#6b6f77] font-black uppercase block tracking-wider">POSITION SIZING (USDT)</label>
            <input
              type="number"
              disabled={isRunning}
              value={localConfig.amount ?? 100}
              onChange={(e) => onUpdateConfig("amount", Number(e.target.value))}
              className="w-full bg-[#06070a] border border-[#161822] focus:border-[#a855f7] text-white p-2.5 rounded outline-none font-mono text-xs disabled:opacity-50"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[8px] text-[#6b6f77] font-black uppercase block tracking-wider">LEVERAGE MULTIPLIER</label>
            {isIslamic ? (
              <div className="flex items-center gap-2 p-2 bg-emerald-500/5 border border-emerald-500/20 rounded text-emerald-400 text-[9px] font-bold">
                <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                SHARIAH SYSTEM LOCK: SPOT-BACKED ASSET (1x DIRECT EXPOSURE)
              </div>
            ) : (
              <select
                disabled={isRunning}
                value={localConfig.leverage ?? 1}
                onChange={(e) => onUpdateConfig("leverage", Number(e.target.value))}
                className="w-full bg-[#06070a] border border-[#161822] focus:border-[#a855f7] text-white p-2.5 rounded outline-none font-mono text-xs disabled:opacity-50"
              >
                <option value={1}>1x Spot Exposure</option>
                <option value={3}>3x Leveraged Spot</option>
                <option value={5}>5x Perpetual Grid</option>
                <option value={10}>10x High Exposure</option>
              </select>
            )}
          </div>
        </div>

        {/* Right configurations fields */}
        <div className="space-y-3">
          <div className="space-y-1">
            <label className="text-[8px] text-[#6b6f77] font-black uppercase block tracking-wider">TARGET TRADING PAIR</label>
            <select
              disabled={isRunning}
              value={localConfig.asset ?? "BTCUSDT"}
              onChange={(e) => onUpdateConfig("asset", e.target.value)}
              className="w-full bg-[#06070a] border border-[#161822] focus:border-[#a855f7] text-white p-2.5 rounded outline-none font-mono text-xs disabled:opacity-50"
            >
              <option value="BTCUSDT">BTC (Bitcoin / Tether)</option>
              <option value="ETHUSDT">ETH (Ethereum / Tether)</option>
              <option value="SOLUSDT">SOL (Solana / Tether)</option>
              <option value="BNBUSDT">BNB (Binance Coin / Tether)</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="text-[8px] text-[#6b6f77] font-black uppercase block tracking-wider">EXECUTION STRATEGY</label>
            <select
              disabled={isRunning}
              value={localConfig.strategy ?? "FAST SCALPER"}
              onChange={(e) => onUpdateConfig("strategy", e.target.value)}
              className="w-full bg-[#06070a] border border-[#161822] focus:border-[#a855f7] text-white p-2.5 rounded outline-none font-mono text-xs disabled:opacity-50"
            >
              <option value="FAST SCALPER">FAST SCALPER (Micro Orderbooks)</option>
              <option value="TREND BALANCER">TREND BALANCER (EMA Crosses)</option>
              <option value="AI SWARMconsensus">AI SWARM CONSENSUS (Gemini Core)</option>
              <option value="STAT ARBITRAGE">STAT ARBITRAGE (Multi-Asset)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Sync and Action triggers */}
      <div className="flex flex-col sm:flex-row gap-3 pt-2">
        <button
          onClick={onApplyConfig}
          disabled={savingState || isRunning}
          className="flex-1 py-3 text-[10px] font-mono font-black rounded border border-[#a855f7]/30 bg-[#a855f7]/5 hover:bg-[#a855f7]/10 text-white transition-all uppercase flex items-center justify-center gap-1.5 disabled:opacity-50"
        >
          {savingState ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <span>APPLY ENGINE CONFIGURATION</span>
          )}
          {saveMessage === "SUCCESS" && <span className="text-emerald-400 font-bold ml-1">SYNCED</span>}
        </button>

        <div className="flex gap-2">
          <button
            onClick={() => onTriggerManualOrder("BUY")}
            disabled={!isRunning}
            className="px-6 py-3 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-40 text-black text-[10px] font-mono font-black uppercase rounded transition-all flex items-center gap-1"
          >
            <Send className="w-3 h-3" />
            BUY
          </button>
          <button
            onClick={() => onTriggerManualOrder("SELL")}
            disabled={!isRunning}
            className="px-6 py-3 bg-rose-500 hover:bg-rose-600 disabled:opacity-40 text-white text-[10px] font-mono font-black uppercase rounded transition-all flex items-center gap-1"
          >
            <Send className="w-3 h-3" />
            SELL
          </button>
        </div>
      </div>
    </div>
  );
};
