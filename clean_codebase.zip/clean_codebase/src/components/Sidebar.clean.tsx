import React from "react";
import { OrbitLogo } from "./OrbitLogo";
import { Eye, ShieldCheck, Lock, Sparkles, X } from "lucide-react";
import { MemoBotIcon } from "./MemoBotIcon";
import { useTheme } from "./ThemeProvider";
import { useLanguage } from "./LanguageProvider";

interface SidebarProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
  engineStatus: string;
  equity: number;
  unrealizedPnl: number;
  usdtAvailable: number;
  lockedMargin: number;
  paperBalance: number;
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onNavigate,
  engineStatus,
  equity,
  unrealizedPnl,
  usdtAvailable,
  lockedMargin,
  paperBalance,
  isOpen = false,
  onClose
}) => {
  const [time, setTime] = React.useState(new Date());
  const { t } = useLanguage();
  let accentColor = "#FA1F4E";
  let sidebarSections = [
    {
      id: "sec-core",
      title: t("CORE WORKSPACE"),
      items: [
        { id: "dashboard", label: t("DASHBOARD") },
        { id: "engines", label: t("CENTRAL ENGINE STATION") },
        { id: "strategies", label: t("STRATEGIES") },
        { id: "live-positions", label: t("RISK MANAGER") },
        { id: "shariyah-bureau", label: t("SHARIYAH BUREAU") },
        { id: "market-intel", label: t("MARKET OVERVIEW") },
      ]
    },
    {
      id: "sec-gateway",
      title: t("TRADING GATEWAY"),
      items: [
        { id: "portfolio", label: t("ASSET PORTFOLIO") },
        { id: "orders", label: t("SECURE ORDER HUB") },
      ]
    },
    {
      id: "sec-memotech",
      title: t("MEMO-TECH"),
      items: [
        { id: "ai-chat", label: t("MEMOBOT AI") },
        { id: "analytics", label: t("HIGHTECHEYE") },
        { id: "secure-vault", label: t("MEMOBOT VAULT") },
        { id: "business-club", label: t("MEMO BUSINESS CLUB") },
      ]
    },
    {
      id: "sec-system",
      title: t("SYSTEM CONTROLS"),
      items: [
        { id: "audit", label: t("AUDITING HUB") },
        { id: "settings", label: t("SETTINGS") },
      ]
    }
  ];

  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
    if (theme?.sidebarSections && theme.sidebarSections.length > 0) {
      sidebarSections = theme.sidebarSections;
    }
  } catch (e) {}

  React.useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleItemClick = (id: string) => {
    onNavigate(id);
    if (onClose) onClose();
  };

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-40 lg:hidden transition-opacity duration-300"
          aria-hidden="true"
        />
      )}

      {/* Main Sidebar (Fixed on Desktop, Slide-over Drawer on Mobile/Tablet) */}
      <aside
        id="sidebar-panel"
        className={`fixed lg:static top-0 bottom-0 left-0 rtl:left-auto rtl:right-0 z-50 w-[270px] max-w-[85vw] bg-[#06070a] flex flex-col shrink-0 h-full select-none border-r rtl:border-r-0 rtl:border-l border-[rgba(var(--color-primary-rgb),0.2)] shadow-2xl lg:shadow-none transform transition-transform duration-300 ease-in-out ${
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0 rtl:translate-x-full rtl:lg:translate-x-0"
        }`}
      >
        {/* Mobile Close Button */}
        <div className="lg:hidden flex items-center justify-between p-3 border-b border-[#151922] bg-[#090b10]">
          <span className="text-[10px] font-mono text-[#8a8d9a] uppercase font-bold tracking-wider">
            NAVIGATION MATRIX
          </span>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-[#141722] text-[#8a8d9a] hover:text-white border border-[#22273a] transition-all cursor-pointer"
            aria-label="Close navigation"
          >
            <X className="w-4 h-4 text-[#FA1F4E]" />
          </button>
        </div>
        
        {/* Brand Header with Orbit Animation */}
        <OrbitLogo />

        {/* Account Overview Widget */}
        <div className="p-3 bg-gradient-to-b from-transparent to-white/[0.02]">
          <div className="flex items-center justify-between mb-2">
            <h3 style={{ color: accentColor }} className="text-[9px] font-aquire tracking-[0.2em] uppercase">
              {t("CORE EQUITY")}
            </h3>
            <div className="flex gap-1">
              <div style={{ backgroundColor: accentColor }} className="w-1.5 h-1.5 rounded-full animate-pulse shadow-[0_0_8px_var(--color-primary)]" />
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between items-end">
              <div className="flex flex-col">
                <span className="text-[7px] text-[#8a8d9a] font-bold tracking-wider uppercase">{t("BALANCE")}</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-xs font-mono font-bold text-white">
                    ${Math.floor(equity ?? 0).toLocaleString()}
                  </span>
                  <span className="text-[8px] font-mono text-white/50">
                    .{((equity ?? 0) % 1).toFixed(2).split('.')[1]}
                  </span>
                </div>
              </div>
              <div className="flex flex-col items-end">
                <span className="text-[7px] text-[#8a8d9a] font-black tracking-widest uppercase">{t("P&L")}</span>
                <span className="text-[10px] font-mono font-bold text-white">
                  {unrealizedPnl >= 0 ? "+" : ""}{(unrealizedPnl ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Groups */}
        <div className="flex-1 py-1 overflow-y-auto space-y-4 px-2 custom-scrollbar">
          {sidebarSections.map((group) => (
            <div key={group.id || group.title} className="space-y-1.5">
              <h3 style={{ color: accentColor }} className="text-[12px] font-aquire tracking-[0.15em] uppercase px-3 mb-2 opacity-90 rtl:text-right">
                {t(group.title)}
              </h3>
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const isActive = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleItemClick(item.id)}
                      style={
                        isActive
                          ? {
                              borderLeftColor: accentColor,
                              borderRightColor: accentColor,
                              backgroundColor: `${accentColor}18`,
                              color: "#ffffff"
                            }
                          : {}
                      }
                      className={`w-full flex items-center justify-between px-3 py-2.5 rounded text-[11px] font-bold font-mono transition-all text-left rtl:text-right group cursor-pointer ${
                        isActive
                          ? "border-l-2 rtl:border-l-0 rtl:border-r-2 text-white shadow-[0_0_12px_rgba(var(--color-primary-rgb),0.15)]"
                          : "border-l-2 rtl:border-l-0 rtl:border-r-2 border-transparent text-[#8a8d9a] hover:bg-[#11131c] hover:text-white"
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        {/* MemoBot Icon for AI Chat */}
                        {item.id === "ai-chat" && (
                          <MemoBotIcon size={14} color={accentColor} glow={true} className="animate-pulse" />
                        )}
                        {/* Eye Icon for HighTechEye */}
                        {item.id === "analytics" && (
                          <Eye className="w-3.5 h-3.5 text-[#FA1F4E] animate-pulse" />
                        )}
                        {/* Vault Icon */}
                        {item.id === "secure-vault" && (
                          <Lock className="w-3.5 h-3.5 text-[#FA1F4E]" />
                        )}
                        {/* Business Club Sparkles Icon */}
                        {item.id === "business-club" && (
                          <Sparkles className="w-3.5 h-3.5 text-[#FA1F4E] animate-pulse" />
                        )}
                        {/* ShieldCheck Icon for Shariyah Bureau */}
                        {item.id === "shariyah-bureau" && (
                          <ShieldCheck className="w-3.5 h-3.5 text-[#FA1F4E]" />
                        )}
                        <span>{t(item.label)}</span>
                      </div>

                      <div className="flex items-center gap-2">
                        {item.id === "business-club" && (
                          <span className="text-[8px] bg-[#FA1F4E]/15 text-[#FA1F4E] border border-[#FA1F4E]/30 px-1 py-0.2 rounded font-black tracking-widest">
                            {t("CLUB")}
                          </span>
                        )}
                        {item.id === "shariyah-bureau" && (
                          <span className="text-[8px] bg-[#FA1F4E]/15 text-[#FA1F4E] border border-[#FA1F4E]/30 px-1 py-0.2 rounded font-black tracking-widest">
                            {t("HALAL")}
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* System Footer Widget */}
        <div className="p-3 border-t border-[#11131c] bg-[#06070a] text-[9px] font-mono text-[#8a8d9a]">
          <div className="flex justify-between items-center">
            <span>{t("UTC TIME:")}</span>
            <span className="text-white font-bold">{time.toISOString().replace('T', ' ').substring(0, 19)}</span>
          </div>
          <div className="flex justify-between items-center mt-1">
            <span>{t("VERSION:")}</span>
            <span style={{ color: accentColor }} className="font-aquire text-[10px] uppercase">MEMOBOT™ FX-PRO v1.1</span>
          </div>
        </div>

      </aside>
    </>
  );
};

export default Sidebar;
