import React, { useState, useEffect } from "react";
import { Layers, ArrowUpRight, ArrowDownRight, Activity } from "lucide-react";

interface OrderBookWidgetProps {
  symbol: string;
  livePrice: number;
}

export const OrderBookWidget: React.FC<OrderBookWidgetProps> = ({ symbol, livePrice }) => {
  const [activeTab, setActiveTab] = useState<"BOOK" | "TRADES">("BOOK");

  // Simulated live bids & asks generated dynamically around live price
  const basePrice = livePrice || (symbol.startsWith("BTC") ? 68450 : symbol.startsWith("ETH") ? 3520 : 185);

  const asks = [
    { price: basePrice + 12.5, amount: 0.8541, total: 58471 },
    { price: basePrice + 9.2, amount: 1.4210, total: 97262 },
    { price: basePrice + 6.0, amount: 0.3120, total: 21356 },
    { price: basePrice + 3.8, amount: 2.1500, total: 147167 },
    { price: basePrice + 1.2, amount: 0.9400, total: 64343 },
  ];

  const bids = [
    { price: basePrice - 1.1, amount: 1.1200, total: 76664 },
    { price: basePrice - 3.5, amount: 0.6500, total: 44492 },
    { price: basePrice - 5.8, amount: 3.4100, total: 233414 },
    { price: basePrice - 8.4, amount: 1.8900, total: 129370 },
    { price: basePrice - 11.0, amount: 0.4200, total: 28749 },
  ];

  const maxTotal = Math.max(...asks.map((a) => a.total), ...bids.map((b) => b.total)) || 1;

  // Recent Trades
  const trades = [
    { price: basePrice + 0.5, amount: 0.24, time: "14:28:42", side: "BUY" },
    { price: basePrice - 0.2, amount: 1.15, time: "14:28:39", side: "SELL" },
    { price: basePrice + 0.1, amount: 0.50, time: "14:28:35", side: "BUY" },
    { price: basePrice - 0.8, amount: 2.80, time: "14:28:28", side: "SELL" },
    { price: basePrice + 0.4, amount: 0.12, time: "14:28:21", side: "BUY" },
  ];

  return (
    <div className="bg-[#0d0e12] border border-[#1a1d26] rounded p-4 panel-glow font-mono text-xs space-y-3">
      
      {/* Header Tabs */}
      <div className="flex items-center justify-between border-b border-[#11131c] pb-2.5">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-[#3b82f6]" />
          <span className="text-[10px] text-white font-bold uppercase tracking-wider">
            {symbol} MARKET DEPTH
          </span>
        </div>

        <div className="flex bg-[#06070a] border border-[#1a1d26] rounded p-0.5 text-[10px]">
          <button
            onClick={() => setActiveTab("BOOK")}
            className={`px-2.5 py-0.5 rounded font-bold uppercase transition-all ${
              activeTab === "BOOK" ? "bg-[#3b82f6] text-white" : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            ORDER BOOK
          </button>
          <button
            onClick={() => setActiveTab("TRADES")}
            className={`px-2.5 py-0.5 rounded font-bold uppercase transition-all ${
              activeTab === "TRADES" ? "bg-[#3b82f6] text-white" : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            LIVE TRADES
          </button>
        </div>
      </div>

      {activeTab === "BOOK" ? (
        <div className="space-y-2">
          {/* Table Header */}
          <div className="grid grid-cols-3 text-[9px] text-[#8a8d9a] font-bold uppercase pb-1 border-b border-[#11131c]">
            <span>PRICE (USDT)</span>
            <span className="text-right">SIZE</span>
            <span className="text-right">TOTAL</span>
          </div>

          {/* Asks (Sell Orders) */}
          <div className="space-y-0.5">
            {asks.slice().reverse().map((ask, idx) => {
              const depthPct = ((ask.total ?? 0) / (maxTotal || 1)) * 100;
              return (
                <div key={idx} className="relative grid grid-cols-3 text-[10px] py-0.5 px-1 rounded hover:bg-[#161923] transition-colors">
                  <div className="absolute right-0 top-0 bottom-0 bg-[#ff1744]/15 rounded-r pointer-events-none" style={{ width: `${depthPct}%` }} />
                  <span className="text-[#ff1744] font-bold z-10">${(ask.price ?? 0).toFixed(2)}</span>
                  <span className="text-right text-white font-mono z-10">{(ask.amount ?? 0).toFixed(4)}</span>
                  <span className="text-right text-[#8a8d9a] z-10">${(ask.total ?? 0).toLocaleString()}</span>
                </div>
              );
            })}
          </div>

          {/* Spread Indicator */}
          <div className="bg-[#06070a] border border-[#1a1d26] py-1.5 px-2 rounded flex justify-between items-center text-[10px]">
            <span className="text-[#3b82f6] font-bold text-xs">
              ${(basePrice ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}
            </span>
            <span className="text-[9px] text-[#8a8d9a]">SPREAD: 0.01 USDT (0.00%)</span>
          </div>

          {/* Bids (Buy Orders) */}
          <div className="space-y-0.5">
            {bids.map((bid, idx) => {
              const depthPct = ((bid.total ?? 0) / (maxTotal || 1)) * 100;
              return (
                <div key={idx} className="relative grid grid-cols-3 text-[10px] py-0.5 px-1 rounded hover:bg-[#161923] transition-colors">
                  <div className="absolute right-0 top-0 bottom-0 bg-[#00e676]/15 rounded-r pointer-events-none" style={{ width: `${depthPct}%` }} />
                  <span className="text-[#00e676] font-bold z-10">${(bid.price ?? 0).toFixed(2)}</span>
                  <span className="text-right text-white font-mono z-10">{(bid.amount ?? 0).toFixed(4)}</span>
                  <span className="text-right text-[#8a8d9a] z-10">${(bid.total ?? 0).toLocaleString()}</span>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* Live Recent Fills Stream */
        <div className="space-y-1.5">
          <div className="grid grid-cols-3 text-[9px] text-[#8a8d9a] font-bold uppercase pb-1 border-b border-[#11131c]">
            <span>PRICE</span>
            <span className="text-right">QTY</span>
            <span className="text-right">TIME</span>
          </div>

          <div className="space-y-1">
            {trades.map((t, idx) => (
              <div key={idx} className="grid grid-cols-3 text-[10px] py-1 px-1 rounded bg-[#06070a] border border-[#11131c] items-center">
                <span className={`font-bold flex items-center gap-1 ${t.side === "BUY" ? "text-[#00e676]" : "text-[#ff1744]"}`}>
                  {t.side === "BUY" ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  ${t.price.toFixed(2)}
                </span>
                <span className="text-right text-white font-mono">{t.amount}</span>
                <span className="text-right text-[#8a8d9a] text-[9px]">{t.time}</span>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
