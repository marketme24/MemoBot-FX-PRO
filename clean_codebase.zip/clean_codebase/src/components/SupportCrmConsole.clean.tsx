import React, { useState, useEffect } from "react";
import { ApiClient } from "../services/api";
import { 
  Ticket, 
  Send, 
  CheckCircle, 
  AlertTriangle, 
  Clock, 
  Terminal, 
  Check, 
  ShieldCheck, 
  Activity, 
  Cpu, 
  UserCheck 
} from "lucide-react";

interface TicketItem {
  id: string;
  topic: string;
  category: string;
  description: string;
  severity: "Minor" | "Major" | "Critical";
  status: "Pending" | "Investigating" | "Resolved";
  assignedAgent: string;
  traceId: string;
  timestamp: string;
  resolutionNotes?: string;
}

interface SupportCrmConsoleProps {
  showAlert: (msg: string) => void;
  onTicketDispatched?: () => void;
}

export const SupportCrmConsole: React.FC<SupportCrmConsoleProps> = ({ showAlert, onTicketDispatched }) => {
  const [tickets, setTickets] = useState<TicketItem[]>([]);
  const [topic, setTopic] = useState("");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState<"Minor" | "Major" | "Critical">("Minor");
  const [loading, setLoading] = useState(false);
  const [resolvingId, setResolvingId] = useState<string | null>(null);
  const [resolutionText, setResolutionText] = useState("");
  const [traceId] = useState(() => `TRC-${Math.floor(100 + Math.random() * 900)}-${Math.floor(10 + Math.random() * 90)}`);

  const fetchTickets = async () => {
    try {
      const data = await ApiClient.get("/support/tickets");
      if (data && data.tickets) {
        setTickets(data.tickets);
      }
    } catch (err) {
      console.error("Failed to fetch CRM tickets:", err);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim() || !description.trim()) {
      showAlert("Please fill in both the topic and detailed description.");
      return;
    }

    setLoading(true);
    try {
      const response = await ApiClient.post("/support/tickets", {
        topic: topic.trim(),
        description: description.trim(),
        severity,
        traceId
      });

      showAlert(`Incident ${response.ticket.id} automatically categorized under [${response.ticket.category}] & routed to ${response.ticket.assignedAgent}!`);
      setTopic("");
      setDescription("");
      fetchTickets();
      if (onTicketDispatched) onTicketDispatched();
    } catch (err: any) {
      showAlert(`Ticket creation failed: ${err.message || "Endpoint error"}`);
    } finally {
      setLoading(false);
    }
  };

  const handleResolveTicket = async (id: string) => {
    if (!resolutionText.trim()) {
      showAlert("Please enter resolution notes to mark the ticket as resolved.");
      return;
    }

    try {
      await ApiClient.post(`/support/tickets/${id}/resolve`, {
        resolutionNotes: resolutionText.trim()
      });
      showAlert(`Ticket ${id} resolved successfully.`);
      setResolvingId(null);
      setResolutionText("");
      fetchTickets();
    } catch (err: any) {
      showAlert(`Resolution update failed: ${err.message}`);
    }
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 font-mono text-xs">
      {/* LEFT: SUBMIT TICKET FORM */}
      <form onSubmit={handleSubmitTicket} className="xl:col-span-5 bg-[#07080b] border border-[#1a1d26] p-4 rounded space-y-4">
        <span className="text-[#00e676] font-extrabold text-[10px] uppercase tracking-wider block border-b border-[#151720] pb-1.5 flex items-center gap-1.5">
          <Ticket className="w-3.5 h-3.5 text-[#00e676]" />
          DISPATCH OPERATIONS HELP TICKET
        </span>

        <div className="flex flex-col gap-1">
          <label className="text-[#8a8d9a] text-[8px] font-bold uppercase">INCIDENT TOPIC / TITLE</label>
          <input
            type="text"
            required
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g. WebSocket frame delay on positions page"
            className="w-full bg-[#0d0e12] border border-[#1a1d26] text-white p-2 rounded text-[10.5px] font-mono outline-none focus:border-[#00e676]"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1">
            <label className="text-[#8a8d9a] text-[8px] font-bold uppercase">SEVERITY LEVEL</label>
            <select
              value={severity}
              onChange={(e) => setSeverity(e.target.value as any)}
              className="w-full bg-[#0d0e12] border border-[#1a1d26] text-white p-1.5 rounded text-[10px] font-bold outline-none cursor-pointer"
            >
              <option value="Minor">MINOR - NON-BLOCKING</option>
              <option value="Major">MAJOR - JITTER / LAG</option>
              <option value="Critical">CRITICAL - OUTAGE</option>
            </select>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-[#8a8d9a] text-[8px] font-bold uppercase">TRACE CORRELATION ID</label>
            <div className="bg-[#0c0d12] border border-[#1a1d26] text-[#8a8d9a] p-1.5 rounded text-[10px] text-center tracking-wider font-bold truncate select-all">
              {traceId}
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-[#8a8d9a] text-[8px] font-bold uppercase">DETAILED INCIDENT DESCRIPTION</label>
          <textarea
            required
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Please specify logs, regional errors (e.g. HTTP 451), or exact replication parameters for the engineering queue."
            className="w-full bg-[#0d0e12] border border-[#1a1d26] text-white p-2 rounded outline-none text-[10px] leading-relaxed resize-none focus:border-[#00e676]"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full py-2 bg-[#00e676] text-black font-extrabold hover:bg-[#00b25c] rounded text-[10px] tracking-wider uppercase transition-all flex items-center justify-center gap-1.5 cursor-pointer"
        >
          {loading ? (
            <>
              <Cpu className="w-3.5 h-3.5 animate-spin" />
              CLASSIFYING CORRELATIONS...
            </>
          ) : (
            <>
              <Send className="w-3 h-3" />
              DISPATCH TO CRM PIPELINE
            </>
          )}
        </button>

        <p className="text-[8px] text-[#8a8d9a] leading-normal">
          Every submitted ticket automatically appends your active <span className="text-white">WebSocket trace correlation ID</span> and undergoes machine-learned routing.
        </p>
      </form>

      {/* RIGHT: CRM SUPPORT DESK STATUS LEDGER */}
      <div className="xl:col-span-7 bg-[#07080b] border border-[#1a1d26] p-4 rounded flex flex-col min-h-[300px]">
        <div className="flex items-center justify-between border-b border-[#151720] pb-1.5 mb-3">
          <span className="text-[#3b82f6] font-extrabold text-[10px] uppercase tracking-wider flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-[#3b82f6] animate-pulse" />
            SUPPORT DESK INCIDENT STATUS LEDGER
          </span>
          <span className="text-[8px] text-[#8a8d9a] font-bold">
            SUPPORT ACTIVE: {tickets.length} TIERS
          </span>
        </div>

        <div className="flex-1 space-y-2 overflow-y-auto max-h-[310px] pr-1">
          {tickets.length === 0 ? (
            <div className="text-center py-10 text-[#8a8d9a] text-[10px]">
              No active tickets in queue. Use the dispatch panel on the left to route an incident.
            </div>
          ) : (
            tickets.map((t) => {
              const isResolved = t.status === "Resolved";
              const sevColor = t.severity === "Critical" ? "text-red-400 border-red-500/20 bg-red-500/10" : t.severity === "Major" ? "text-amber-400 border-amber-500/20 bg-amber-500/10" : "text-[#00e676] border-[#00e676]/20 bg-[#00e676]/10";
              const statusColor = t.status === "Resolved" ? "text-[#00e676] border-[#00e676]/30 bg-[#00e676]/10" : t.status === "Investigating" ? "text-amber-400 border-amber-500/30 bg-amber-500/10" : "text-sky-400 border-sky-500/30 bg-sky-500/10";

              return (
                <div key={t.id} className="bg-[#0c0d14] border border-[#161822] p-3 rounded space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-black text-[10px] tracking-wider">{t.id}</span>
                      <span className="text-[#8a8d9a]">•</span>
                      <span className={`px-1.5 py-0.2 rounded border text-[8px] font-extrabold uppercase ${sevColor}`}>
                        {t.severity}
                      </span>
                      <span className="text-[#8a8d9a]">•</span>
                      <span className="text-[#8a8d9a] text-[9.5px] uppercase font-bold">{t.category}</span>
                    </div>

                    <span className={`px-2 py-0.5 border rounded font-black text-[8px] uppercase tracking-wider ${statusColor}`}>
                      {t.status}
                    </span>
                  </div>

                  <p className="text-white font-bold text-[10.5px] leading-tight">{t.topic}</p>
                  <p className="text-[#8a8d9a] text-[9.5px] leading-relaxed">{t.description}</p>

                  <div className="grid grid-cols-2 gap-2 text-[9px] bg-[#07080c] p-2 rounded border border-[#14151b] text-[#8a8d9a]">
                    <div>ASSIGNED CO-PILOT: <span className="text-white font-bold">{t.assignedAgent}</span></div>
                    <div>TRACE_ID: <span className="text-white font-mono">{t.traceId}</span></div>
                  </div>

                  {t.resolutionNotes && (
                    <div className="bg-[#042113] border border-[#00e676]/20 text-[#00e676] p-2 rounded text-[9.5px] leading-relaxed">
                      <strong>RESOLUTION ACTION:</strong> {t.resolutionNotes}
                    </div>
                  )}

                  {!isResolved && (
                    <div className="pt-1.5 border-t border-[#12141a]">
                      {resolvingId === t.id ? (
                        <div className="space-y-2">
                          <textarea
                            rows={1.5}
                            value={resolutionText}
                            onChange={(e) => setResolutionText(e.target.value)}
                            placeholder="Enter troubleshooting action / resolution notes to sign-off..."
                            className="w-full bg-[#08090d] border border-[#3b82f6] text-white p-1.5 rounded outline-none text-[9.5px] leading-relaxed resize-none"
                          />
                          <div className="flex justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => setResolvingId(null)}
                              className="px-2.5 py-1 bg-[#12141c] text-[#8a8d9a] rounded hover:text-white"
                            >
                              CANCEL
                            </button>
                            <button
                              type="button"
                              onClick={() => handleResolveTicket(t.id)}
                              className="px-3 py-1 bg-[#3b82f6] text-white rounded font-bold hover:bg-[#2563eb]"
                            >
                              SIGN-OFF RESOLUTION
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            setResolvingId(t.id);
                            setResolutionText(`Reconnection diagnostics run. Synced with ${t.assignedAgent} resolution grid.`);
                          }}
                          className="px-2.5 py-1.5 bg-[#121622] hover:bg-[#3b82f6] text-[#3b82f6] hover:text-white border border-[#3b82f6]/20 rounded font-bold text-[8px] uppercase tracking-wider transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <UserCheck className="w-3 h-3" />
                          CRM SIMULATE RESOLUTION
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
