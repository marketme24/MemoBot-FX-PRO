import React, { useEffect, useRef } from "react";

interface NeuralCanvasProps {
  isThinking: boolean;
  intensity?: number;
}

export const NeuralCanvas: React.FC<NeuralCanvasProps> = ({ isThinking, intensity = 1 }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 600);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 200);

    const handleResize = () => {
      if (!canvas || !canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = canvas.parentElement.clientHeight;
    };
    window.addEventListener("resize", handleResize);

    // Particle Node Constellation
    const particleCount = 45;
    const particles = Array.from({ length: particleCount }).map(() => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.8,
      vy: (Math.random() - 0.5) * 0.8,
      radius: Math.random() * 2 + 1,
      hue: Math.random() > 0.5 ? 215 : 340, // Electric Blue or Magenta
    }));

    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, width, height);
      phase += isThinking ? 0.08 : 0.02;

      // Draw background ambient glow wave
      const gradient = ctx.createRadialGradient(
        width / 2,
        height / 2,
        10,
        width / 2,
        height / 2,
        width * 0.6
      );
      gradient.addColorStop(0, isThinking ? "rgba(250, 31, 78, 0.12)" : "rgba(0, 229, 255, 0.06)");
      gradient.addColorStop(1, "rgba(6, 7, 10, 0)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Update & Draw Particles
      particles.forEach((p, i) => {
        const speedMultiplier = isThinking ? 2.5 * intensity : 1;
        p.x += p.vx * speedMultiplier;
        p.y += p.vy * speedMultiplier;

        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        // Draw Node
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius * (isThinking ? 1.5 : 1), 0, Math.PI * 2);
        ctx.fillStyle = p.hue === 180 ? "rgba(59, 130, 246, 0.8)" : "rgba(250, 31, 78, 0.8)";
        ctx.shadowColor = p.hue === 180 ? "#3b82f6" : "#FA1F4E";
        ctx.shadowBlur = isThinking ? 12 : 5;
        ctx.fill();

        // Connect Lines to nearby nodes
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j];
          const dx = p.x - p2.x;
          const dy = p.y - p2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 90) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            const alpha = (1 - dist / 90) * (isThinking ? 0.6 : 0.25);
            ctx.strokeStyle =
              p.hue === 180
                ? `rgba(59, 130, 246, ${alpha})`
                : `rgba(250, 31, 78, ${alpha})`;
            ctx.lineWidth = isThinking ? 1.2 : 0.6;
            ctx.stroke();
          }
        }
      });

      // Sine Wave Quantum Soundwave Line
      ctx.beginPath();
      ctx.moveTo(0, height / 2);
      for (let x = 0; x < width; x += 4) {
        const amp = isThinking ? 24 * intensity : 8;
        const freq = 0.02;
        const y =
          height / 2 +
          Math.sin(x * freq + phase) * amp * Math.cos(x * 0.005) +
          (isThinking ? (Math.random() - 0.5) * 6 : 0);
        ctx.lineTo(x, y);
      }
      ctx.strokeStyle = isThinking
        ? "rgba(250, 31, 78, 0.7)"
        : "rgba(59, 130, 246, 0.4)";
      ctx.lineWidth = isThinking ? 2 : 1;
      ctx.stroke();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
    };
  }, [isThinking, intensity]);

  return (
    <div className="relative w-full h-full min-h-[140px] rounded overflow-hidden bg-[#06070a]/80 border border-[#1a1d26]">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
      <div className="absolute top-2 left-3 flex items-center gap-2 text-[9px] font-mono uppercase tracking-widest text-[#8a8d9a] pointer-events-none">
        <span
          className={`w-2 h-2 rounded-full ${
            isThinking ? "bg-[#FA1F4E] animate-ping" : "bg-[#3b82f6] animate-pulse"
          }`}
        />
        <span>{isThinking ? "NEURAL QUANT SYNTHESIS IN PROGRESS..." : "QUANTUM NEURAL FIELD ONLINE"}</span>
      </div>
    </div>
  );
};
