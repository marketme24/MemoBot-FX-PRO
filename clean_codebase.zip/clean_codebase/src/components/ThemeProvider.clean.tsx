import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export const FONT_MAP: Record<string, { label: string; font: string; family: string }> = {
  AQUIRE: { label: "AQUIRE (OTF)", font: "'Aquire', sans-serif", family: "Native Display" },
  MONTSERRAT: { label: "MONTSERRAT", font: "'Montserrat', sans-serif", family: "Modern Sans" },
  POPPINS: { label: "POPPINS", font: "'Poppins', sans-serif", family: "Clean Sans" },
  OSWALD: { label: "OSWALD", font: "'Oswald', sans-serif", family: "Condensed" },
  BEBAS_NEUE: { label: "BEBAS NEUE", font: "'Bebas Neue', sans-serif", family: "Bold Headline" },
  EXO2: { label: "EXO 2", font: "'Exo 2', sans-serif", family: "Futuristic" },
  OXANIUM: { label: "OXANIUM", font: "'Oxanium', sans-serif", family: "Cyber Gaming" },
  SYNE: { label: "SYNE", font: "'Syne', sans-serif", family: "Artistic" },
  TEKO: { label: "TEKO", font: "'Teko', sans-serif", family: "High Tech" },
  SORA: { label: "SORA", font: "'Sora', sans-serif", family: "Minimal" },
  ROBOTO: { label: "ROBOTO", font: "'Roboto', sans-serif", family: "Classic Sans" },
  ROBOTO_MONO: { label: "ROBOTO MONO", font: "'Roboto Mono', monospace", family: "Mono" },
  FIRA_CODE: { label: "FIRA CODE", font: "'Fira Code', monospace", family: "Code" },
  INTER: { label: "INTER", font: "'Inter', sans-serif", family: "Sans" },
  JETBRAINS: { label: "JETBRAINS", font: "'JetBrains Mono', monospace", family: "Mono" },
  ORBITRON: { label: "ORBITRON", font: "'Orbitron', sans-serif", family: "Sci-Fi" },
  RAJDHANI: { label: "RAJDHANI", font: "'Rajdhani', sans-serif", family: "Modern" },
  GROTESK: { label: "SPACE GROTESK", font: "'Space Grotesk', sans-serif", family: "Clean" },
  SYNCOPATE: { label: "SYNCOPATE", font: "'Syncopate', sans-serif", family: "Expanded" },
  AUDIOWIDE: { label: "AUDIOWIDE", font: "'Audiowide', sans-serif", family: "Futuristic" },
  BRUNO_ACE: { label: "BRUNO ACE", font: "'Bruno Ace', sans-serif", family: "Tech" },
  CHAKRA: { label: "CHAKRA PETCH", font: "'Chakra Petch', sans-serif", family: "Cyber" },
  MICHROMA: { label: "MICHROMA", font: "'Michroma', sans-serif", family: "Display" },
  PLAYFAIR: { label: "PLAYFAIR", font: "'Playfair Display', serif", family: "Serif" },
  CINZEL: { label: "CINZEL", font: "'Cinzel', serif", family: "Luxury" },
  ELECTROLIZE: { label: "ELECTROLIZE", font: "'Electrolize', sans-serif", family: "Tech" },
  PRESS_START: { label: "PRESS START 2P", font: "'Press Start 2P', cursive", family: "Retro Arcade" },
  VT323: { label: "VT323", font: "'VT323', monospace", family: "Terminal" },
  QUANTICO: { label: "QUANTICO", font: "'Quantico', sans-serif", family: "Military Tech" },
  SHARE_TECH: { label: "SHARE TECH MONO", font: "'Share Tech Mono', monospace", family: "Cyber Mono" },
};

export const COLOR_OPTIONS = [
  { id: "#FA1F4E", name: "MemoBot Crimson" },
  { id: "#38bdf8", name: "Electric Sky Blue" },
  { id: "#00e676", name: "Islamic Emerald" },
  { id: "#f59e0b", name: "Amber Gold" },
  { id: "#a855f7", name: "Neon Purple" },
  { id: "#ff6d00", name: "Bright Orange" },
];

export interface NavItemDef {
  id: string;
  label: string;
}

export interface NavSectionDef {
  id: string;
  title: string;
  items: NavItemDef[];
}

export const DEFAULT_SIDEBAR_SECTIONS: NavSectionDef[] = [
  {
    id: "sec-core",
    title: "CORE WORKSPACE",
    items: [
      { id: "dashboard", label: "DASHBOARD" },
      { id: "engines", label: "CENTRAL ENGINE STATION" },
      { id: "strategies", label: "STRATEGIES" },
      { id: "live-positions", label: "RISK MANAGER" },
      { id: "shariyah-bureau", label: "SHARIYAH BUREAU" },
      { id: "market-intel", label: "MARKET OVERVIEW" },
    ]
  },
  {
    id: "sec-gateway",
    title: "TRADING GATEWAY",
    items: [
      { id: "portfolio", label: "INDIVIDUAL TRADE" },
      { id: "orders", label: "PAPER TRADE" },
    ]
  },
  {
    id: "sec-memotech",
    title: "MEMO-TECH",
    items: [
      { id: "ai-chat", label: "MEMOBOT AI" },
      { id: "analytics", label: "HIGHTECHEYE" },
      { id: "secure-vault", label: "MEMOBOT VAULT" },
      { id: "business-club", label: "MEMO BUSINESS CLUB" },
    ]
  },
  {
    id: "sec-system",
    title: "SYSTEM CONTROLS",
    items: [
      { id: "audit", label: "AUDITING HUB" },
      { id: "settings", label: "SETTINGS" },
    ]
  }
];

interface ThemeContextType {
  accentColor: string;
  setAccentColor: (color: string) => void;
  selectedFont: string;
  setSelectedFont: (font: string) => void;
  fontWeight: string;
  setFontWeight: (weight: string) => void;
  fontStyle: string;
  setFontStyle: (style: string) => void;
  letterSpacing: string;
  setLetterSpacing: (spacing: string) => void;
  textTransform: string;
  setTextTransform: (transform: string) => void;
  brandRedTitle: string;
  setBrandRedTitle: (val: string) => void;
  brandWhiteTitle: string;
  setBrandWhiteTitle: (val: string) => void;
  brandSubtitle: string;
  setBrandSubtitle: (val: string) => void;
  sidebarSections: NavSectionDef[];
  setSidebarSections: React.Dispatch<React.SetStateAction<NavSectionDef[]>>;
  moveSectionUp: (sectionIdx: number) => void;
  moveSectionDown: (sectionIdx: number) => void;
  moveItemUp: (sectionIdx: number, itemIdx: number) => void;
  moveItemDown: (sectionIdx: number, itemIdx: number) => void;
  renameSection: (sectionIdx: number, newTitle: string) => void;
  renameItem: (sectionIdx: number, itemIdx: number, newLabel: string) => void;
  resetSidebarToDefault: () => void;
  inspectorActive: boolean;
  setInspectorActive: (active: boolean) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

function hexToRgb(hex: string): string {
  let c = hex.replace("#", "");
  if (c.length === 3) {
    c = c.split("").map((x) => x + x).join("");
  }
  const num = parseInt(c, 16);
  if (isNaN(num)) return "250, 31, 78";
  return `${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}`;
}

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [inspectorActive, setInspectorActive] = useState<boolean>(false);

  const [accentColor, setAccentColorState] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.accentColor) return parsed.accentColor;
      }
    } catch (e) {}
    return "#FA1F4E";
  });

  const [selectedFont, setSelectedFontState] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.selectedFont) return parsed.selectedFont;
      }
    } catch (e) {}
    return "AQUIRE";
  });

  const [fontWeight, setFontWeight] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.fontWeight) return parsed.fontWeight;
      }
    } catch (e) {}
    return "700";
  });

  const [fontStyle, setFontStyle] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.fontStyle) return parsed.fontStyle;
      }
    } catch (e) {}
    return "normal";
  });

  const [letterSpacing, setLetterSpacing] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.letterSpacing) return parsed.letterSpacing;
      }
    } catch (e) {}
    return "0.05em";
  });

  const [textTransform, setTextTransform] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.textTransform) return parsed.textTransform;
      }
    } catch (e) {}
    return "uppercase";
  });

  const [brandRedTitle, setBrandRedTitle] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.brandRedTitle) return parsed.brandRedTitle;
      }
    } catch (e) {}
    return "MEMOBOT";
  });

  const [brandWhiteTitle, setBrandWhiteTitle] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.brandWhiteTitle) return parsed.brandWhiteTitle;
      }
    } catch (e) {}
    return "FX-PRO";
  });

  const [brandSubtitle, setBrandSubtitle] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_THEME_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.brandSubtitle) return parsed.brandSubtitle;
      }
    } catch (e) {}
    return "PRIME EDITION • HIGH-PRECISION TRADING";
  });

  const [sidebarSections, setSidebarSections] = useState<NavSectionDef[]>(() => {
    try {
      const saved = localStorage.getItem("MEMOBOT_SIDEBAR_CONFIG");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Check if ORBIT-ME AI is present and upgrade it to MEMO-TECH
          const orbitSec = parsed.find((s: NavSectionDef) => s.id === "sec-[#orbit]" || s.title === "ORBIT-ME AI");
          if (orbitSec) {
            orbitSec.id = "sec-memotech";
            orbitSec.title = "MEMO-TECH";
          }
          let memoTechSec = parsed.find((s: NavSectionDef) => s.id === "sec-memotech" || s.title === "MEMO-TECH");
          if (memoTechSec) {
            memoTechSec.title = "MEMO-TECH";
            if (!memoTechSec.items.some((i: NavItemDef) => i.id === "secure-vault")) {
              memoTechSec.items.push({ id: "secure-vault", label: "MEMOBOT VAULT" });
            }
            if (!memoTechSec.items.some((i: NavItemDef) => i.id === "business-club")) {
              memoTechSec.items.push({ id: "business-club", label: "MEMO BUSINESS CLUB" });
            }
          }
          // Remove duplicate secure-vault from sec-system if present
          const sysSec = parsed.find((s: NavSectionDef) => s.id === "sec-system");
          if (sysSec) {
            sysSec.items = sysSec.items.filter((i: NavItemDef) => i.id !== "secure-vault");
          }

          const core = parsed.find((s: NavSectionDef) => s.id === "sec-core");
          if (core && !core.items.some((i: NavItemDef) => i.id === "shariyah-bureau")) {
            core.items.splice(5, 0, { id: "shariyah-bureau", label: "SHARIYAH BUREAU" });
          }
          return parsed;
        }
      }
    } catch (e) {}
    return DEFAULT_SIDEBAR_SECTIONS;
  });

  useEffect(() => {
    const rgb = hexToRgb(accentColor);
    let fontVal = "'Aquire', sans-serif";

    if (FONT_MAP[selectedFont]) {
      fontVal = FONT_MAP[selectedFont].font;
    } else if (selectedFont && selectedFont.trim() !== "") {
      const cleanFontName = selectedFont.trim();
      fontVal = `'${cleanFontName}', sans-serif`;
      
      // Inject custom Google Font link dynamically
      const linkId = "custom-google-font-loader";
      let linkEl = document.getElementById(linkId) as HTMLLinkElement | null;
      if (!linkEl) {
        linkEl = document.createElement("link");
        linkEl.id = linkId;
        linkEl.rel = "stylesheet";
        document.head.appendChild(linkEl);
      }
      linkEl.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(cleanFontName)}:ital,wght@0,300;0,400;0,600;0,700;0,900;1,400&display=swap`;
    }

    document.documentElement.style.setProperty("--color-primary", accentColor);
    document.documentElement.style.setProperty("--color-primary-rgb", rgb);
    document.documentElement.style.setProperty("--font-aquire-custom", fontVal);
    document.documentElement.style.setProperty("--font-weight-custom", fontWeight);
    document.documentElement.style.setProperty("--font-style-custom", fontStyle);
    document.documentElement.style.setProperty("--letter-spacing-custom", letterSpacing);
    document.documentElement.style.setProperty("--text-transform-custom", textTransform);

    localStorage.setItem(
      "MEMOBOT_THEME_CONFIG",
      JSON.stringify({
        accentColor,
        selectedFont,
        fontWeight,
        fontStyle,
        letterSpacing,
        textTransform,
        brandRedTitle,
        brandWhiteTitle,
        brandSubtitle,
      })
    );
  }, [accentColor, selectedFont, fontWeight, fontStyle, letterSpacing, textTransform, brandRedTitle, brandWhiteTitle, brandSubtitle]);

  useEffect(() => {
    localStorage.setItem("MEMOBOT_SIDEBAR_CONFIG", JSON.stringify(sidebarSections));
  }, [sidebarSections]);

  const setAccentColor = (color: string) => setAccentColorState(color);
  const setSelectedFont = (fontKey: string) => setSelectedFontState(fontKey);

  const moveSectionUp = (sectionIdx: number) => {
    if (sectionIdx <= 0) return;
    setSidebarSections((prev) => {
      const copy = [...prev];
      const temp = copy[sectionIdx];
      copy[sectionIdx] = copy[sectionIdx - 1];
      copy[sectionIdx - 1] = temp;
      return copy;
    });
  };

  const moveSectionDown = (sectionIdx: number) => {
    setSidebarSections((prev) => {
      if (sectionIdx >= prev.length - 1) return prev;
      const copy = [...prev];
      const temp = copy[sectionIdx];
      copy[sectionIdx] = copy[sectionIdx + 1];
      copy[sectionIdx + 1] = temp;
      return copy;
    });
  };

  const moveItemUp = (sectionIdx: number, itemIdx: number) => {
    if (itemIdx <= 0) return;
    setSidebarSections((prev) => {
      const copy = [...prev];
      const section = { ...copy[sectionIdx] };
      const items = [...section.items];
      const temp = items[itemIdx];
      items[itemIdx] = items[itemIdx - 1];
      items[itemIdx - 1] = temp;
      section.items = items;
      copy[sectionIdx] = section;
      return copy;
    });
  };

  const moveItemDown = (sectionIdx: number, itemIdx: number) => {
    setSidebarSections((prev) => {
      const section = prev[sectionIdx];
      if (itemIdx >= section.items.length - 1) return prev;
      const copy = [...prev];
      const newSec = { ...section };
      const items = [...newSec.items];
      const temp = items[itemIdx];
      items[itemIdx] = items[itemIdx + 1];
      items[itemIdx + 1] = temp;
      newSec.items = items;
      copy[sectionIdx] = newSec;
      return copy;
    });
  };

  const renameSection = (sectionIdx: number, newTitle: string) => {
    setSidebarSections((prev) => {
      const copy = [...prev];
      copy[sectionIdx] = { ...copy[sectionIdx], title: newTitle };
      return copy;
    });
  };

  const renameItem = (sectionIdx: number, itemIdx: number, newLabel: string) => {
    setSidebarSections((prev) => {
      const copy = [...prev];
      const sec = { ...copy[sectionIdx] };
      const items = [...sec.items];
      items[itemIdx] = { ...items[itemIdx], label: newLabel };
      sec.items = items;
      copy[sectionIdx] = sec;
      return copy;
    });
  };

  const resetSidebarToDefault = () => {
    setSidebarSections(DEFAULT_SIDEBAR_SECTIONS);
  };

  return (
    <ThemeContext.Provider
      value={{
        accentColor,
        setAccentColor,
        selectedFont,
        setSelectedFont,
        fontWeight,
        setFontWeight,
        fontStyle,
        setFontStyle,
        letterSpacing,
        setLetterSpacing,
        textTransform,
        setTextTransform,
        brandRedTitle,
        setBrandRedTitle,
        brandWhiteTitle,
        setBrandWhiteTitle,
        brandSubtitle,
        setBrandSubtitle,
        sidebarSections,
        setSidebarSections,
        moveSectionUp,
        moveSectionDown,
        moveItemUp,
        moveItemDown,
        renameSection,
        renameItem,
        resetSidebarToDefault,
        inspectorActive,
        setInspectorActive,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
};
