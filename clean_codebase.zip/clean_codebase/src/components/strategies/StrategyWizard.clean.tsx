import React, { useState } from "react";
import { 
  Sparkles, 
  ArrowRight, 
  Coins, 
  Play, 
  Cpu, 
  Flame, 
  ShieldCheck, 
  HelpCircle, 
  CheckCircle2, 
  AlertTriangle 
} from "lucide-react";

interface StrategyWizardProps {
  onDeploy: (strategyName: string, asset: string, amount: number, config: any, engineId: string) => void;
  isDeploying?: boolean;
}

const EXPANDED_COINS = [
  "BTC", "ETH", "SOL", "BNB", "ADA", "XRP", "DOT", "LINK", "AVAX", "MATIC",
  "TRX", "NEAR", "FIL", "ICP", "LTC", "UNI", "DOGE", "SHIB", "ATOM", "XLM",
  "APT", "OP", "ARB", "SUI", "INJ", "TIA", "SEI", "FET", "RNDR", "WLD"
];

const ALGORITHMS = [
  { 
    id: "SIRIUS", 
    name: "SIRIUS MOMENTUM TREND", 
    desc: "Follows strong bullish momentum with trailing stop locks.",
    complexity: "Simple",
    winRate: "74.8%",
    defaultConfig: { ema_fast: 18, ema_slow: 45, stop_loss: 2.0, leverage: 1 }
  },
  { 
    id: "RIGEL", 
    name: "RIGEL HFT SCALPER", 
    desc: "High-frequency micro-channel scalper for sideways consolidation.",
    complexity: "Intermediate",
    winRate: "79.2%",
    defaultConfig: { ema_fast: 12, ema_slow: 28, stop_loss: 1.5, leverage: 1 }
  },
  { 
    id: "CANOPUS", 
    name: "CANOPUS STAT ARBITRAGE", 
    desc: "Statistical arbitrage model based on multi-exchange price spreads.",
    complexity: "Expert",
    winRate: "82.4%",
    defaultConfig: { ema_fast: 15, ema_slow: 35, stop_loss: 2.5, leverage: 1 }
  },
  { 
    id: "HALAL", 
    name: "HALAL GUARD GRID", 
    desc: "Islamic compliance grid order routing with 100% physical spot asset backing.",
    complexity: "Simple",
    winRate: "70.5%",
    defaultConfig: { ema_fast: 22, ema_slow: 55, stop_loss: 1.2, leverage: 1 }
  }
];

const ENGINES_MAP = [
  { id: "ENG-001", exch: "Binance", name: "Binance Engine Slot 1" },
  { id: "ENG-002", exch: "Binance", name: "Binance Engine Slot 2" },
  { id: "ENG-003", exch: "Binance", name: "Binance Engine Slot 3" },
  { id: "ENG-004", exch: "KuCoin", name: "KuCoin Engine Slot 1" },
  { id: "ENG-005", exch: "KuCoin", name: "KuCoin Engine Slot 2" },
  { id: "ENG-006", exch: "KuCoin", name: "KuCoin Engine Slot 3" },
  { id: "ENG-007", exch: "OKX", name: "OKX Engine Slot 1" },
  { id: "ENG-008", exch: "OKX", name: "OKX Engine Slot 2" },
  { id: "ENG-009", exch: "OKX", name: "OKX Engine Slot 3" },
  { id: "ENG-010", exch: "Bybit", name: "Bybit Engine Slot 1" },
  { id: "ENG-011", exch: "Bybit", name: "Bybit Engine Slot 2" },
  { id: "ENG-012", exch: "Bybit", name: "Bybit Engine Slot 3" }
];

export const StrategyWizard: React.FC<StrategyWizardProps> = ({ onDeploy, isDeploying = false }) => {
  const [step, setStep] = useState(1);
  const [selectedAlgo, setSelectedAlgo] = useState(ALGORITHMS[0]);
  const [selectedCoin, setSelectedCoin] = useState("BTC");
  const [tradeAmount, setTradeAmount] = useState(250);
  const [targetEngine, setTargetEngine] = useState("ENG-001");
  const [customParams, setCustomParams] = useState<any>(ALGORITHMS[0].defaultConfig);
  const [aiOptimized, setAiOptimized] = useState(false);
  const [optimizationMessage, setOptimizationMessage] = useState("");

  const handleSelectAlgo = (algo: typeof ALGORITHMS[0]) => {
    setSelectedAlgo(algo);
    setCustomParams(algo.defaultConfig);
    setAiOptimized(false);
    setOptimizationMessage("");
  };

  const runAiOptimization = () => {
    setAiOptimized(true);
    // Generate beautiful custom optimized strategy params for this coin dynamically
    const coinHash = selectedCoin.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const emaFast = 10 + (coinHash % 12);
    const emaSlow = 25 + (coinHash % 25);
    const stopLoss = 1.0 + parseFloat(((coinHash % 15) / 10).toFixed(1));
    
    setCustomParams({
      ema_fast: emaFast,
      ema_slow: emaSlow,
      stop_loss: stopLoss,
      leverage: 1
    });

    setOptimizationMessage(
      `AI Copilot analyzed ${selectedCoin} historical volatility: Configured specialized High-Efficiency EMA (${emaFast}/${emaSlow}) with conservative ${stopLoss}% Spot Safety Buffer.`
    );
  };

  const triggerDeploy = () => {
    const finalName = `Wizard_${selectedAlgo.id}_${selectedCoin}`;
    onDeploy(finalName, `${selectedCoin}USDT`, tradeAmount, customParams, targetEngine);
  };

  return (
    <div className="bg-[#0d0e12] border border-[#FA1F4E]/25 rounded-lg p-5 relative overflow-hidden font-mono text-xs">
      {/* Decorative high tech grid header */}
      <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-[#FA1F4E] via-[#00f2ff] to-[#00e676]" />
      
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-[#1a1d26] pb-3 mb-4">
        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-white font-black text-sm uppercase">
            <Sparkles className="w-4 h-4 text-[#f59e0b] animate-pulse" />
            <span>SWARM CREATION WIZARD</span>
            <span className="text-[9px] bg-[#00f2ff]/10 text-[#00f2ff] border border-[#00f2ff]/30 px-1.5 py-0.2 rounded font-normal lowercase">Zero Complexity</span>
          </div>
          <p className="text-[10px] text-[#8a8d9a] font-sans">
            Configure, backtest, and connect your algorithmic strategies with any of our 12 engines in 3 steps.
          </p>
        </div>
        
        {/* Step Indicator Bullets */}
        <div className="flex items-center gap-2 bg-[#06070a] border border-[#1a1d26] px-3 py-1 rounded">
          {[1, 2, 3].map((num) => (
            <div key={num} className="flex items-center gap-1">
              <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-bold ${
                step === num 
                  ? "bg-[#FA1F4E] text-white" 
                  : step > num 
                  ? "bg-[#00e676] text-black" 
                  : "bg-[#1a1d26] text-[#8a8d9a]"
              }`}>
                {num}
              </span>
              <span className={`text-[8px] font-bold ${step === num ? "text-white" : "text-[#8a8d9a]"}`}>
                {num === 1 ? "ALGO" : num === 2 ? "ASSET" : "ENGINE"}
              </span>
              {num < 3 && <span className="text-[#1a1d26]">&gt;</span>}
            </div>
          ))}
        </div>
      </div>

      {/* Step 1: Select Algorithm Template */}
      {step === 1 && (
        <div className="space-y-4">
          <div className="text-[10px] text-[#8a8d9a] font-bold uppercase tracking-wider">
            STEP 1: SELECT YOUR TRADING CORE ALGORITHM
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {ALGORITHMS.map((algo) => (
              <div 
                key={algo.id}
                onClick={() => handleSelectAlgo(algo)}
                className={`p-3 rounded border cursor-pointer transition-all flex flex-col justify-between h-28 ${
                  selectedAlgo.id === algo.id 
                    ? "bg-[#FA1F4E]/10 border-[#FA1F4E] shadow-[0_0_10px_rgba(250,31,78,0.1)]" 
                    : "bg-[#06070a] border-[#1a1d26] hover:border-[#FA1F4E]/40"
                }`}
              >
                <div>
                  <div className="flex justify-between items-center">
                    <span className="text-white font-extrabold">{algo.name}</span>
                    <span className="text-[8px] bg-black/40 px-1.5 py-0.2 rounded text-[#00e676] border border-[#1a1d26]">
                      WR: {algo.winRate}
                    </span>
                  </div>
                  <p className="text-[10px] text-[#8a8d9a] font-sans mt-1 leading-relaxed">
                    {algo.desc}
                  </p>
                </div>
                <div className="flex justify-between items-center text-[9px] text-[#8a8d9a] border-t border-[#1a1d26]/40 pt-1.5 mt-1">
                  <span>LEVEL: <span className="text-[#f59e0b] font-bold">{algo.complexity}</span></span>
                  <span className="text-emerald-400 font-bold uppercase text-[8.5px]">🕌 SHARIAH APPROVED</span>
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={() => setStep(2)}
              className="flex items-center gap-1 px-4 py-2 bg-[#FA1F4E] hover:bg-[#d4153d] text-white font-extrabold uppercase rounded"
            >
              <span>NEXT STEP: DEFINE ASSET</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Define Asset Sizing */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="text-[10px] text-[#8a8d9a] font-bold uppercase tracking-wider">
            STEP 2: CHOOSE FROM 30+ ASSETS (10X EXPANSION) & TRADING BUDGET
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            {/* Coin selector grid */}
            <div className="md:col-span-8 space-y-2">
              <label className="text-[#8a8d9a] text-[9px] uppercase font-bold block">
                SELECT ASSET (COMPLIANT SPOT LIQUIDITY):
              </label>
              <div className="grid grid-cols-6 sm:grid-cols-10 gap-1 bg-[#06070a] border border-[#1a1d26] p-2 rounded max-h-[110px] overflow-y-auto">
                {EXPANDED_COINS.map((coin) => (
                  <button
                    key={coin}
                    onClick={() => {
                      setSelectedCoin(coin);
                      setAiOptimized(false);
                      setOptimizationMessage("");
                    }}
                    className={`py-1 text-[9px] font-bold rounded border transition-colors ${
                      selectedCoin === coin
                        ? "bg-[#00f2ff]/20 border-[#00f2ff] text-white"
                        : "bg-black/30 text-[#8a8d9a] border-[#1a1d26] hover:border-white/20"
                    }`}
                  >
                    {coin}
                  </button>
                ))}
              </div>
            </div>

            {/* Sizing & Slices */}
            <div className="md:col-span-4 space-y-3">
              <div className="space-y-1.5">
                <label className="text-[#8a8d9a] text-[9px] uppercase font-bold block">
                  CAPITAL ALLOCATION (USDT):
                </label>
                <div className="relative">
                  <input
                    type="number"
                    min="10"
                    max="10000"
                    value={tradeAmount}
                    onChange={(e) => setTradeAmount(parseInt(e.target.value) || 10)}
                    className="w-full bg-[#06070a] border border-[#1a1d26] text-white text-xs px-2.5 py-2 rounded outline-none focus:border-[#00f2ff]"
                  />
                  <span className="absolute right-2 top-2 text-[9px] text-[#8a8d9a] font-bold">USDT</span>
                </div>
              </div>

              {/* AI Auto Optimization feature */}
              <button
                onClick={runAiOptimization}
                className="w-full py-2 bg-[#00f2ff]/10 hover:bg-[#00f2ff]/20 text-[#00f2ff] border border-[#00f2ff]/40 rounded font-bold uppercase text-[9.5px] transition-colors flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#f59e0b] animate-pulse" />
                AI OPTIMAL PARAMETERS SUGGEST
              </button>
            </div>
          </div>

          {/* AI Optimizer recommendation banner */}
          {aiOptimized && (
            <div className="bg-[#00f2ff]/5 border border-[#00f2ff]/30 p-2.5 rounded text-[9.5px] text-[#00f2ff] leading-relaxed flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#00e676] shrink-0 mt-0.5" />
              <span>{optimizationMessage}</span>
            </div>
          )}

          <div className="flex justify-between pt-2">
            <button
              onClick={() => setStep(1)}
              className="px-4 py-2 border border-[#1a1d26] hover:bg-[#1a1d26] text-white uppercase rounded"
            >
              BACK
            </button>
            <button
              onClick={() => setStep(3)}
              className="flex items-center gap-1 px-4 py-2 bg-[#FA1F4E] hover:bg-[#d4153d] text-white font-extrabold uppercase rounded"
            >
              <span>NEXT STEP: ENGINE SLOT</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Select Engine Slot & Deploy */}
      {step === 3 && (
        <div className="space-y-4">
          <div className="text-[10px] text-[#8a8d9a] font-bold uppercase tracking-wider">
            STEP 3: SECURE BINDING TO ONE OF 12 CENTRAL SWARM ENGINES
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {["Binance", "KuCoin", "OKX", "Bybit"].map((exch) => (
              <div key={exch} className="bg-[#06070a] border border-[#1a1d26] p-2.5 rounded space-y-2">
                <span className="text-white font-bold text-[10px] border-b border-[#1a1d26] pb-1 block uppercase">
                  {exch} Swarm Slots
                </span>
                <div className="space-y-1.5">
                  {ENGINES_MAP.filter(e => e.exch === exch).map((engine) => (
                    <div 
                      key={engine.id}
                      onClick={() => setTargetEngine(engine.id)}
                      className={`p-1.5 rounded border text-[10.5px] font-bold cursor-pointer transition-colors flex justify-between items-center ${
                        targetEngine === engine.id
                          ? "bg-[#00e676]/20 border-[#00e676] text-white"
                          : "bg-black/40 border-transparent text-[#8a8d9a] hover:bg-black/60"
                      }`}
                    >
                      <span>{engine.name}</span>
                      <span className={`w-1.5 h-1.5 rounded-full ${targetEngine === engine.id ? "bg-[#00e676]" : "bg-[#8a8d9a]/30"}`} />
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Engine Capacity & Safety Limit Notice */}
          <div className="p-3 bg-[#11131c]/50 border border-[#1a1d26] rounded-md flex gap-2 items-start">
            <ShieldCheck className="w-4 h-4 text-[#00e676] shrink-0 mt-0.5" />
            <p className="text-[9px] text-[#8a8d9a] font-sans leading-relaxed">
              <strong>Institutional Security Standard:</strong> Memobot automatically deploys this algorithm with zero-interest physical spot collateral. In case of full system engine capacity, a built-in auto-balancing priority queue will coordinate rate-limited executions securely.
            </p>
          </div>

          <div className="flex justify-between pt-2">
            <button
              onClick={() => setStep(2)}
              className="px-4 py-2 border border-[#1a1d26] hover:bg-[#1a1d26] text-white uppercase rounded"
            >
              BACK
            </button>
            <button
              onClick={triggerDeploy}
              disabled={isDeploying}
              className="flex items-center gap-1.5 px-5 py-2.5 bg-gradient-to-r from-[#00e676] to-[#00f2ff] hover:brightness-110 text-black font-extrabold uppercase rounded shadow-[0_0_15px_rgba(0,230,118,0.25)]"
            >
              <Play className="w-4 h-4 fill-current text-black" />
              <span>COMPILED & DEPLOY TO SWARM</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
