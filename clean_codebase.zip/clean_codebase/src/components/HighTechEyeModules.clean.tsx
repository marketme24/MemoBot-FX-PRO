import React, { useState } from "react";
import { Zap, ShieldAlert, RefreshCw, Activity, CheckCircle2, Play, AlertTriangle, Terminal } from "lucide-react";

interface ObservabilityMetrics {
  cpu_usage_pct: number;
  ram_usage_pct: number;
  db_latency_ms: number;
  queue_depth: number;
  active_threads: number;
}

interface HighTechEyeModulesProps {
  metrics: ObservabilityMetrics;
  onShowAlert: (msg: string) => void;
}

export const HighTechEyeModules: React.FC<HighTechEyeModulesProps> = ({ metrics, onShowAlert }) => {
  // Self-Repair State
  const [repairState, setRepairState] = useState<{
    lastAction: string;
    result: string;
    correlationId: string;
    isRunning: boolean;
  }>({
    lastAction: "None",
    result: "N/A",
    correlationId: "N/A",
    isRunning: false,
  });

  // Sandbox Simulation State
  const [simState, setSimState] = useState<{
    amount: number;
    type: string;
    corridor: string;
    status: string;
    isSimulating: boolean;
  }>({
    amount: 1000,
    type: "FX / Payment",
    corridor: "USD → AED",
    status: "Ready",
    isSimulating: false,
  });

  // Stress Test State
  const [stressMode, setStressMode] = useState<string>("Idle");

  const handleRunRepair = (actionName: string) => {
    setRepairState((prev) => ({ ...prev, isRunning: true }));
    const generatedId = `CORR-FIX-${Math.floor(100000 + Math.random() * 900000)}`;
    
    setTimeout(() => {
      setRepairState({
        lastAction: actionName,
        result: "SUCCESS — NOMINAL",
        correlationId: generatedId,
        isRunning: false,
      });
      onShowAlert(`[REPAIR ENGINE] Executed ${actionName} successfully. Tracking ID: ${generatedId}`);
    }, 800);
  };

  const handleRunSimulation = () => {
    setSimState((prev) => ({ ...prev, isSimulating: true, status: "Processing..." }));
    setTimeout(() => {
      setSimState((prev) => ({
        ...prev,
        isSimulating: false,
        status: "Approved — Vault Verified",
      }));
      onShowAlert("[SANDBOX SIMULATION] Transaction route verified across Vault & Gateway.");
    }, 600);
  };

  const handleToggleStress = (mode: string) => {
    if (stressMode === mode) {
      setStressMode("Idle");
      onShowAlert("[STRESS TEST] Deactivated stress testing mode.");
    } else {
      setStressMode(mode);
      onShowAlert(`[STRESS TEST] Activated ${mode} mode. Monitoring system throughput...`);
    }
  };

  return (
    <div className="space-y-4">
      {/* MODULE 1 — CORRELATION MAP */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded text-xs space-y-3">
        <div className="text-[10px] uppercase text-[#3b82f6] font-bold tracking-widest flex items-center gap-2">
          <Activity className="w-3.5 h-3.5" />
          <span>Unified Correlation Map</span>
        </div>
        <div className="text-[11px] text-[#8a8d9a]">Vault → Engine → Gateway → Banking → Risk → Compliance</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
          <div className="bg-[#06070a] rounded p-3 border border-[#11131c] space-y-1">
            <div className="text-[10px] uppercase text-[#8a8d9a] font-bold mb-1">Core Flow</div>
            <div>Vault → Engine: <span className="text-[#3b82f6] font-bold">Stable</span></div>
            <div>Engine → Gateway: <span className="text-[#3b82f6] font-bold">Stable</span></div>
            <div>Gateway → Banking: <span className="text-amber-400 font-bold">Sensitive</span></div>
          </div>
          <div className="bg-[#06070a] rounded p-3 border border-[#11131c] space-y-1">
            <div className="text-[10px] uppercase text-[#8a8d9a] font-bold mb-1">Risk Chain</div>
            <div>Compliance → FX: <span className="text-[#3b82f6] font-bold">Aligned</span></div>
            <div>FX → Balances: <span className="text-white font-bold">Normal</span></div>
            <div>Balances → PnL: <span className="text-white font-bold">Normal</span></div>
          </div>
        </div>
      </div>

      {/* MODULE 2 — PREDICTIVE FAILURE AI & DEPENDENCY GRAPH */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded text-xs space-y-2">
          <div className="text-[10px] uppercase text-[#3b82f6] font-bold tracking-widest">Predictive Failure AI</div>
          <div className="bg-[#06070a] p-3 rounded border border-[#11131c] space-y-1 text-[11px]">
            <div>Endpoint Failure Risk: <span className="text-[#00e676] font-bold">Low (1.2%)</span></div>
            <div>24h Latency Forecast: <span className="text-white font-bold">+{metrics.db_latency_ms}ms</span></div>
            <div>Compliance Stress: <span className="text-[#3b82f6] font-bold">Nominal</span></div>
          </div>
        </div>

        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded text-xs space-y-2">
          <div className="text-[10px] uppercase text-[#3b82f6] font-bold tracking-widest">System Dependency Graph</div>
          <div className="bg-[#06070a] p-3 rounded border border-[#11131c] space-y-1 text-[11px]">
            <div>DB Cluster: <span className="text-[#00e676] font-bold">Online</span></div>
            <div>Redis Cache: <span className="text-[#00e676] font-bold">Online</span></div>
            <div>Encryption Vault: <span className="text-[#00e676] font-bold">Secure</span></div>
          </div>
        </div>
      </div>

      {/* MODULE 3 — TRANSACTION SIMULATION SANDBOX */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded text-xs space-y-3">
        <div className="flex justify-between items-center border-b border-[#11131c] pb-2">
          <span className="text-[10px] uppercase text-[#3b82f6] font-bold tracking-widest">Transaction Simulation Sandbox</span>
          <button
            onClick={handleRunSimulation}
            disabled={simState.isSimulating}
            className="px-2.5 py-1 bg-[#06070a] hover:bg-[#3b82f6]/20 border border-[#3b82f6]/40 text-[#3b82f6] rounded text-[10px] font-bold uppercase transition-all flex items-center gap-1 disabled:opacity-50"
          >
            <Play className="w-3 h-3" />
            <span>{simState.isSimulating ? "Simulating..." : "Run Test Simulation"}</span>
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
          <div className="bg-[#06070a] p-3 rounded border border-[#11131c] space-y-1">
            <div className="text-[10px] text-[#8a8d9a] font-bold uppercase">Simulation Inputs</div>
            <div>Type: <span className="text-white">{simState.type}</span></div>
            <div>Amount: <span className="text-white">{simState.amount} USDT</span></div>
            <div>Corridor: <span className="text-white">{simState.corridor}</span></div>
          </div>
          <div className="bg-[#06070a] p-3 rounded border border-[#11131c] space-y-1">
            <div className="text-[10px] text-[#8a8d9a] font-bold uppercase">Simulation Outputs</div>
            <div>Vault Access: <span className="text-[#00e676] font-bold">OK</span></div>
            <div>Engine Route: <span className="text-white">Standard</span></div>
            <div>Status: <span className="text-[#3b82f6] font-bold">{simState.status}</span></div>
          </div>
        </div>
      </div>

      {/* MODULE 4 — STRESS TEST & SELF REPAIR ENGINE */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Stress Test */}
        <div className="bg-[#0d0e12] border border-[#1a1d26] p-4 rounded text-xs space-y-3">
          <div className="text-[10px] uppercase text-[#3b82f6] font-bold tracking-widest">System Stress Test Mode</div>
          <div className="flex flex-wrap gap-2">
            {["Burst Test", "Corridor Overload"].map((mode) => (
              <button
                key={mode}
                onClick={() => handleToggleStress(mode)}
                className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase border transition-all ${
                  stressMode === mode
                    ? "bg-[#FA1F4E]/20 text-[#FA1F4E] border-[#FA1F4E]"
                    : "bg-[#06070a] text-[#8a8d9a] border-[#11131c] hover:text-white"
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
          <div className="text-[10px] text-[#8a8d9a]">
            Active Stress Mode: <strong className="text-white uppercase">{stressMode}</strong>
          </div>
        </div>

        {/* Self Repair Engine */}
        <div className="bg-[#0d0e12] border border-[#FA1F4E]/30 p-4 rounded text-xs space-y-3">
          <div className="text-[10px] uppercase text-[#FA1F4E] font-bold tracking-widest flex items-center gap-1.5">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Self-Repair & Fixing Engine</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {["Restart Endpoint", "Flush Cache", "Reset Dependencies"].map((act) => (
              <button
                key={act}
                onClick={() => handleRunRepair(act)}
                disabled={repairState.isRunning}
                className="px-2.5 py-1 bg-[#06070a] hover:bg-[#FA1F4E]/20 border border-[#1a1d26] hover:border-[#FA1F4E] text-white rounded text-[9px] font-bold uppercase transition-all disabled:opacity-50"
              >
                {act}
              </button>
            ))}
          </div>
          <div className="bg-[#06070a] p-2.5 rounded border border-[#11131c] space-y-1 text-[10px] text-[#8a8d9a]">
            <div>Last Action: <span className="text-white font-bold">{repairState.lastAction}</span></div>
            <div>Result: <span className="text-[#00e676] font-bold">{repairState.result}</span></div>
            <div>Tracking ID: <span className="text-[#3b82f6] font-mono">{repairState.correlationId}</span></div>
          </div>
        </div>
      </div>
    </div>
  );
};
