import React, { useState } from "react";
import { useLanguage } from "../../LanguageProvider";
import { 
  Layers, 
  Server, 
  Cpu, 
  ShieldCheck, 
  Zap, 
  Database, 
  Radio, 
  Workflow, 
  Code2, 
  Terminal, 
  Lock, 
  ArrowRight,
  ChevronRight,
  Activity,
  Network
} from "lucide-react";

export const ArchitectureTree: React.FC = () => {
  const { isArabic, t } = useLanguage();
  const [selectedLayer, setSelectedLayer] = useState<"frontend" | "backend" | "flow">("flow");

  const frontendNodes = [
    {
      id: "fe-ui",
      title: "UI / View Layer",
      titleAr: "طبقة الواجهات والتفاعل المرئي",
      tech: "React 18 + TypeScript + Tailwind CSS",
      desc: "Zero-latency reactive views subscribing to immutable stores without direct API calls.",
      descAr: "واجهات تفاعلية نقية ترتبط بالمخازن بدون طلبات مباشرة نحو الخادم.",
      subItems: isArabic 
        ? ["صفحات المنصة (15 وحدة وظيفية)", "استوديو المظهر (محرك الجماليات)", "مركز دعم ثنائي اللغة مع المحاذاة الكاملة"]
        : ["Pages (15 Functional Modules)", "Theme Studio (Aesthetic Engine)", "Bilingual Arabic/English RTL Hub"]
    },
    {
      id: "fe-store",
      title: "State & Decision Stores",
      titleAr: "مخازن الحالة والقرارات المركزية",
      tech: "Central Decision Kernel & Typed Stores",
      desc: "Deterministic in-memory state containers with reactive pub/sub listeners.",
      descAr: "مخازن بيانات محكمة ومحصنة في الذاكرة تدعم التحديث اللحظي للمكونات.",
      subItems: isArabic
        ? ["مخزن الهوية (مصفوفة الـ 4 فئات)", "مخزن المحركات (12 عقدة فائقة السرعة)", "مخزن المخاطر (محددات المخاطرة الصارمة)"]
        : ["identityStore (4-Tier Matrix)", "engineStore (12 High-Speed Nodes)", "riskStore (Risk Clamps)"]
    },
    {
      id: "fe-service",
      title: "Service Orchestration Layer",
      titleAr: "طبقة تنسيق الخدمات ومنطق الأعمال",
      tech: "Modular TypeScript Services",
      desc: "Pure business logic routing, correlation tracking, and WebSocket listener bindings.",
      descAr: "معالجة منطق الأعمال وإدارة معرفات التتبع وتلقي رسائل المقبس الحي.",
      subItems: isArabic
        ? ["خدمة الهوية والمصادقة", "خدمة المحركات والتنفيذ", "خدمة القنوات الاجتماعية", "خدمة الرقابة وإدارة المخاطر"]
        : ["IdentityService", "EngineService", "SocialService", "RiskService"]
    }
  ];

  const backendNodes = [
    {
      id: "be-api",
      title: "API Gateway & Router",
      titleAr: "بوابة وخادم واجهات البرمجة الآمنة",
      tech: "Node.js + Express 5 + TSX",
      desc: "High-throughput endpoints with strict distributed tracing (X-Correlation-ID).",
      descAr: "منافذ سريعة ومحمية تدعم التتبع الشامل لكل طلب بسجل تدقيق مستقل.",
      subItems: isArabic
        ? ["بوابة المصادقة والتشفير", "أوامر تشغيل ومراقبة المحركات", "سجل التوثيق والتدقيق المالي"]
        : ["/api/v1/auth (Ed25519 & SSO)", "/api/v1/engines (Execution Commands)", "/api/v1/audit (Ledger Records)"]
    },
    {
      id: "be-ws",
      title: "WebSocket Telemetry Mesh",
      titleAr: "شبكة بث البيانات اللحظية المشفرة",
      tech: "Single Connection WebSocketManager",
      desc: "Continuous microsecond tick streamer dispatching order book depth & engine heartbeats.",
      descAr: "بث نبضات الأسعار ومستشعرات عمق السوق وحالات المحركات دون تأخير.",
      subItems: isArabic
        ? ["نبضات سجل الأوامر الفورية", "قياس نبض المحركات في أجزاء المللي ثانية", "إشارات قاطع الطوارئ الفوري"]
        : ["Order Book Ticks", "Engine Telemetry Heartbeats", "Instant Emergency Kill-Signals"]
    },
    {
      id: "be-security",
      title: "Cryptographic Vault & Shariah Guard",
      titleAr: "الخزنة المشفرة وحارس الامتثال الشرعي",
      tech: "Hardware Enclave & AAOIFI Audits",
      desc: "Multi-sig signature validation, 0% margin loan enforcement, and 100% Spot physical settlement.",
      descAr: "التحقق التشفيري المتعدد، ومنع قروض الرافعة، وتأكيد التقابض الفوري الحقيقي.",
      subItems: isArabic
        ? ["التحقق من التوقيع الرقمي Ed25519", "إنفاذ معايير أيوفي الشرعية 21 و 59", "سجل تدقيق مشفر بتقنية SHA-256"]
        : ["Ed25519 Token Verifier", "AAOIFI Standard 21/59 Clamps", "SHA-256 Ledger Audit Log"]
    }
  ];

  return (
    <div className="bg-[#08090d] border border-[#1a1d26] rounded-xl p-5 space-y-5 font-mono">
      {/* Topology Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#161822] pb-4">
        <div>
          <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
            <Network className="w-4 h-4 text-cyan-400" />
            {t("SYSTEM TOPOLOGY & ARCHITECTURE TREE")}
          </h4>
          <p className="text-xs text-[#8a8d9a] mt-0.5">
            {t("Strict structural flow: HTML ➔ Component ➔ Store ➔ Service ➔ ApiClient ➔ Backend Core")}
          </p>
        </div>

        <div className="flex items-center gap-1.5 bg-[#0e1017] p-1 rounded-lg border border-[#1a1e2a] text-xs">
          <button
            onClick={() => setSelectedLayer("flow")}
            className={`px-2.5 py-1 rounded font-bold transition-all cursor-pointer ${
              selectedLayer === "flow" ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/40" : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            {t("DATA PIPELINE FLOW")}
          </button>
          <button
            onClick={() => setSelectedLayer("frontend")}
            className={`px-2.5 py-1 rounded font-bold transition-all cursor-pointer ${
              selectedLayer === "frontend" ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/40" : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            {t("FRONT-END ARCHITECTURE")}
          </button>
          <button
            onClick={() => setSelectedLayer("backend")}
            className={`px-2.5 py-1 rounded font-bold transition-all cursor-pointer ${
              selectedLayer === "backend" ? "bg-cyan-500/20 text-cyan-400 border border-cyan-500/40" : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            {t("BACK-END & RUNTIME ENGINE")}
          </button>
        </div>
      </div>

      {/* Architecture Flow Diagram */}
      {selectedLayer === "flow" && (
        <div className="space-y-4">
          <div className="p-4 bg-[#0a0c12] border border-[#161a26] rounded-lg">
            <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest block mb-3">
              {t("STATE FLOW ARCHITECTURE")}
            </span>

            <div className="grid grid-cols-1 md:grid-cols-6 gap-2 text-center text-xs">
              {[
                { title: isArabic ? "واجهة العرض" : "HTML & View", tag: isArabic ? "شجرة العناصر" : "DOM Tree", icon: Code2, color: "text-blue-400" },
                { title: isArabic ? "مكونات ريأكت" : "React Component", tag: isArabic ? "تفاعلي" : "Reactive", icon: Layers, color: "text-cyan-400" },
                { title: isArabic ? "مخزن القرارات" : "Decision Store", tag: isArabic ? "حالة الذاكرة" : "In-Memory State", icon: Database, color: "text-purple-400" },
                { title: isArabic ? "طبقة الخدمات" : "Service Worker", tag: isArabic ? "منطق الأعمال" : "Business Logic", icon: Workflow, color: "text-amber-400" },
                { title: isArabic ? "عميل واجهة الربط" : "ApiClient & WS", tag: isArabic ? "تتبع التزامن" : "Tracing (X-Corr-ID)", icon: Radio, color: "text-emerald-400" },
                { title: isArabic ? "محركات التداول" : "Backend Engines", tag: isArabic ? "شبكة كمية" : "Quant Mesh", icon: Server, color: "text-rose-400" }
              ].map((step, idx) => {
                const Icon = step.icon;
                return (
                  <div key={idx} className="p-3 bg-[#0f121a] border border-[#1c2232] rounded-lg flex flex-col items-center justify-between space-y-2">
                    <div className="w-8 h-8 rounded-lg bg-[#141824] flex items-center justify-center border border-[#222838]">
                      <Icon className={`w-4 h-4 ${step.color}`} />
                    </div>
                    <div>
                      <div className="text-white font-bold text-[11px]">{step.title}</div>
                      <div className="text-[9px] text-[#717684] mt-0.5">{step.tag}</div>
                    </div>
                    <span className="text-[8px] px-1.5 py-0.5 rounded bg-[#161a26] text-[#8a8d9a]">
                      {isArabic ? `الخطوة 0${idx + 1}` : `Step 0${idx + 1}`}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Front-End Tree Breakdown */}
      {selectedLayer === "frontend" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          {frontendNodes.map((node) => (
            <div key={node.id} className="p-4 bg-[#0a0c12] border border-[#161a26] rounded-lg space-y-3">
              <div className="flex items-center justify-between border-b border-[#161a26] pb-2">
                <h5 className="font-bold text-white text-xs">{isArabic ? node.titleAr : node.title}</h5>
                <span className="text-[9px] px-2 py-0.5 rounded bg-cyan-950/60 text-cyan-400 border border-cyan-800/40">
                  {node.tech}
                </span>
              </div>
              <p className="text-[11px] text-[#8a8d9a] leading-relaxed">
                {isArabic ? node.descAr : node.desc}
              </p>
              <div className="space-y-1 pt-1">
                {node.subItems.map((sub, i) => (
                  <div key={i} className="text-[10px] text-white/80 flex items-center gap-1.5">
                    <ChevronRight className="w-3 h-3 text-cyan-400 shrink-0" />
                    <span>{sub}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Back-End Tree Breakdown */}
      {selectedLayer === "backend" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
          {backendNodes.map((node) => (
            <div key={node.id} className="p-4 bg-[#0a0c12] border border-[#161a26] rounded-lg space-y-3">
              <div className="flex items-center justify-between border-b border-[#161a26] pb-2">
                <h5 className="font-bold text-white text-xs">{isArabic ? node.titleAr : node.title}</h5>
                <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-800/40">
                  {node.tech}
                </span>
              </div>
              <p className="text-[11px] text-[#8a8d9a] leading-relaxed">
                {isArabic ? node.descAr : node.desc}
              </p>
              <div className="space-y-1 pt-1">
                {node.subItems.map((sub, i) => (
                  <div key={i} className="text-[10px] text-white/80 flex items-center gap-1.5">
                    <ChevronRight className="w-3 h-3 text-emerald-400 shrink-0" />
                    <span>{sub}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
