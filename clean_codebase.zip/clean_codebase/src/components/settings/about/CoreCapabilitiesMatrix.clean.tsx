import React from "react";
import { useLanguage } from "../../LanguageProvider";
import { 
  Zap, 
  ShieldCheck, 
  Cpu, 
  Layers, 
  Lock, 
  Activity, 
  Globe, 
  Server,
  Sparkles,
  CheckCircle2,
  Sliders
} from "lucide-react";

export const CoreCapabilitiesMatrix: React.FC = () => {
  const { isArabic, t } = useLanguage();

  const specs = [
    {
      icon: Zap,
      color: "text-amber-400",
      bg: "bg-amber-500/10 border-amber-500/30",
      title: "Sub-Millisecond Routing",
      titleAr: "توجيه الأوامر بأجزاء من المللي ثانية",
      stat: "< 0.18ms Co-Located",
      desc: "Ultra-low latency algorithmic execution connecting directly to Tier-1 liquidity engines with zero queuing.",
      descAr: "تنفيذ فائق السرعة عبر مسارات ربط مباشرة بمزودي السيولة العالمية من الدرجة الأولى بدون تأخير."
    },
    {
      icon: ShieldCheck,
      color: "text-emerald-400",
      bg: "bg-emerald-500/10 border-emerald-500/30",
      title: "100% Spot Halal AAOIFI",
      titleAr: "امتثال شرعي فوري ١٠٠٪ (معايير أيوفي)",
      stat: "AAOIFI 21 / 59",
      desc: "Zero overnight swap fees, zero margin loans, and mandatory real physical asset custody verification.",
      descAr: "خلو تام من رسوم التبييت والفوائد وقروض الرافعة المالية، مع إلزامية التقابض الفعلي الحقيقي."
    },
    {
      icon: Sliders,
      color: "text-rose-400",
      bg: "bg-rose-500/10 border-rose-500/30",
      title: "Hardcoded Risk Clamping",
      titleAr: "تثبيت وحماية المخاطر إجبارياً",
      stat: "1.0% Max Loss Clamp",
      desc: "Hardware-level stop-loss enforcement preserving account capital against flash crashes and slippage.",
      descAr: "حماية عتادية لمنع تجاوز الخسارة نسبة ١.٠٪ للصفقة لحفظ رؤوس الأموال من الانزلاقات السعرية."
    },
    {
      icon: Cpu,
      color: "text-cyan-400",
      bg: "bg-cyan-500/10 border-cyan-500/30",
      title: "12 Concurrent Quant Engines",
      titleAr: "١٢ محركاً كمياً متزامناً",
      stat: "12 Active Nodes",
      desc: "Parallel multi-strategy execution across Sirius, Canopus, Vega, Antares, and specialized micro-grid bots.",
      descAr: "تنفيذ متزامن عبر شبكة متكاملة تضم ١٢ محركاً خوارزمياً مستقلاً لتغطية كافة ظروف السوق."
    },
    {
      icon: Lock,
      color: "text-purple-400",
      bg: "bg-purple-500/10 border-purple-500/30",
      title: "Ed25519 & mTLS Security",
      titleAr: "تشفير Ed25519 وشهادات mTLS",
      stat: "Hardware HSM Enclave",
      desc: "Cryptographic token verification, multi-factor authentication, and SHA-256 immutable audit trails.",
      descAr: "مصادقة تشفيرية متقدمة مع دعم العزل العتادي وسجل تدقيق ثابت ببصمات SHA-256 لكل أمر."
    },
    {
      icon: Globe,
      color: "text-blue-400",
      bg: "bg-blue-500/10 border-blue-500/30",
      title: "4-Tier Identity Matrix",
      titleAr: "مصفوفة الهوية والتخصيص الرباعية",
      stat: "Dynamic Provisioning",
      desc: "Seamless role-based resource bounds from micro-capital individual space to institutional desks.",
      descAr: "توزيع وتخصيص ديناميكي للموارد والصلاحيات يمتد من الحساب الفردي حتى المكاتب المؤسسية."
    }
  ];

  return (
    <div className="bg-[#08090d] border border-[#1a1d26] rounded-xl p-5 space-y-4 font-mono">
      <div className="border-b border-[#161822] pb-3">
        <h4 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          {t("CORE CAPABILITIES & INSTITUTIONAL SPECIFICATIONS")}
        </h4>
        <p className="text-xs text-[#8a8d9a] mt-0.5">
          {t("Engineered with military-grade precision, zero client-side financial computation, and strict Islamic finance standards.")}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {specs.map((spec, idx) => {
          const Icon = spec.icon;
          return (
            <div
              key={idx}
              className="p-4 bg-[#0a0c12] border border-[#161a26] rounded-xl hover:border-[#333] transition-all space-y-3 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center border ${spec.bg}`}>
                    <Icon className={`w-4 h-4 ${spec.color}`} />
                  </div>
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-[#141824] text-white border border-[#222838]">
                    {spec.stat}
                  </span>
                </div>

                <h5 className="font-bold text-white text-xs mb-1">
                  {isArabic ? spec.titleAr : spec.title}
                </h5>

                <p className="text-[11px] text-[#8a8d9a] leading-relaxed">
                  {isArabic ? spec.descAr : spec.desc}
                </p>
              </div>

              <div className="pt-2 border-t border-[#141722] flex items-center gap-1.5 text-[9px] text-emerald-400">
                <CheckCircle2 className="w-3 h-3" />
                <span>{t("AUDIT CHAIN SYNCED")}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
