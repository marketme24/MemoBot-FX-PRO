import React, { useState, useEffect } from "react";
import { Cpu, Network, Radio, ShieldCheck, Database, Sliders, LifeBuoy, ArrowRight } from "lucide-react";

interface GeneralSettingsProps {
  showAlert: (msg: string) => void;
}


function usePersistentState<T>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [state, setState] = React.useState<T>(() => {
    const saved = localStorage.getItem(key);
    if (saved !== null) {
      try { return JSON.parse(saved); } catch (e) { return saved as any; }
    }
    return initialValue;
  });
  React.useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);
  return [state, setState];
}

export const GeneralSettings: React.FC<GeneralSettingsProps> = ({ showAlert }) => {
  const [debugMode, setDebugMode] = usePersistentState("memobot_general_debugMode", false);
  const [autoReconnect, setAutoReconnect] = usePersistentState("memobot_general_autoReconnect", true);
  const [apiTimeout, setApiTimeout] = usePersistentState("memobot_general_apiTimeout", "5000");

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* System Configuration (lg:span-7) */}
        <div className="lg:col-span-7 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
          <div className="flex items-center gap-2 border-b border-[#11131c] pb-2 text-[#FA1F4E] font-bold text-[10px] uppercase">
            <Cpu className="w-4 h-4 text-[#FA1F4E]" />
            SYSTEM & TELEMETRY CONFIGURATION
          </div>

          <div className="space-y-4 pt-1">
            <div className="flex items-center justify-between pb-3 border-b border-[#11131c]">
              <div className="space-y-1">
                <span className="text-white font-bold block">PLATFORM VERBOSE TELEMETRY</span>
                <span className="text-[10px] text-[#8a8d9a]">Exposes full WebSocket frames and database logs directly inside browser console.</span>
              </div>
              <button
                onClick={() => {
                  setDebugMode(!debugMode);
                  showAlert(`Platform debugging telemetry ${!debugMode ? "ENABLED" : "DISABLED"}`);
                }}
                className={`px-3 py-1.5 rounded text-[10px] font-bold border transition-all ${
                  debugMode
                    ? "bg-[rgba(0,230,118,0.15)] border-[#00e676] text-[#00e676]"
                    : "bg-transparent border-[#1a1d26] text-[#8a8d9a] hover:border-[#00e5ff]"
                }`}
              >
                {debugMode ? "TELEMETRY: ON" : "TELEMETRY: OFF"}
              </button>
            </div>

            <div className="flex items-center justify-between pb-3 border-b border-[#11131c]">
              <div className="space-y-1">
                <span className="text-white font-bold block">WEBSOCKET AUTO-RECONNECT</span>
                <span className="text-[10px] text-[#8a8d9a]">Automatically re-establishes HFT socket stream upon connection drop.</span>
              </div>
              <button
                onClick={() => {
                  setAutoReconnect(!autoReconnect);
                  showAlert(`Auto-reconnect ${!autoReconnect ? "ENABLED" : "DISABLED"}`);
                }}
                className={`px-3 py-1.5 rounded text-[10px] font-bold border transition-all ${
                  autoReconnect
                    ? "bg-[rgba(0,230,118,0.15)] border-[#00e676] text-[#00e676]"
                    : "bg-transparent border-[#1a1d26] text-[#8a8d9a] hover:border-[#00e5ff]"
                }`}
              >
                {autoReconnect ? "AUTO: ACTIVE" : "AUTO: PAUSED"}
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <span className="text-white font-bold block">REST API TIMEOUT (MS)</span>
                <span className="text-[10px] text-[#8a8d9a]">Maximum execution time allowed before aborting async requests.</span>
              </div>
              <select
                value={apiTimeout}
                onChange={(e) => {
                  setApiTimeout(e.target.value);
                  showAlert(`API Timeout updated to ${e.target.value}ms`);
                }}
                className="bg-[#06070a] border border-[#1a1d26] text-white px-3 py-1 rounded text-[10px] font-bold outline-none"
              >
                <option value="3000">3000 ms (Strict)</option>
                <option value="5000">5000 ms (Standard)</option>
                <option value="10000">10000 ms (Extended)</option>
              </select>
            </div>
          </div>
        </div>

        {/* System Host Environment Details (lg:span-5) */}
        <div className="lg:col-span-5 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
          <div className="flex items-center gap-2 text-[#FA1F4E] font-bold border-b border-[#11131c] pb-2 uppercase text-[10px]">
            <Network className="w-4 h-4 text-[#FA1F4E]" />
            HOST ENVIRONMENT DETAILS
          </div>

          <div className="space-y-3 leading-relaxed text-[10px]">
            <div className="flex justify-between border-b border-[#11131c] pb-1.5">
              <span>SYSTEM VERSION:</span>
              <span className="text-white font-bold">MEMOBOT™ FX-PRO v1.4.0</span>
            </div>
            <div className="flex justify-between border-b border-[#11131c] pb-1.5">
              <span>LEDGER COMPLIANCE:</span>
              <span className="text-[#00e676] font-bold">HALAL ACTIVE</span>
            </div>
            <div className="flex justify-between border-b border-[#11131c] pb-1.5">
              <span>VIRTUALIZATION ENGINE:</span>
              <span className="text-white">Docker / Google Cloud Run</span>
            </div>
            <div className="flex justify-between border-b border-[#11131c] pb-1.5">
              <span>API PROXY PORT:</span>
              <span className="text-[#00e5ff] font-bold">3000 (INBOUND ACTIVE)</span>
            </div>
            <div className="flex justify-between border-b border-[#11131c] pb-1.5">
              <span>SECURITY VAULT LAYER:</span>
              <span className="text-[#00e5ff] font-bold">FREEDOM MATRIX™</span>
            </div>
            <div className="flex justify-between">
              <span>SERVER TIMEZONE:</span>
              <span className="text-white font-bold">UTC / GMT+0</span>
            </div>
          </div>
        </div>

        {/* System Operations & Support Desk Reference Block */}
        <div className="lg:col-span-12 bg-[#0a0d14]/60 border border-[#1a1d26] p-4 rounded-lg space-y-3 font-mono">
          <div className="flex items-center gap-2 border-b border-[#12141c] pb-2 text-[#00e676]">
            <LifeBuoy className="w-4 h-4 animate-pulse" />
            <span className="text-[10px] font-extrabold uppercase tracking-wider">
              MEMOBOT GLOBAL OPERATIONS SERVICE DESK
            </span>
          </div>
          <div className="text-[#8a8d9a] text-[10.5px] leading-relaxed space-y-2">
            <p>
              Our complete multi-tier professional support desk has been consolidated into the primary <span className="text-white font-bold">MEMOBOT AI</span> workspace.
            </p>
            <p>
              Navigate to the <span className="text-[#00e676] font-bold">OPERATIONS SUPPORT DESK</span> tab on the AI chat page to chat with platform-trained AI diagnosticians, run system trace telemetry checks, and dispatch incident tickets to our operations CRM pipeline.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
