import React, { useState } from "react";
import { Palette, Type, Layout, Check, ArrowUp, ArrowDown, RotateCcw, Sliders, MousePointerClick } from "lucide-react";
import { useTheme, FONT_MAP, COLOR_OPTIONS } from "../ThemeProvider";

interface ThemeStudioSettingsProps {
  showAlert: (msg: string) => void;
}

export const ThemeStudioSettings: React.FC<ThemeStudioSettingsProps> = ({ showAlert }) => {
  const {
    accentColor,
    setAccentColor,
    selectedFont,
    setSelectedFont,
    fontWeight,
    setFontWeight,
    fontStyle,
    setFontStyle,
    letterSpacing,
    setLetterSpacing,
    textTransform,
    setTextTransform,
    brandRedTitle,
    setBrandRedTitle,
    brandWhiteTitle,
    setBrandWhiteTitle,
    brandSubtitle,
    setBrandSubtitle,
    sidebarSections,
    moveSectionUp,
    moveSectionDown,
    moveItemUp,
    moveItemDown,
    renameSection,
    renameItem,
    resetSidebarToDefault,
    inspectorActive,
    setInspectorActive,
  } = useTheme();

  const [customHex, setCustomHex] = useState("");
  const [fontFilter, setFontFilter] = useState("");
  const [customFontInput, setCustomFontInput] = useState("");

  const fontList = Object.entries(FONT_MAP).map(([id, val]) => ({
    id,
    label: val.label,
    family: val.family,
    fontStr: val.font,
  }));

  const filteredFontList = fontList.filter(
    (f) =>
      f.label.toLowerCase().includes(fontFilter.toLowerCase()) ||
      f.family.toLowerCase().includes(fontFilter.toLowerCase()) ||
      f.id.toLowerCase().includes(fontFilter.toLowerCase())
  );

  const handleCustomFontSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (customFontInput.trim()) {
      const fontName = customFontInput.trim();
      setSelectedFont(fontName);
      showAlert(`Applied custom Google Font: "${fontName}" across entire platform`);
      setCustomFontInput("");
    }
  };

  const handleCustomHexSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (/^#([0-9A-F]{3}){1,2}$/i.test(customHex)) {
      setAccentColor(customHex);
      showAlert(`Accent color set to custom hex ${customHex}`);
      setCustomHex("");
    } else {
      showAlert("Invalid HEX code format. Use format #RRGGBB");
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Dynamic Header Preview Box */}
      <div 
        style={{ borderColor: `${accentColor}50`, boxShadow: `0 0 25px ${accentColor}15` }}
        className="bg-[#0b0d12] border p-5 rounded-lg text-center space-y-2 transition-all"
      >
        <h3 className="text-2xl font-aquire text-white tracking-widest flex items-center justify-center gap-2">
          <span style={{ color: accentColor }}>{brandRedTitle}</span> | {brandWhiteTitle}
        </h3>
        <p style={{ color: accentColor }} className="text-[11px] font-bold tracking-wider uppercase">
          ---- WE NOT JUST GIVE SIGNALS!!! WE "PROTECT YOUR CAPITAL FIRST" ----
        </p>
        <p className="text-[10px] text-[#8a8d9a] max-w-xl mx-auto italic">
          {brandSubtitle}
        </p>
      </div>

      <div style={{ color: accentColor }} className="flex items-center gap-2 font-bold uppercase text-sm tracking-wider">
        <Palette className="w-5 h-5" />
        THEME STUDIO — CONFIGURE LAYOUT, AESTHETICS & SIDEBAR ARCHITECTURE
      </div>

      {/* Platform Interactive Visual DOM Inspector Pointer Tool */}
      <div 
        style={{ borderColor: `${accentColor}40`, boxShadow: inspectorActive ? `0 0 25px ${accentColor}15` : "" }}
        className="inspector-exclude bg-[#0d0e12] border border-[#1a1d26] p-5 rounded-lg flex flex-col md:flex-row items-center gap-5 transition-all"
      >
        {/* Left: Custom developer pointer icon container matching user's image */}
        <div className="relative flex-shrink-0">
          <div 
            style={{ borderColor: inspectorActive ? accentColor : "#8a8d9a40" }}
            className={`relative w-16 h-16 border-2 border-dashed rounded-lg bg-[#ffffff02] flex items-center justify-center transition-all ${inspectorActive ? "animate-pulse" : ""}`}
          >
            {/* Corner dots mimicking exact devtools selector pointer box */}
            <div className="absolute -top-1 -left-1 w-2.5 h-2.5 bg-black border border-white/40 rounded-sm" />
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-black border border-white/40 rounded-sm" />
            <div className="absolute -bottom-1 -left-1 w-2.5 h-2.5 bg-black border border-white/40 rounded-sm" />
            <div className="absolute -bottom-1 -right-1 w-2.5 h-2.5 bg-black border border-white/40 rounded-sm" />
            
            <MousePointerClick 
              style={{ color: inspectorActive ? accentColor : "#8a8d9a" }} 
              className={`w-8 h-8 transition-transform ${inspectorActive ? "scale-110" : "scale-100 hover:scale-105"}`} 
            />
          </div>
          {inspectorActive && (
            <span className="absolute -top-1.5 -right-1.5 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ backgroundColor: accentColor }}></span>
              <span className="relative inline-flex rounded-full h-3 w-3" style={{ backgroundColor: accentColor }}></span>
            </span>
          )}
        </div>

        {/* Center: Instruction and Telemetry Info */}
        <div className="flex-1 space-y-1.5 text-center md:text-left">
          <h4 className="text-sm font-extrabold text-white uppercase tracking-wider flex items-center justify-center md:justify-start gap-2 font-aquire">
            <span style={{ color: accentColor }}>LIVE ELEMENT INSPECTOR</span>
            <span className="text-[9px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-1.5 py-0.2 rounded font-mono font-black">
              DESIGN INSTRUMENT
            </span>
          </h4>
          <p className="text-[11px] text-[#8a8d9a] leading-relaxed max-w-2xl font-sans">
            Activate the high-fidelity platform visual editor. Once triggered, hover any part of the application (excluding the sidebar) to instantly highlight it. Click any header, text block, or card frame to live-edit text, apply custom theme colors, select nested parent nodes, or prune unwanted layout frames on-the-fly!
          </p>
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-x-4 gap-y-1 text-[9px] text-[#555] font-bold">
            <span>✓ ZERO SERVER DEPLOY REQUIRED</span>
            <span>&bull;</span>
            <span>✓ APPLIES COMPANION THEME PRESETS</span>
            <span>&bull;</span>
            <span>✓ DOM COMPONENT MODIFIER INSTANT-PREVIEW</span>
          </div>
        </div>

        {/* Right: Toggle Button */}
        <div className="shrink-0 w-full md:w-auto">
          <button
            onClick={() => {
              setInspectorActive(!inspectorActive);
              showAlert(
                inspectorActive 
                  ? "Visual DOM Inspector deactivated." 
                  : "Visual DOM Inspector active! Hover any spot on the page (except sidebar) and click to modify or delete elements live."
              );
            }}
            style={{ 
              backgroundColor: inspectorActive ? "transparent" : accentColor,
              borderColor: accentColor,
              color: inspectorActive ? "#ffffff" : "#000000"
            }}
            className={`w-full md:w-56 py-3 px-4 rounded-md border text-[11px] font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 hover:brightness-110 active:scale-[0.98] ${
              inspectorActive 
                ? "bg-transparent text-white shadow-[0_0_15px_rgba(var(--color-primary-rgb),0.2)]" 
                : "text-black font-black"
            }`}
          >
            <MousePointerClick className="w-4 h-4" style={{ color: inspectorActive ? "#ffffff" : "#000000" }} />
            <span>{inspectorActive ? "Deactivate Inspector" : "Activate Pointer Tool"}</span>
          </button>
        </div>
      </div>

      {/* Row 1: Typography & Accent Colors */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Fonts & Palette */}
        <div className="lg:col-span-7 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded-lg space-y-5">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-[#11131c] pb-2">
            <span className="text-[11px] text-white font-bold uppercase flex items-center gap-2">
              <Type className="w-4 h-4" style={{ color: accentColor }} />
              GLOBAL TYPOGRAPHY & COLOR ACCENTS
            </span>
            <span className="text-[9px] text-[#8a8d9a]">FONT FAMILY (`/public/fonts/aquire.otf`)</span>
          </div>

          {/* Font Search & Custom Google Font Input */}
          <div className="space-y-2">
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={fontFilter}
                onChange={(e) => setFontFilter(e.target.value)}
                placeholder="🔍 Search 30+ font presets..."
                className="flex-1 bg-[#06070a] border border-[#1a1d26] focus:border-primary text-white text-[10px] p-2 rounded outline-none"
              />
              <form onSubmit={handleCustomFontSubmit} className="flex gap-1.5 flex-1">
                <input
                  type="text"
                  value={customFontInput}
                  onChange={(e) => setCustomFontInput(e.target.value)}
                  placeholder="Type ANY Google Font (e.g. Montserrat)..."
                  className="flex-1 bg-[#06070a] border border-[#1a1d26] focus:border-primary text-white text-[10px] p-2 rounded outline-none"
                />
                <button
                  type="submit"
                  style={{ backgroundColor: accentColor }}
                  className="px-3 py-1.5 text-white text-[9px] font-bold uppercase rounded hover:opacity-90 transition-opacity shrink-0"
                >
                  Apply
                </button>
              </form>
            </div>
            {selectedFont && !FONT_MAP[selectedFont] && (
              <div style={{ color: accentColor }} className="text-[10px] font-bold flex items-center gap-1.5">
                <span>✓ ACTIVE CUSTOM FONT:</span>
                <span className="underline font-mono">{selectedFont}</span>
              </div>
            )}
          </div>

          {/* Font Selector Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 max-h-64 overflow-y-auto pr-1">
            {filteredFontList.map((f) => {
              const isActive = selectedFont === f.id;
              return (
                <button
                  key={f.id}
                  onClick={() => {
                    setSelectedFont(f.id);
                    showAlert(`Font family updated to ${f.label}`);
                  }}
                  style={
                    isActive
                      ? {
                          borderColor: accentColor,
                          backgroundColor: `${accentColor}25`,
                          boxShadow: `0 0 12px ${accentColor}35`,
                          color: "#ffffff",
                          fontFamily: f.fontStr,
                        }
                      : { fontFamily: f.fontStr }
                  }
                  className={`p-2 rounded border text-center transition-all flex flex-col items-center justify-center gap-0.5 ${
                    isActive
                      ? "text-white font-bold"
                      : "bg-[#06070a] border-[#1a1d26] text-[#8a8d9a] hover:border-[#333]"
                  }`}
                >
                  <span className="text-xs font-bold">Aa</span>
                  <span className="text-[8px] tracking-wider uppercase truncate w-full">{f.label}</span>
                </button>
              );
            })}
          </div>

          {/* 4 Font Formatting/Editing Options */}
          <div className="pt-3 border-t border-[#11131c] space-y-3">
            <div className="flex items-center gap-1.5 text-[10px] text-white font-bold uppercase">
              <Sliders className="w-3.5 h-3.5" style={{ color: accentColor }} />
              4 FONT EDITING & FORMATTING OPTIONS
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {/* Option 1: Weight */}
              <div className="space-y-1">
                <label className="text-[8px] text-[#8a8d9a] uppercase font-bold">1. Font Weight</label>
                <select
                  value={fontWeight}
                  onChange={(e) => {
                    setFontWeight(e.target.value);
                    showAlert(`Font Weight updated to ${e.target.value}`);
                  }}
                  className="w-full bg-[#06070a] border border-[#1a1d26] text-white text-[10px] p-1.5 rounded outline-none"
                >
                  <option value="300">Light (300)</option>
                  <option value="400">Regular (400)</option>
                  <option value="600">Semi-Bold (600)</option>
                  <option value="700">Bold (700)</option>
                  <option value="900">Black (900)</option>
                </select>
              </div>

              {/* Option 2: Style */}
              <div className="space-y-1">
                <label className="text-[8px] text-[#8a8d9a] uppercase font-bold">2. Font Style</label>
                <select
                  value={fontStyle}
                  onChange={(e) => {
                    setFontStyle(e.target.value);
                    showAlert(`Font Style updated to ${e.target.value}`);
                  }}
                  className="w-full bg-[#06070a] border border-[#1a1d26] text-white text-[10px] p-1.5 rounded outline-none"
                >
                  <option value="normal">Normal</option>
                  <option value="italic">Italic</option>
                </select>
              </div>

              {/* Option 3: Letter Spacing */}
              <div className="space-y-1">
                <label className="text-[8px] text-[#8a8d9a] uppercase font-bold">3. Letter Spacing</label>
                <select
                  value={letterSpacing}
                  onChange={(e) => {
                    setLetterSpacing(e.target.value);
                    showAlert(`Letter Spacing updated to ${e.target.value}`);
                  }}
                  className="w-full bg-[#06070a] border border-[#1a1d26] text-white text-[10px] p-1.5 rounded outline-none"
                >
                  <option value="0.02em">Tight (0.02em)</option>
                  <option value="0.05em">Normal (0.05em)</option>
                  <option value="0.1em">Wide (0.1em)</option>
                  <option value="0.2em">Ultra-Wide (0.2em)</option>
                </select>
              </div>

              {/* Option 4: Text Transform */}
              <div className="space-y-1">
                <label className="text-[8px] text-[#8a8d9a] uppercase font-bold">4. Text Case</label>
                <select
                  value={textTransform}
                  onChange={(e) => {
                    setTextTransform(e.target.value);
                    showAlert(`Text Transform updated to ${e.target.value}`);
                  }}
                  className="w-full bg-[#06070a] border border-[#1a1d26] text-white text-[10px] p-1.5 rounded outline-none"
                >
                  <option value="uppercase">UPPERCASE</option>
                  <option value="capitalize">Capitalize</option>
                  <option value="none">Normal Case</option>
                </select>
              </div>
            </div>
          </div>

          {/* Accent Color Selection */}
          <div className="pt-3 border-t border-[#11131c]">
            <span className="text-[9px] text-[#8a8d9a] block mb-2 uppercase font-bold">PRIMARY ACCENT COLOR (CHANGES ENTIRE THEME)</span>
            <div className="flex flex-wrap items-center gap-3">
              {COLOR_OPTIONS.map((c) => {
                const isSelected = accentColor === c.id;
                return (
                  <button
                    key={c.id}
                    onClick={() => {
                      setAccentColor(c.id);
                      showAlert(`Accent color updated to ${c.name}`);
                    }}
                    className={`w-8 h-8 rounded-full transition-transform flex items-center justify-center relative ${
                      isSelected ? "scale-110 ring-2 ring-white shadow-[0_0_15px_rgba(255,255,255,0.7)]" : "opacity-80 hover:opacity-100 hover:scale-105"
                    }`}
                    style={{ backgroundColor: c.id }}
                    title={c.name}
                  >
                    {isSelected && <Check className="w-4 h-4 text-black font-black" />}
                  </button>
                );
              })}

              {/* Custom Hex Code Entry */}
              <form onSubmit={handleCustomHexSubmit} className="flex items-center gap-1.5 ml-auto">
                <input
                  type="text"
                  placeholder="#00FFCC"
                  value={customHex}
                  onChange={(e) => setCustomHex(e.target.value)}
                  className="w-20 bg-[#06070a] border border-[#1a1d26] text-white p-1.5 rounded text-[10px] outline-none font-mono"
                />
                <button
                  type="submit"
                  style={{ backgroundColor: accentColor }}
                  className="px-2.5 py-1.5 rounded text-[9px] font-bold text-black uppercase hover:brightness-110"
                >
                  SET HEX
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Right Column: Brand Titles */}
        <div className="lg:col-span-5 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-[#11131c] pb-2">
            <span className="text-[11px] text-white font-bold uppercase flex items-center gap-2">
              <Layout className="w-4 h-4" style={{ color: accentColor }} />
              BRAND TITLES & SUBTITLES
            </span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[9px] text-[#8a8d9a] block mb-1 uppercase font-bold">BRAND HIGHLIGHT TITLE (ACCENT COLOR)</label>
              <input
                type="text"
                value={brandRedTitle ?? ""}
                onChange={(e) => setBrandRedTitle(e.target.value)}
                className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2 rounded text-xs outline-none focus:border-white transition-colors"
              />
            </div>

            <div>
              <label className="text-[9px] text-[#8a8d9a] block mb-1 uppercase font-bold">BRAND SECONDARY TITLE</label>
              <input
                type="text"
                value={brandWhiteTitle ?? ""}
                onChange={(e) => setBrandWhiteTitle(e.target.value)}
                className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2 rounded text-xs outline-none focus:border-white transition-colors"
              />
            </div>

            <div>
              <label className="text-[9px] text-[#8a8d9a] block mb-1 uppercase font-bold">BRAND SUBTITLE / TAGLINE</label>
              <input
                type="text"
                value={brandSubtitle ?? ""}
                onChange={(e) => setBrandSubtitle(e.target.value)}
                className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2 rounded text-xs outline-none focus:border-white transition-colors"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Row 2: SIDEBAR ARCHITECTURE — Reorder Navigators & Rename Pages/Panels */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded-lg space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-[#11131c] pb-3 gap-2">
          <div>
            <h4 className="text-sm font-bold text-white uppercase flex items-center gap-2">
              <Layout className="w-4 h-4" style={{ color: accentColor }} />
              SIDEBAR ARCHITECTURE — MOVE NAVIGATORS & RENAME PANELS
            </h4>
            <p className="text-[10px] text-[#8a8d9a] mt-0.5">
              Reorder navigation sections and individual page items using Up/Down controls, or edit any panel title.
            </p>
          </div>

          <button
            onClick={() => {
              resetSidebarToDefault();
              showAlert("Sidebar architecture restored to default layout!");
            }}
            className="px-3 py-1.5 bg-[#161822] hover:bg-[#222536] border border-[#2a2d3e] text-white rounded text-[9px] font-bold uppercase flex items-center gap-1.5 transition-all self-start sm:self-auto"
          >
            <RotateCcw className="w-3 h-3 text-amber-400" />
            RESET TO DEFAULT
          </button>
        </div>

        {/* Render Editable Sidebar Sections & Items */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {sidebarSections.map((sec, secIdx) => (
            <div 
              key={sec.id || secIdx} 
              style={{ borderColor: `${accentColor}30` }}
              className="bg-[#06070a] border rounded-lg p-4 space-y-3 relative"
            >
              {/* Section Header with Up/Down & Title Edit */}
              <div className="flex items-center justify-between gap-2 border-b border-[#181a24] pb-2">
                <div className="flex items-center gap-1.5 flex-1">
                  <span className="text-[9px] font-mono text-[#8a8d9a] font-bold">SEC {secIdx + 1}</span>
                  <input
                    type="text"
                    value={sec.title}
                    onChange={(e) => renameSection(secIdx, e.target.value)}
                    style={{ color: accentColor }}
                    className="bg-transparent text-xs font-bold uppercase outline-none focus:bg-[#0d0e12] focus:px-2 p-1 rounded transition-all flex-1"
                  />
                </div>

                <div className="flex items-center gap-1">
                  <button
                    disabled={secIdx === 0}
                    onClick={() => moveSectionUp(secIdx)}
                    className="p-1 rounded bg-[#11131c] hover:bg-[#1a1d2b] disabled:opacity-30 disabled:hover:bg-[#11131c] text-white"
                    title="Move Section Up"
                  >
                    <ArrowUp className="w-3 h-3" />
                  </button>
                  <button
                    disabled={secIdx === sidebarSections.length - 1}
                    onClick={() => moveSectionDown(secIdx)}
                    className="p-1 rounded bg-[#11131c] hover:bg-[#1a1d2b] disabled:opacity-30 disabled:hover:bg-[#11131c] text-white"
                    title="Move Section Down"
                  >
                    <ArrowDown className="w-3 h-3" />
                  </button>
                </div>
              </div>

              {/* Items List inside Section */}
              <div className="space-y-2 pt-1">
                {sec.items.map((item, itemIdx) => (
                  <div 
                    key={item.id} 
                    className="flex items-center justify-between gap-2 p-2 bg-[#0d0e12] border border-[#161924] rounded group hover:border-[#2a2d3e] transition-all"
                  >
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <span className="text-[8px] font-mono text-[#555] font-bold">#{itemIdx + 1}</span>
                      <input
                        type="text"
                        value={item.label}
                        onChange={(e) => renameItem(secIdx, itemIdx, e.target.value)}
                        className="bg-transparent text-[11px] font-mono font-bold text-white outline-none focus:bg-[#06070a] focus:px-2 p-1 rounded flex-1 min-w-0 border border-transparent focus:border-[#333]"
                      />
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        disabled={itemIdx === 0}
                        onClick={() => moveItemUp(secIdx, itemIdx)}
                        className="p-1 rounded bg-[#06070a] hover:bg-[#181a24] disabled:opacity-30 text-[#8a8d9a] hover:text-white"
                        title="Move Navigator Up"
                      >
                        <ArrowUp className="w-3 h-3" />
                      </button>
                      <button
                        disabled={itemIdx === sec.items.length - 1}
                        onClick={() => moveItemDown(secIdx, itemIdx)}
                        className="p-1 rounded bg-[#06070a] hover:bg-[#181a24] disabled:opacity-30 text-[#8a8d9a] hover:text-white"
                        title="Move Navigator Down"
                      >
                        <ArrowDown className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
