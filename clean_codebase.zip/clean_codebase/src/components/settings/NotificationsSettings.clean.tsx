import React, { useState, useEffect } from "react";
import { ApiClient } from "../../services/api";
import { Bell, MessageSquare, Mail, Volume2, ShieldAlert, Send, CheckCircle2, Zap, Smartphone, Globe } from "lucide-react";

interface NotificationsSettingsProps {
  showAlert: (msg: string) => void;
}


function usePersistentState<T>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [state, setState] = React.useState<T>(() => {
    const saved = localStorage.getItem(key);
    if (saved !== null) {
      try { return JSON.parse(saved); } catch (e) { return saved as any; }
    }
    return initialValue;
  });
  React.useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);
  return [state, setState];
}

export const NotificationsSettings: React.FC<NotificationsSettingsProps> = ({ showAlert }) => {
// Telegram Bot Settings
  const [telegramEnabled, setTelegramEnabled] = usePersistentState("memobot_notif_telegramEnabled", true);
  const [telegramToken, setTelegramToken] = usePersistentState("memobot_notif_telegramToken", "7182938401:AAHx_MemobotFxProSecretBotKey");
  const [telegramChatId, setTelegramChatId] = usePersistentState("memobot_notif_telegramChatId", "981726354");
  const [telegramAlertTrades, setTelegramAlertTrades] = usePersistentState("memobot_notif_telegramAlertTrades", true);
  const [telegramAlertDrawdown, setTelegramAlertDrawdown] = usePersistentState("memobot_notif_telegramAlertDrawdown", true);
  const [telegramAlertDailyPnL, setTelegramAlertDailyPnL] = usePersistentState("memobot_notif_telegramAlertDailyPnL", true);
  const [telegramAlertErrors, setTelegramAlertErrors] = usePersistentState("memobot_notif_telegramAlertErrors", true);

  // Email Notification Settings
  const [emailEnabled, setEmailEnabled] = usePersistentState("memobot_notif_emailEnabled", true);
  const [recipientEmail, setRecipientEmail] = usePersistentState("memobot_notif_recipientEmail", "maher@memobot-fxpro.com");
  const [dailyBriefingSchedule, setDailyBriefingSchedule] = usePersistentState("memobot_notif_dailyBriefingSchedule", "08:00 UTC (Market Open)");
  const [emailAlertTrades, setEmailAlertTrades] = usePersistentState("memobot_notif_emailAlertTrades", false);
  const [emailAlertDrawdown, setEmailAlertDrawdown] = usePersistentState("memobot_notif_emailAlertDrawdown", true);
  const [emailAlertDailyPnL, setEmailAlertDailyPnL] = usePersistentState("memobot_notif_emailAlertDailyPnL", true);

  // Webhooks (Slack/Discord/Custom)
  const [webhookUrl, setWebhookUrl] = usePersistentState("memobot_notif_webhookUrl", "https://discord.com/api/webhooks/12938401/memobot-hft-alerts");
  const [webhookEnabled, setWebhookEnabled] = usePersistentState("memobot_notif_webhookEnabled", false);

  // Audio & In-App Banners
  const [soundAlerts, setSoundAlerts] = usePersistentState("memobot_notif_soundAlerts", true);
  const [desktopPush, setDesktopPush] = usePersistentState("memobot_notif_desktopPush", true);

  // Trigger Conditions
  const [alertOnOrderExecution, setAlertOnOrderExecution] = usePersistentState("memobot_notif_alertOnOrderExecution", true);
  const [alertOnDrawdown, setAlertOnDrawdown] = usePersistentState("memobot_notif_alertOnDrawdown", true);
  const [drawdownThresholdPercent, setDrawdownThresholdPercent] = usePersistentState("memobot_notif_drawdownThresholdPercent", "1.5");
  const [alertOnHalalViolation, setAlertOnHalalViolation] = usePersistentState("memobot_notif_alertOnHalalViolation", true);
  const [alertOnLatencySpike, setAlertOnLatencySpike] = usePersistentState("memobot_notif_alertOnLatencySpike", true);

  const handleTestTelegram = async () => {
    try {
      await ApiClient.post("/notifications/test", { type: "TELEGRAM", token: telegramToken, chatId: telegramChatId });
      showAlert("⚡ Test alert dispatched to Telegram Bot (@MemobotFxPro_Bot). Check your mobile app!");
    } catch (err) {
      showAlert("Failed to test Telegram: " + (err.message || err));
    }
  };

  const handleTestEmail = async () => {
    try {
      await ApiClient.post("/notifications/test", { type: "EMAIL", email: recipientEmail });
      showAlert(`📧 Sample Executive Briefing dispatch triggered to ${recipientEmail}.`);
    } catch (err) {
      showAlert("Failed to test Email: " + (err.message || err));
    }
  };

  const handleTestWebhook = async () => {
    try {
      await ApiClient.post("/notifications/test", { type: "WEBHOOK", url: webhookUrl });
      showAlert("🔗 Webhook test payload sent successfully (HTTP 200 OK).");
    } catch (err) {
      showAlert("Failed to test Webhook: " + (err.message || err));
    }
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Header Banner */}
      <div className="bg-[#0d0e12] border border-[#3b82f6]/30 p-4 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-[0_0_20px_rgba(59,130,246,0.1)]">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#3b82f6]/15 border border-[#3b82f6]/50 rounded-lg text-[#3b82f6] shrink-0">
            <Bell className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-white font-extrabold uppercase tracking-widest text-sm">
                REAL-TIME NOTIFICATION & TELEMETRY ALERT ENGINE
              </span>
              <span className="px-2 py-0.5 bg-[#00e676]/20 border border-[#00e676]/60 text-[#00e676] text-[8.5px] font-extrabold rounded uppercase">
                ALL SYSTEMS ACTIVE
              </span>
            </div>
            <p className="text-[10px] text-[#8a8d9a] mt-0.5">
              Instant multi-channel alerts for trade executions, drawdown capital protection, and daily financial briefings.
            </p>
          </div>
        </div>

                <button
          onClick={() => showAlert("Notification configuration saved to engine runtime state.")}
          className="px-4 py-2 bg-[#3b82f6] text-white hover:bg-[#2563eb] font-extrabold rounded text-[10px] uppercase transition-all shadow-[0_0_15px_rgba(59,130,246,0.3)] self-end sm:self-center"
        >
          SAVE NOTIFICATION PREFERENCES
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Channels & Integration (lg:span-7) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Telegram Bot Channel */}
          <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-5">
            <div className="flex items-center justify-between border-b border-[#11131c] pb-3">
              <div className="flex items-center gap-2 text-[#3b82f6] font-bold text-[11px] uppercase">
                <Smartphone className="w-5 h-5 text-[#3b82f6]" />
                TELEGRAM BOT INTERFACE & TELEMETRY
              </div>
              <button
                onClick={() => {
                  setTelegramEnabled(!telegramEnabled);
                  showAlert(`Telegram notifications ${!telegramEnabled ? "ENABLED" : "DISABLED"}`);
                }}
                className={`px-3 py-1.5 rounded text-[10px] font-bold border transition-all ${
                  telegramEnabled
                    ? "bg-[#00e676]/20 border-[#00e676] text-[#00e676] shadow-[0_0_10px_rgba(0,230,118,0.2)]"
                    : "bg-transparent border-[#1a1d26] text-[#8a8d9a]"
                }`}
              >
                {telegramEnabled ? "TELEGRAM: ONLINE" : "TELEGRAM: OFF"}
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-[#8a8d9a] font-bold block mb-1.5 uppercase">BOT API TOKEN:</label>
                  <input
                    type="text"
                    value={telegramToken ?? ""}
                    onChange={(e) => setTelegramToken(e.target.value)}
                    className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2.5 rounded text-xs outline-none focus:border-[#3b82f6] transition-colors"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#8a8d9a] font-bold block mb-1.5 uppercase">CHAT / CHANNEL ID:</label>
                  <input
                    type="text"
                    value={telegramChatId ?? ""}
                    onChange={(e) => setTelegramChatId(e.target.value)}
                    className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2.5 rounded text-xs outline-none focus:border-[#3b82f6] transition-colors"
                  />
                </div>
              </div>

              {/* Notification Preferences */}
              <div className="pt-2">
                <label className="text-[10px] text-[#8a8d9a] font-bold block mb-2 uppercase border-b border-[#11131c] pb-1">TELEGRAM NOTIFICATION PREFERENCES:</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                  <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded hover:border-[#3b82f6]/50 transition-colors">
                    <div>
                      <span className="text-white font-bold block text-[10px]">Trade Executions</span>
                      <span className="text-[9px] text-[#8a8d9a]">Buy/Sell instant alerts</span>
                    </div>
                    <input type="checkbox" checked={telegramAlertTrades} onChange={(e) => setTelegramAlertTrades(e.target.checked)} className="w-4 h-4 accent-[#3b82f6] cursor-pointer" />
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded hover:border-[#FA1F4E]/50 transition-colors">
                    <div>
                      <span className="text-white font-bold block text-[10px]">Capital Drawdown</span>
                      <span className="text-[9px] text-[#8a8d9a]">Risk & equity threshold alerts</span>
                    </div>
                    <input type="checkbox" checked={telegramAlertDrawdown} onChange={(e) => setTelegramAlertDrawdown(e.target.checked)} className="w-4 h-4 accent-[#FA1F4E] cursor-pointer" />
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded hover:border-[#00e676]/50 transition-colors">
                    <div>
                      <span className="text-white font-bold block text-[10px]">Daily PnL Summary</span>
                      <span className="text-[9px] text-[#8a8d9a]">End-of-day reports</span>
                    </div>
                    <input type="checkbox" checked={telegramAlertDailyPnL} onChange={(e) => setTelegramAlertDailyPnL(e.target.checked)} className="w-4 h-4 accent-[#00e676] cursor-pointer" />
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded hover:border-[#eab308]/50 transition-colors">
                    <div>
                      <span className="text-white font-bold block text-[10px]">System Warnings</span>
                      <span className="text-[9px] text-[#8a8d9a]">Errors & compliance flags</span>
                    </div>
                    <input type="checkbox" checked={telegramAlertErrors} onChange={(e) => setTelegramAlertErrors(e.target.checked)} className="w-4 h-4 accent-[#eab308] cursor-pointer" />
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#11131c]">
                <label className="text-[10px] text-[#00e676] font-bold block mb-2 uppercase flex items-center gap-2">
                  <Smartphone className="w-3.5 h-3.5" />
                  TELEGRAM MINI APP INVITATIONS
                </label>
                <div className="text-[9px] text-[#8a8d9a] mb-3">
                  Send direct messages from the MemoBot Telegram account to local contacts. The message includes an inline button that instantly launches the MemoBot trading interface as a native Telegram Mini App.
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="flex-1">
                    <input
                      type="text"
                      placeholder="Enter Telegram @username or Phone Number..."
                      className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2.5 rounded text-xs outline-none focus:border-[#00e676] transition-colors"
                      id="tg-invite-contact"
                    />
                  </div>
                  <button
                    onClick={async () => {
                      const el = document.getElementById("tg-invite-contact") as HTMLInputElement;
                      if (el && el.value) {
                        try {
                          await ApiClient.post("/institutional/telegram-invite", { contact: el.value, token: telegramToken });
                          showAlert(`📨 Mini App Invitation successfully dispatched to ${el.value}. Note: If they haven't started the bot yet, Telegram may block the message.`);
                          el.value = "";
                        } catch (err: any) {
                          showAlert("Failed to send invite: " + (err.message || err));
                        }
                      } else {
                        showAlert("⚠️ Please enter a valid Telegram username or phone number.");
                      }
                    }}
                    className="py-2.5 px-4 bg-[#00e676]/10 border border-[#00e676] text-[#00e676] hover:bg-[#00e676] hover:text-black rounded text-[11px] font-bold uppercase transition-all flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    SEND INVITE
                  </button>
                </div>
              </div>



              <div className="pt-2">
                <button
                  onClick={handleTestTelegram}
                  className="w-full py-3 bg-[#3b82f6]/10 border border-[#3b82f6] text-[#3b82f6] hover:bg-[#3b82f6] hover:text-white rounded text-[11px] font-bold uppercase transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  DISPATCH TEST PAYLOAD TO TELEGRAM
                </button>
              </div>
            </div>
          </div>


          
          {/* Email Briefings & Reports */}
          <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-5">
            <div className="flex items-center justify-between border-b border-[#11131c] pb-3">
              <div className="flex items-center gap-2 text-[#FA1F4E] font-bold text-[11px] uppercase">
                <Mail className="w-5 h-5 text-[#FA1F4E]" />
                EMAIL EXECUTIVE BRIEFINGS
              </div>
              <button
                onClick={() => {
                  setEmailEnabled(!emailEnabled);
                  showAlert(`Email briefings ${!emailEnabled ? "ENABLED" : "DISABLED"}`);
                }}
                className={`px-3 py-1.5 rounded text-[10px] font-bold border transition-all ${
                  emailEnabled
                    ? "bg-[#00e676]/20 border-[#00e676] text-[#00e676] shadow-[0_0_10px_rgba(0,230,118,0.2)]"
                    : "bg-transparent border-[#1a1d26] text-[#8a8d9a]"
                }`}
              >
                {emailEnabled ? "EMAIL: ACTIVE" : "EMAIL: OFF"}
              </button>
            </div>

            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-[#8a8d9a] font-bold block mb-1.5 uppercase">PRIMARY RECIPIENT EMAIL:</label>
                  <input
                    type="email"
                    value={recipientEmail ?? ""}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2.5 rounded text-xs outline-none focus:border-[#FA1F4E] transition-colors"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-[#8a8d9a] font-bold block mb-1.5 uppercase">DAILY BRIEFING SCHEDULE:</label>
                  <select
                    value={dailyBriefingSchedule ?? ""}
                    onChange={(e) => setDailyBriefingSchedule(e.target.value)}
                    className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2.5 rounded text-xs outline-none focus:border-[#FA1F4E] transition-colors"
                  >
                    <option value="08:00 UTC (Market Open)">08:00 UTC (Market Open)</option>
                    <option value="16:00 UTC (US Close)">16:00 UTC (US Close)</option>
                    <option value="23:59 UTC (Daily Roll)">23:59 UTC (Daily Roll)</option>
                  </select>
                </div>
              </div>

              {/* Notification Preferences */}
              <div className="pt-2">
                <label className="text-[10px] text-[#8a8d9a] font-bold block mb-2 uppercase border-b border-[#11131c] pb-1">EMAIL NOTIFICATION PREFERENCES:</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
                  <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded hover:border-[#FA1F4E]/50 transition-colors">
                    <div>
                      <span className="text-white font-bold block text-[10px]">Daily PnL</span>
                      <span className="text-[9px] text-[#8a8d9a]">Full report</span>
                    </div>
                    <input type="checkbox" checked={emailAlertDailyPnL} onChange={(e) => setEmailAlertDailyPnL(e.target.checked)} className="w-4 h-4 accent-[#FA1F4E] cursor-pointer" />
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded hover:border-[#FA1F4E]/50 transition-colors">
                    <div>
                      <span className="text-white font-bold block text-[10px]">Drawdown</span>
                      <span className="text-[9px] text-[#8a8d9a]">Critical alerts</span>
                    </div>
                    <input type="checkbox" checked={emailAlertDrawdown} onChange={(e) => setEmailAlertDrawdown(e.target.checked)} className="w-4 h-4 accent-[#FA1F4E] cursor-pointer" />
                  </div>
                  <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded hover:border-[#FA1F4E]/50 transition-colors">
                    <div>
                      <span className="text-white font-bold block text-[10px]">Trade Log</span>
                      <span className="text-[9px] text-[#8a8d9a]">Daily digest</span>
                    </div>
                    <input type="checkbox" checked={emailAlertTrades} onChange={(e) => setEmailAlertTrades(e.target.checked)} className="w-4 h-4 accent-[#FA1F4E] cursor-pointer" />
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={handleTestEmail}
                  className="w-full py-3 bg-[#FA1F4E]/10 border border-[#FA1F4E] text-[#FA1F4E] hover:bg-[#FA1F4E] hover:text-white rounded text-[11px] font-bold uppercase transition-all flex items-center justify-center gap-2"
                >
                  <Mail className="w-4 h-4" />
                  DISPATCH TEST EXECUTIVE BRIEFING EMAIL
                </button>
              </div>
            </div>
          </div>


          {/* Webhooks & Institutional Feeds */}
          <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
            <div className="flex items-center justify-between border-b border-[#11131c] pb-2">
              <div className="flex items-center gap-2 text-[#eab308] font-bold text-[10px] uppercase">
                <Globe className="w-4 h-4 text-[#eab308]" />
                CUSTOM WEBHOOK / DISCORD / SLACK FEED
              </div>
              <button
                onClick={() => {
                  setWebhookEnabled(!webhookEnabled);
                  showAlert(`Webhook stream ${!webhookEnabled ? "ENABLED" : "DISABLED"}`);
                }}
                className={`px-2.5 py-1 rounded text-[9px] font-bold border transition-all ${
                  webhookEnabled
                    ? "bg-[#00e676]/20 border-[#00e676] text-[#00e676]"
                    : "bg-transparent border-[#1a1d26] text-[#8a8d9a]"
                }`}
              >
                {webhookEnabled ? "WEBHOOK: ONLINE" : "WEBHOOK: OFF"}
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">ENDPOINT WEBHOOK URL:</label>
                <input
                  type="text"
                  value={webhookUrl ?? ""}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2 rounded text-xs outline-none focus:border-[#eab308]"
                />
              </div>

              <button
                onClick={handleTestWebhook}
                className="w-full py-2 bg-[#eab308]/10 border border-[#eab308] text-[#eab308] hover:bg-[#eab308] hover:text-black rounded text-[10px] font-bold uppercase transition-all flex items-center justify-center gap-1.5"
              >
                <Zap className="w-3.5 h-3.5" />
                DISPATCH TEST WEBHOOK PAYLOAD
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Trigger Thresholds & Audio Controls (lg:span-5) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Trigger Rules & Capital Safeguards */}
          <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
            <div className="flex items-center gap-2 border-b border-[#11131c] pb-2 text-[#00e676] font-bold text-[10px] uppercase">
              <ShieldAlert className="w-4 h-4 text-[#00e676]" />
              ALERT TRIGGER RULES & THRESHOLDS
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded">
                <div>
                  <span className="text-white font-bold block text-[10px]">ORDER EXECUTIONS (BUY/SELL)</span>
                  <span className="text-[9px] text-[#8a8d9a]">Instant notify on every HFT engine execution</span>
                </div>
                <input
                  type="checkbox"
                  checked={alertOnOrderExecution}
                  onChange={(e) => setAlertOnOrderExecution(e.target.checked)}
                  className="w-4 h-4 accent-[#3b82f6] cursor-pointer"
                />
              </div>

              <div className="p-2.5 bg-[#06070a] border border-[#1a1d26] rounded space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-white font-bold block text-[10px]">DRAWDOWN CAPITAL SHIELD</span>
                    <span className="text-[9px] text-[#8a8d9a]">Trigger alert when portfolio drawdown exceeds limit</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={alertOnDrawdown}
                    onChange={(e) => setAlertOnDrawdown(e.target.checked)}
                    className="w-4 h-4 accent-[#FA1F4E] cursor-pointer"
                  />
                </div>
                {alertOnDrawdown && (
                  <div className="flex items-center gap-2 pt-1 border-t border-[#11131c]">
                    <span className="text-[9px] text-[#8a8d9a] uppercase font-bold">TRIGGER LIMIT (%):</span>
                    <input
                      type="number"
                      step="0.1"
                      value={drawdownThresholdPercent ?? ""}
                      onChange={(e) => setDrawdownThresholdPercent(e.target.value)}
                      className="w-20 bg-[#0d0e12] border border-[#1a1d26] text-white p-1 rounded text-center text-xs outline-none"
                    />
                    <span className="text-[9px] text-[#FA1F4E] font-bold">% DRAWDOWN</span>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded">
                <div>
                  <span className="text-white font-bold block text-[10px]">HALAL COMPLIANCE AUDIT FLAGS</span>
                  <span className="text-[9px] text-[#8a8d9a]">Instant flag on swap/interest non-compliance</span>
                </div>
                <input
                  type="checkbox"
                  checked={alertOnHalalViolation}
                  onChange={(e) => setAlertOnHalalViolation(e.target.checked)}
                  className="w-4 h-4 accent-[#00e676] cursor-pointer"
                />
              </div>

              <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded">
                <div>
                  <span className="text-white font-bold block text-[10px]">LATENCY & WEBSOCKET SPIKE</span>
                  <span className="text-[9px] text-[#8a8d9a]">Alert if exchange response time exceeds 100ms</span>
                </div>
                <input
                  type="checkbox"
                  checked={alertOnLatencySpike}
                  onChange={(e) => setAlertOnLatencySpike(e.target.checked)}
                  className="w-4 h-4 accent-[#eab308] cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Sound & Browser Push FX */}
          <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
            <div className="flex items-center gap-2 border-b border-[#11131c] pb-2 text-[#3b82f6] font-bold text-[10px] uppercase">
              <Volume2 className="w-4 h-4 text-[#3b82f6]" />
              AUDIO EFFECTS & IN-APP BANNERS
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded">
                <div>
                  <span className="text-white font-bold block text-[10px]">AUDIOPHILE TRADE SOUND CHIME</span>
                  <span className="text-[9px] text-[#8a8d9a]">Play distinct futuristic chime on order fills</span>
                </div>
                <button
                  onClick={() => {
                    setSoundAlerts(!soundAlerts);
                    if (!soundAlerts) showAlert("🎵 Audio execution chimes turned ON.");
                  }}
                  className={`px-3 py-1 rounded text-[9px] font-bold border transition-all ${
                    soundAlerts ? "bg-[#3b82f6]/20 border-[#3b82f6] text-[#3b82f6]" : "bg-transparent border-[#1a1d26] text-[#8a8d9a]"
                  }`}
                >
                  {soundAlerts ? "SOUND: ON" : "SOUND: MUTE"}
                </button>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-[#06070a] border border-[#1a1d26] rounded">
                <div>
                  <span className="text-white font-bold block text-[10px]">DESKTOP & BROWSER PUSH NOTIFICATIONS</span>
                  <span className="text-[9px] text-[#8a8d9a]">Show browser push toasts when tab is minimized</span>
                </div>
                <button
                  onClick={() => {
                    setDesktopPush(!desktopPush);
                    if (!desktopPush) showAlert("🔔 Desktop push notifications enabled.");
                  }}
                  className={`px-3 py-1 rounded text-[9px] font-bold border transition-all ${
                    desktopPush ? "bg-[#00e676]/20 border-[#00e676] text-[#00e676]" : "bg-transparent border-[#1a1d26] text-[#8a8d9a]"
                  }`}
                >
                  {desktopPush ? "PUSH: ACTIVE" : "PUSH: OFF"}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
