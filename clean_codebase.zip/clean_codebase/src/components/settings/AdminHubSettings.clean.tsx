import React, { useState, useEffect } from "react";
import {
  ShieldAlert,
  Search,
  UserCheck,
  UserX,
  UserPlus,
  Heart,
  Gift,
  Award,
  FileText,
  Copy,
  Check,
  RefreshCw,
  Clock,
  Activity,
  Lock,
  Unlock,
  Sparkles,
  ChevronDown,
  Terminal,
  Send,
  Smartphone,
  ExternalLink,
  CreditCard
} from "lucide-react";
import { ApiClient } from "../../services/api";

interface AdminHubSettingsProps {
  showAlert: (msg: string) => void;
}

interface UserProfile {
  id: string;
  name: string;
  contact: string;
  email: string;
  role: string;
  isVIP: boolean;
  vipBadge?: string;
  isFrozen: boolean;
  joinedAt: string;
  patchGroup: "Family (1st Patch)" | "Close Friends (2nd Patch)" | "Marketing Ambassador (3rd Patch)" | "Standard Client";
  lastActive: string;
  activities: { timestamp: string; action: string; details: string }[];
  billingStatus?: 'Waived' | 'Active' | 'Pending';
  successFeePct?: number;
  monthlyFee?: number;
  invoices?: { id: string; date: string; type: string; amount: number; status: 'PAID' | 'WAIVED' | 'PENDING' }[];
  logins?: { timestamp: string; ip: string; device: string; location: string; status: 'SUCCESS' | 'FAILED' }[];
  username?: string;
  password?: string;
  mustChangePassword?: boolean;
}

interface TrialInvitation {
  id: string;
  recipientName: string;
  recipientContact: string;
  duration: '24hrs' | '3days' | '1week' | '1month';
  createdAt: string;
  expiresAt: string;
  status: 'PENDING' | 'ACTIVE' | 'EXPIRED' | 'REVOKED';
  invitedBy: string;
  username?: string;
  password?: string;
}

export const AdminHubSettings: React.FC<AdminHubSettingsProps> = ({ showAlert }) => {
  // Live User Activity Registry for Monitoring
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [copiedLetter, setCopiedLetter] = useState<boolean>(false);

  // Search filter query
  const [searchQuery, setSearchQuery] = useState("");

  // New User Creation Form State
  const [newUserName, setNewUserName] = useState("");
  const [newUserContact, setNewUserContact] = useState("");
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserPatch, setNewUserPatch] = useState<UserProfile["patchGroup"]>("Family (1st Patch)");
  const [generatedLetter, setGeneratedLetter] = useState<string | null>(null);

  // VIP Dispatch Console States
  const [dispatchMethod, setDispatchMethod] = useState<"Email" | "SMS" | "WhatsApp">("Email");
  const [dispatchLogs, setDispatchLogs] = useState<string[]>([]);
  const [dispatching, setDispatching] = useState<boolean>(false);
  const [dispatchSuccess, setDispatchSuccess] = useState<boolean>(false);

  // Trial Invitation System States
  const [trialInvitations, setTrialInvitations] = useState<TrialInvitation[]>([]);
  const [newTrialName, setNewTrialName] = useState("");
  const [newTrialContact, setNewTrialContact] = useState("");
  const [newTrialDuration, setNewTrialDuration] = useState<'24hrs' | '3days' | '1week' | '1month'>("3days");
  const [isSubmittingTrial, setIsSubmittingTrial] = useState(false);
  const [generatedTrialLetter, setGeneratedTrialLetter] = useState<string | null>(null);
  const [copiedTrialLetter, setCopiedTrialLetter] = useState(false);

  // Fetch users & trial invitations
  const fetchAllData = async (active = true) => {
    try {
      const usersData = await ApiClient.get("/admin/vip-users");
      if (active && Array.isArray(usersData)) {
        setUsers(usersData);
        if (usersData.length > 0 && !selectedUserId) {
          setSelectedUserId(usersData[0].id);
        }
      }

      const trialData = await ApiClient.get("/admin/trial-invitations");
      if (active && trialData && Array.isArray(trialData.invitations)) {
        setTrialInvitations(trialData.invitations);
      }
    } catch (err: any) {
      console.error("Failed to fetch admin VIP users or trial invitations:", err);
    } finally {
      if (active) setLoading(false);
    }
  };

  useEffect(() => {
    let active = true;
    fetchAllData(active);
    return () => {
      active = false;
    };
  }, []);

  const handleCreateTrialInvitation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTrialName.trim() || !newTrialContact.trim()) {
      showAlert("Please enter recipient name and email/phone for the trial invitation.", "error");
      return;
    }

    setIsSubmittingTrial(true);
    setGeneratedTrialLetter(null);
    try {
      const res = await ApiClient.post("/admin/trial-invitations", {
        recipientName: newTrialName,
        recipientContact: newTrialContact,
        duration: newTrialDuration
      });

      if (res && res.success) {
        const invite = res.invitation;
        
        // Generate professional copyable invitation message with temporary credentials
        const trialLetter = `⚡ ========================================== ⚡
🛡️ MEMOBOT FX-PRO™ TRIAL SANDBOX AUTHORIZATION 🛡️
⚡ ========================================== ⚡

Dear ${newTrialName.trim()},

We are pleased to provision your temporary trial access to the MEMOBOT FX-PRO™ algorithmic asset execution suite. This license grants you temporary sandbox simulation capabilities to monitor platform performance and real-time execution telemetry.

============================================================
🎁 LICENSE DETAILED TERMS
============================================================
- License ID: ${invite.id}
- Active Term Duration: ${invite.duration}
- Expiration Timeline: ${invite.expiresAt}
- Scope: Non-Custodial Sandbox Trading & Real-Time Testnet Telemetry (No Capital Risked)

============================================================
🔑 SECURE TEMPORARY TRIAL LOGIN CREDENTIALS
============================================================
For your security, you are required to change this password on your first login:

Platform Access Link: ${window.location.origin}
Your Access ID (Username): ${invite.username}
Your Temporary Password Key: ${invite.password}

============================================================
🛡️ CRITICAL NON-CUSTODIAL SAFETY INFORMATION
============================================================
MEMOBOT FX-PRO™ operates as a pure execution manager via secure API connections:
- We DO NOT hold, custody, or store your digital assets.
- We DO NOT have permission to, nor can we ever, withdraw your funds.
- Under trial mode, the platform is restricted to sandbox simulation telemetry, so your real capital is never at risk.

To begin your experience, navigate to the Platform Access Link and authenticate using your temporary credentials.

Welcome to the future of asset intelligence,

With respects,

— The MemoBot FX-Pro Operations Division
🔒 Secure Trial Provisioning Grid Active`;

        setGeneratedTrialLetter(trialLetter);
        showAlert(`Trial Invitation Code ${invite.id} generated successfully with secure temporary credentials!`);
        setNewTrialName("");
        setNewTrialContact("");
        // Reload trial invitations
        const trialData = await ApiClient.get("/admin/trial-invitations");
        if (trialData && Array.isArray(trialData.invitations)) {
          setTrialInvitations(trialData.invitations);
        }
      } else {
        showAlert(res?.error || "Failed to generate trial invitation.", "error");
      }
    } catch (err: any) {
      showAlert(`Error: ${err.message || err}`, "error");
    } finally {
      setIsSubmittingTrial(false);
    }
  };

  const handleToggleTrialStatus = async (inviteId: string, status?: string) => {
    try {
      const res = await ApiClient.post(`/admin/trial-invitations/${inviteId}/toggle-status`, { status });
      if (res && res.success) {
        setTrialInvitations(prev => prev.map(inv => inv.id === inviteId ? res.invitation : inv));
        showAlert(`Invitation ${inviteId} status updated to ${res.invitation.status}.`);
      }
    } catch (err: any) {
      showAlert(`Failed to update trial invitation: ${err.message || err}`, "error");
    }
  };

  const filteredUsers = users.filter((u) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      u.id.toLowerCase().includes(q) ||
      u.name.toLowerCase().includes(q) ||
      (u.email && u.email.toLowerCase().includes(q)) ||
      (u.contact && u.contact.toLowerCase().includes(q)) ||
      u.patchGroup.toLowerCase().includes(q)
    );
  });

  const selectedUser = filteredUsers.find((u) => u.id === selectedUserId) || filteredUsers[0] || users[0];

  // Sub-tabs for detailed client intelligence
  const [clientSubTab, setClientSubTab] = useState<"activities" | "billing" | "logins">("activities");
  const [customInvoiceAmount, setCustomInvoiceAmount] = useState<string>("150.00");
  const [customInvoiceType, setCustomInvoiceType] = useState<string>("SUCCESS_FEE");

  const handleToggleFreeze = async (userId: string) => {
    try {
      const res = await ApiClient.post(`/admin/vip-users/${userId}/toggle-freeze`);
      if (res && res.success && res.user) {
        setUsers((prev) => prev.map((u) => (u.id === userId ? res.user : u)));
        showAlert(`Account ${res.user.name} (${res.user.id}) has been ${res.user.isFrozen ? "FROZEN / HELD" : "UNFROZEN / ACTIVATED"}.`);
      }
    } catch (err: any) {
      showAlert(`Failed to toggle account freeze: ${err.message || err}`);
    }
  };

  const handleToggleBilling = async (userId: string) => {
    try {
      const res = await ApiClient.post(`/admin/vip-users/${userId}/toggle-billing`);
      if (res && res.success && res.user) {
        setUsers((prev) => prev.map((u) => (u.id === userId ? res.user : u)));
        showAlert(`Billing for ${res.user.name} (${res.user.id}) changed to: ${res.user.billingStatus}.`);
      }
    } catch (err: any) {
      showAlert(`Failed to update billing: ${err.message || err}`);
    }
  };

  const handleTriggerInvoice = async (userId: string) => {
    try {
      const amount = parseFloat(customInvoiceAmount);
      if (isNaN(amount) || amount <= 0) {
        showAlert("Please enter a valid invoice amount.");
        return;
      }
      const res = await ApiClient.post(`/admin/vip-users/${userId}/add-invoice`, {
        amount,
        type: customInvoiceType
      });
      if (res && res.success && res.user) {
        setUsers((prev) => prev.map((u) => (u.id === userId ? res.user : u)));
        showAlert(`Custom invoice generated for $${amount.toFixed(2)} (${customInvoiceType}).`);
      }
    } catch (err: any) {
      showAlert(`Failed to generate invoice: ${err.message || err}`);
    }
  };

  const handleCreateVIPUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || (!newUserEmail.trim() && !newUserContact.trim())) {
      showAlert("Please enter at least a Name and an Email or Phone number.");
      return;
    }

    const newId = `USR-${Math.floor(1000 + Math.random() * 9000)}`;
    const generatedUsername = `client_${newUserName.trim().toLowerCase().replace(/[^a-z0-9]/g, "").substring(0, 10) || "user"}_${newId.split("-")[1]}`;
    const generatedPassword = `MB-VIP-${Math.floor(100000 + Math.random() * 900000)}`;

    let badge = "VIP HONORED MEMBER 💎";
    if (newUserPatch === "Family (1st Patch)") {
      badge = "FAMILY VIP 💖 (FREE FOR LIFE)";
    } else if (newUserPatch === "Close Friends (2nd Patch)") {
      badge = "INNER CIRCLE VIP 🌟 (FREE FOR LIFE)";
    } else if (newUserPatch === "Marketing Ambassador (3rd Patch)") {
      badge = "PROMO AMBASSADOR VIP 🚀";
    }

    const isStandard = newUserPatch === "Standard Client";
    const createdUser: UserProfile = {
      id: newId,
      name: newUserName.trim(),
      contact: newUserContact.trim() || "N/A",
      email: newUserEmail.trim() || "N/A",
      role: isStandard ? "Standard Trader" : `Lifetime VIP (${newUserPatch.split(" ")[0]})`,
      isVIP: !isStandard,
      vipBadge: isStandard ? undefined : badge,
      isFrozen: false,
      joinedAt: new Date().toISOString().replace("T", " ").substring(0, 19),
      patchGroup: newUserPatch,
      lastActive: "Just created",
      billingStatus: isStandard ? "Active" : "Waived",
      successFeePct: isStandard ? 15 : 0,
      monthlyFee: isStandard ? 499 : 0,
      username: generatedUsername,
      password: generatedPassword,
      mustChangePassword: true,
      invoices: [
        {
          id: `INV-${newId.split("-")[1]}-01`,
          date: new Date().toISOString().substring(0, 10),
          type: "SUBSCRIPTION",
          amount: isStandard ? 499.00 : 499.00,
          status: isStandard ? "PENDING" : "WAIVED"
        }
      ],
      logins: [
        {
          timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
          ip: "127.0.0.1",
          device: "Admin Panel Provision Link",
          location: "Internal Server",
          status: "SUCCESS"
        }
      ],
      activities: [
        {
          timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
          action: "ACCOUNT_CREATED",
          details: isStandard
            ? "Provisioned as Standard Client with Active billing terms."
            : `Provisioned as Lifetime Free VIP under ${newUserPatch}.`,
        },
      ],
    };

    try {
      const res = await ApiClient.post("/admin/vip-users", createdUser);
      if (res && res.success) {
        setUsers((prev) => [res.user, ...prev]);
        setSelectedUserId(newId);

        // High elite welcome package explaining brand, platform guidelines, and critical fund security
        const letter = `💎 ========================================== 💎
🏆 MEMOBOT FX-PRO™ ELITE VIP WELCOME PACKAGE 🏆
💎 ========================================== 💎

Dear ${newUserName.trim()},

We are deeply honored and humbled to welcome you to the absolute pinnacle of automated high-frequency asset intelligence: MEMOBOT FX-PRO™.

Our platform exists with a single, unyielding guiding mission: 
"To Protect Capital First and Add a Genuine Smile to Your Face Every Single Day." 

As an esteemed family or inner-circle member, you have been granted full Lifetime VIP Access—completely free, forever, with zero subscription costs, no performance-share fees, and unlimited concurrent algorithmic execution threads.

============================================================
🔑 SECURE TEMPORARY SYSTEM ACCESS CREDENTIALS
============================================================
To access your personal trading console, please use these credentials:

Platform Access Link: ${window.location.origin}
Your Access ID (Username): ${generatedUsername}
Your Temporary Password Key: ${generatedPassword}

⚠️ ATTENTION: For security purposes, you will be forced to change this password key upon your very first login.

============================================================
🛡️ CRITICAL SECURITY & NON-CUSTODIAL GUARANTEE
============================================================
MEMOBOT FX-PRO™ operates as a pure execution manager via secure API endpoints:
- We DO NOT hold, custody, or store your digital assets.
- We DO NOT have permission to, nor can we ever, withdraw your funds.
- Your capital remains 100% inside your own verified exchange accounts (such as Binance, OKX, or Bybit), under your absolute, exclusive personal control at all times.
- MemoBot simply conducts lightning-fast compliance-first calculations and triggers instant trading instructions directly inside your personal account with utmost precision.

============================================================
📦 WHAT IS INCLUDED IN YOUR VIP KIT
============================================================
1. Ultra-Low Latency Execution Engine: Access to our highest-priority memory grid.
2. Premium Shariyah Bureau Validation: Auto-filtering of non-compliant assets in real-time.
3. 24/7 Dedicated Concierge Node: Instant priority processing for all your strategies.
4. Fully Waived Management Charges: Permanent bypass of all monthly billing cycles.

Whether you are managing modest personal savings or high-net-worth institutional capital, MemoBot works tirelessly on your behalf with absolute care.

Welcome to our global family,

With our warmest regards, deepest gratitude, & respect,

— The MemoBot FX-Pro Executive Team
🔒 Secure Multi-Tenant Architecture Verified`;

        setGeneratedLetter(letter);
        setDispatchLogs([]);
        setDispatchSuccess(false);
        // Default select dispatch channel based on inputs
        if (newUserEmail.trim()) {
          setDispatchMethod("Email");
        } else {
          setDispatchMethod("SMS");
        }

        showAlert(`Successfully created Lifetime VIP account for ${newUserName}! Auto welcome letter generated.`);

        // Reset inputs
        setNewUserName("");
        setNewUserContact("");
        setNewUserEmail("");
      }
    } catch (err: any) {
      showAlert(`Failed to create VIP user: ${err.message || err}`);
    }
  };

  const handleDispatchInvitation = () => {
    if (!generatedLetter) return;
    setDispatching(true);
    setDispatchSuccess(false);
    setDispatchLogs([]);

    const recipientName = selectedUser ? selectedUser.name : "VIP Client";
    const targetAddress = dispatchMethod === "Email" 
      ? (selectedUser?.email && selectedUser.email !== "N/A" ? selectedUser.email : "") 
      : (selectedUser?.contact && selectedUser.contact !== "N/A" ? selectedUser.contact : "");

    if (!targetAddress) {
      setDispatchLogs([
        `[${new Date().toLocaleTimeString()}] ❌ ERROR: Target address for ${dispatchMethod} is empty or invalid. Please check the profile input!`
      ]);
      setDispatching(false);
      showAlert(`Please configure a valid email/phone to dispatch via ${dispatchMethod}!`, "error");
      return;
    }

    const steps = [
      `[${new Date().toLocaleTimeString()}] 🚀 INITIALIZING SYSTEM OUTBOUND DISPATCH PROTOCOL...`,
      `[${new Date().toLocaleTimeString()}] 📡 Channel Selected: Secure ${dispatchMethod} Relay Gateway`,
      `[${new Date().toLocaleTimeString()}] 📦 Compiling brand explanation and non-custodial custody disclosure...`,
      `[${new Date().toLocaleTimeString()}] 🔐 Embedding secure API seed credentials for ${recipientName}...`,
      `[${new Date().toLocaleTimeString()}] 🔌 Resolving route to target server destination: ${targetAddress}...`,
      `[${new Date().toLocaleTimeString()}] 🛰️ Routing Elite VIP waived billing certificate to dispatch database...`,
      `[${new Date().toLocaleTimeString()}] 📧 Contacting live outbound API gateway...`,
      `[${new Date().toLocaleTimeString()}] ⚡ Initiating secure payload packet handshake...`
    ];

    let currentStep = 0;
    const interval = setInterval(async () => {
      if (currentStep < steps.length) {
        setDispatchLogs(prev => [...prev, steps[currentStep]]);
        currentStep++;
      } else {
        clearInterval(interval);
        try {
          // Trigger actual backend SMTP / SMS dispatch
          const res = await ApiClient.post("/admin/dispatch-invitation", {
            userId: selectedUserId,
            method: dispatchMethod,
            letterContent: generatedLetter,
            targetAddress
          });

          if (res && res.success) {
            const isSim = !!res.isSimulated;
            setDispatchLogs(prev => [
              ...prev,
              `[${new Date().toLocaleTimeString()}] ⚡ Packet transmission acknowledged by gateway server.`,
              isSim 
                ? `[${new Date().toLocaleTimeString()}] 🛡️ [SIMULATION MODE COMPLETED] ${res.message || "Routed via sandbox environment."}`
                : `[${new Date().toLocaleTimeString()}] ✅ DISPATCH SUCCESS! Elite Welcome Kit successfully routed and delivered to ${targetAddress}!`,
              `[${new Date().toLocaleTimeString()}] 🟢 Core System Telemetry: 100% Operational.`
            ]);
            setDispatchSuccess(true);
            showAlert(isSim ? "VIP Welcome Kit successfully simulated and queued!" : `Elite VIP Welcome Kit successfully sent to ${targetAddress}!`);
          } else {
            const errMsg = res?.error || "Unknown server response rejection";
            setDispatchLogs(prev => [
              ...prev,
              `[${new Date().toLocaleTimeString()}] ❌ SYSTEM DISPATCH ERROR: ${errMsg}`,
              `[${new Date().toLocaleTimeString()}] 💡 GUIDE: Make sure to define SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, and SMTP_FROM in the system settings or .env file to enable live outgoing mail.`
            ]);
            setDispatchSuccess(false);
            showAlert(`Dispatch issue: ${errMsg}`, "error");
          }
        } catch (err: any) {
          const errMsg = err.message || err;
          setDispatchLogs(prev => [
            ...prev,
            `[${new Date().toLocaleTimeString()}] ❌ CONNECTIVITY ERROR: Failed to reach dispatch relay endpoint: ${errMsg}`,
            `[${new Date().toLocaleTimeString()}] 💡 GUIDE: Make sure your server dev-server environment configuration is up-to-date.`
          ]);
          setDispatchSuccess(false);
          showAlert(`Failed to connect to dispatch route: ${errMsg}`, "error");
        } finally {
          setDispatching(false);
        }
      }
    }, 400);
  };

  const copyLetterToClipboard = () => {
    if (!generatedLetter) return;
    navigator.clipboard.writeText(generatedLetter);
    setCopiedLetter(true);
    setTimeout(() => setCopiedLetter(false), 2000);
    showAlert("Honorable Welcome Letter copied to clipboard!");
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-[#06070a] border border-[#1a1d26] rounded-xl text-white font-mono text-xs space-y-4 shadow-[0_0_30px_rgba(0,0,0,0.8)]">
        <div className="relative flex items-center justify-center">
          <div className="w-12 h-12 rounded-full border border-cyan-500/30 border-t-[#00f0ff] animate-spin" />
          <div className="absolute w-8 h-8 rounded-full border border-[#FA1F4E]/30 border-b-[#FA1F4E] animate-spin" style={{ animationDirection: "reverse" }} />
          <img src="/MemoBot.png" alt="MemoBot" className="h-6 w-auto mix-blend-screen filter drop-shadow-[0_0_8px_rgba(250,31,78,0.9)] absolute" />
        </div>
        <p className="text-[#FA1F4E] font-bold uppercase tracking-widest drop-shadow-[0_0_8px_rgba(250,31,78,0.4)]">
          Synchronizing Override Registry with Secure Database...
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Admin Hub Header Banner */}
      <div className="bg-[#0d0e12] border border-[#FA1F4E]/40 p-4 rounded-lg flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-[0_0_20px_rgba(250,31,78,0.15)]">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#FA1F4E]/20 border border-[#FA1F4E]/50 rounded-lg text-[#FA1F4E] shrink-0">
            <ShieldAlert className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-white font-extrabold uppercase tracking-widest text-sm">
                ADMIN HUB & USER OVERRIDE CONTROL
              </span>
              <span className="px-2 py-0.5 bg-[#FA1F4E]/20 border border-[#FA1F4E]/60 text-[#FA1F4E] text-[8.5px] font-extrabold rounded uppercase">
                SUPERADMIN ACCESS ACTIVE
              </span>
            </div>
            <p className="text-[10px] text-[#8a8d9a] mt-0.5">
              Monitor client movements, manage user freezing, and provision lifetime free VIP accounts for family, friends, and marketing.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* User Activity & Telemetry Monitoring Dropdown Panel (lg:span-7) */}
        <div className="lg:col-span-7 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
          <div className="flex items-center justify-between border-b border-[#11131c] pb-2">
            <div className="flex items-center gap-2 text-[#00e5ff] font-bold text-[10px] uppercase">
              <Search className="w-4 h-4 text-[#00e5ff]" />
              CLIENT MONITORING & MOVEMENT TELEMETRY
            </div>
            <span className="text-[9px] text-[#8a8d9a]">LIVE AUDIT (PRIVACY SAFE)</span>
          </div>

          {/* User Selector Dropdown */}
          <div className="space-y-3">
            <div>
              <label className="text-[9px] text-[#8a8d9a] font-bold uppercase block mb-1">
                SEARCH CLIENT REGISTRY (REAL-TIME FUZZY FILTER):
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Type Name, Email, Phone, Client ID, or Patch Group..."
                  className="w-full bg-[#06070a] border border-[#00e5ff]/30 hover:border-[#00e5ff] focus:border-[#00e5ff] text-white p-2 pl-8 rounded text-xs outline-none font-mono"
                />
                <Search className="w-3.5 h-3.5 text-[#8a8d9a] absolute left-2.5 top-2.5" />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery("")}
                    className="absolute right-2.5 top-2.5 text-[#8a8d9a] hover:text-white text-[9px] uppercase font-bold"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] text-[#8a8d9a] font-bold uppercase block">
                SELECT CLIENT PROFILE:
              </label>
              <div className="relative">
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="w-full bg-[#06070a] border border-[#00e5ff]/40 hover:border-[#00e5ff] text-white p-2.5 rounded text-xs outline-none font-mono cursor-pointer appearance-none pr-8"
                >
                  {filteredUsers.length > 0 ? (
                    filteredUsers.map((u) => (
                      <option key={u.id} value={u.id}>
                        [{u.id}] {u.name} ({u.email || u.contact}) - {u.patchGroup}
                      </option>
                    ))
                  ) : (
                    <option value="" disabled>No clients match filter</option>
                  )}
                </select>
                <ChevronDown className="w-4 h-4 text-[#00e5ff] absolute right-2.5 top-3 pointer-events-none" />
              </div>
              {filteredUsers.length === 0 && (
                <p className="text-[#FA1F4E] text-[8.5px] font-bold uppercase mt-1">
                  ⚠️ No active matches found in DB state for &quot;{searchQuery}&quot;. Please broaden your search.
                </p>
              )}
            </div>
          </div>

          {/* Selected Client Card Details */}
          {selectedUser && (
            <div className="bg-[#06070a] border border-[#1a1d26] p-4 rounded space-y-3">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-[#11131c] pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-white font-extrabold text-sm">{selectedUser.name}</span>
                    {selectedUser.vipBadge && (
                      <span className="px-2 py-0.5 bg-[#FA1F4E]/15 border border-[#FA1F4E]/40 text-[#FA1F4E] text-[8.5px] font-bold rounded uppercase">
                        {selectedUser.vipBadge}
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-[#8a8d9a] mt-0.5">
                    ID: <span className="text-white font-bold">{selectedUser.id}</span> | Contact: {selectedUser.contact} | Email: {selectedUser.email}
                  </div>
                </div>

                <button
                  onClick={() => handleToggleFreeze(selectedUser.id)}
                  className={`px-3.5 py-1.5 rounded text-[10px] font-extrabold uppercase transition-all flex items-center gap-1.5 ${
                    selectedUser.isFrozen
                      ? "bg-[#00e676] hover:bg-[#0ea5e9] text-black"
                      : "bg-[#ef4444] hover:bg-[#dc2626] text-white shadow-[0_0_10px_rgba(239,68,68,0.3)]"
                  }`}
                >
                  {selectedUser.isFrozen ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                  {selectedUser.isFrozen ? "UNFREEZE / RELEASE ACCOUNT" : "FREEZE / HOLD ACCOUNT"}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div className="bg-[#0d0e12] p-2 rounded border border-[#1a1d26]">
                  <span className="text-[#8a8d9a] block">JOINED SINCE:</span>
                  <span className="text-white font-bold">{selectedUser.joinedAt}</span>
                </div>
                <div className="bg-[#0d0e12] p-2 rounded border border-[#1a1d26]">
                  <span className="text-[#8a8d9a] block">PATCH GROUP:</span>
                  <span className="text-[#00e5ff] font-bold">{selectedUser.patchGroup}</span>
                </div>
              </div>

              {/* Internal Client Sub-Tabs Navigation */}
              <div className="flex border-b border-[#161822] gap-1 pb-1 pt-1">
                <button
                  type="button"
                  onClick={() => setClientSubTab("activities")}
                  className={`flex-1 py-1.5 px-2 rounded-t text-[9px] font-bold uppercase transition-all flex items-center justify-center gap-1.5 border-t border-x ${
                    clientSubTab === "activities"
                      ? "bg-[#0d0e12] border-[#1a1d26] text-[#00e5ff]"
                      : "bg-[#06070a]/40 border-transparent text-[#8a8d9a] hover:text-white hover:bg-[#06070a]"
                  }`}
                >
                  <Activity className="w-3 h-3" />
                  Audit Trail
                </button>
                <button
                  type="button"
                  onClick={() => setClientSubTab("billing")}
                  className={`flex-1 py-1.5 px-2 rounded-t text-[9px] font-bold uppercase transition-all flex items-center justify-center gap-1.5 border-t border-x ${
                    clientSubTab === "billing"
                      ? "bg-[#0d0e12] border-[#1a1d26] text-[#FA1F4E]"
                      : "bg-[#06070a]/40 border-transparent text-[#8a8d9a] hover:text-white hover:bg-[#06070a]"
                  }`}
                >
                  <CreditCard className="w-3 h-3" />
                  Billing & Invoices
                </button>
                <button
                  type="button"
                  onClick={() => setClientSubTab("logins")}
                  className={`flex-1 py-1.5 px-2 rounded-t text-[9px] font-bold uppercase transition-all flex items-center justify-center gap-1.5 border-t border-x ${
                    clientSubTab === "logins"
                      ? "bg-[#0d0e12] border-[#1a1d26] text-[#00e676]"
                      : "bg-[#06070a]/40 border-transparent text-[#8a8d9a] hover:text-white hover:bg-[#06070a]"
                  }`}
                >
                  <Smartphone className="w-3 h-3" />
                  Login Sessions
                </button>
              </div>

              {/* Sub-Tab 1: Complete User Movement History */}
              {clientSubTab === "activities" && (
                <div className="space-y-1.5 pt-1">
                  <span className="text-[9px] font-extrabold text-[#00e5ff] uppercase block flex items-center gap-1">
                    <Activity className="w-3 h-3" />
                    COMPLETE MOVEMENT & AUDIT LOGS (PRIVACY-PRESERVED)
                  </span>
                  <div className="max-h-56 overflow-y-auto space-y-1.5 bg-[#0d0e12] p-2.5 rounded border border-[#1a1d26] font-mono">
                    {selectedUser.activities && selectedUser.activities.length > 0 ? (
                      selectedUser.activities.map((act, i) => (
                        <div key={i} className="text-[9.5px] border-b border-[#11131c] last:border-none pb-1.5">
                          <div className="flex justify-between text-[#8a8d9a]">
                            <span>{act.timestamp}</span>
                            <span className="text-[#00e5ff] font-bold">{act.action}</span>
                          </div>
                          <div className="text-white mt-0.5">{act.details}</div>
                        </div>
                      ))
                    ) : (
                      <div className="text-[#8a8d9a] text-center py-4 text-[10px]">
                        No movement or audit logs found.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Sub-Tab 2: Client Billing, Wave Toggle, Invoice Generation & Invoice List */}
              {clientSubTab === "billing" && (
                <div className="space-y-3 pt-1 text-[10px]">
                  {/* System Architecture Explanation Card */}
                  <div className="bg-[#06070a] border border-[#00e5ff]/20 p-3 rounded text-[8.5px] leading-relaxed text-[#8a8d9a] space-y-1.5">
                    <div className="text-[#00e5ff] font-extrabold uppercase text-[9px] flex items-center gap-1.5">
                      <CreditCard className="w-3.5 h-3.5 text-[#00e5ff]" />
                      HOW SUBSCRIPTION & FINANCIAL INCLUSION FEES ARE CONNECTED
                    </div>
                    <p>
                      Each client profile on MEMOBOT FX-PRO™ is bound to specific billing protocols:
                    </p>
                    <ul className="list-disc pl-4 space-y-1 text-[#8a8d9a]">
                      <li>
                        <span className="text-white font-bold">Standard Commercial Fee Scheme:</span> Connected automatically to a <span className="text-white font-bold">$499.00/mo</span> base subscription and a <span className="text-white font-bold">15% Net Profit Success Fee</span> generated via settlement invoices.
                      </li>
                      <li>
                        <span className="text-white font-bold">Inclusion VIP Wave Protocol:</span> Activated for Patches (Family, Friends, or Marketing). Bypasses monthly infrastructure charges ($0.00) and waives success fees (0.00% net profit) automatically.
                      </li>
                    </ul>
                  </div>

                  {/* Current Plan Overview */}
                  <div className="bg-[#0d0e12] p-2.5 rounded border border-[#1a1d26] space-y-2">
                    <div className="flex justify-between items-center border-b border-[#161822] pb-1.5">
                      <span className="font-bold text-white uppercase text-[9.5px]">Billing Profile & Fee Control</span>
                      <span className={`px-2 py-0.5 rounded text-[8px] font-bold ${
                        selectedUser.billingStatus === "Waived" 
                          ? "bg-[#00e676]/15 text-[#00e676] border border-[#00e676]/40" 
                          : "bg-[#FA1F4E]/15 text-[#FA1F4E] border border-[#FA1F4E]/40"
                      }`}>
                        {selectedUser.billingStatus === "Waived" ? "FEES WAIVED (VIP FREE)" : "ACTIVE BILLING"}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[9px]">
                      <div>
                        <span className="text-[#8a8d9a] block text-[8px]">Monthly Subscription:</span>
                        <span className="text-white font-bold">
                          {selectedUser.billingStatus === "Waived" ? "$0.00 (Waived)" : `$${selectedUser.monthlyFee || 499}.00/mo`}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#8a8d9a] block text-[8px]">Performance Success Fee:</span>
                        <span className="text-white font-bold">
                          {selectedUser.billingStatus === "Waived" ? "0% (Bypassed)" : `${selectedUser.successFeePct || 15}% Net Profit`}
                        </span>
                      </div>
                    </div>

                    {/* Toggle Override Button */}
                    <div className="pt-1.5 flex justify-end">
                      <button
                        type="button"
                        onClick={() => handleToggleBilling(selectedUser.id)}
                        className={`px-3 py-1 text-[8.5px] font-bold uppercase rounded transition-all border ${
                          selectedUser.billingStatus === "Waived"
                            ? "border-[#FA1F4E]/40 bg-[#FA1F4E]/10 text-[#FA1F4E] hover:bg-[#FA1F4E] hover:text-white"
                            : "border-[#00e676]/40 bg-[#00e676]/10 text-[#00e676] hover:bg-[#00e676] hover:text-black"
                        }`}
                      >
                        {selectedUser.billingStatus === "Waived" ? "Activate Commercial Charges" : "Waive All Subscription & Success Fees"}
                      </button>
                    </div>
                  </div>

                  {/* Manual Invoice Builder */}
                  <div className="bg-[#0d0e12] p-2.5 rounded border border-[#1a1d26] space-y-2">
                    <span className="font-bold text-white uppercase text-[9px] block">Trigger Manual Client Invoice</span>
                    <div className="grid grid-cols-12 gap-1.5 items-center">
                      <div className="col-span-4">
                        <select
                          value={customInvoiceType}
                          onChange={(e) => setCustomInvoiceType(e.target.value)}
                          className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-1 rounded text-[9.5px] outline-none"
                        >
                          <option value="SUCCESS_FEE">Success Fee</option>
                          <option value="SUBSCRIPTION">Subscription</option>
                          <option value="HFT_SETUP">Setup Charge</option>
                        </select>
                      </div>
                      <div className="col-span-5 relative">
                        <span className="absolute left-1.5 top-1.5 text-[#8a8d9a] text-[9.5px]">$</span>
                        <input
                          type="text"
                          value={customInvoiceAmount}
                          onChange={(e) => setCustomInvoiceAmount(e.target.value)}
                          className="w-full bg-[#06070a] border border-[#1a1d26] text-white py-1 pl-4 pr-1 rounded text-[9.5px] text-right outline-none"
                          placeholder="Amount"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => handleTriggerInvoice(selectedUser.id)}
                        className="col-span-3 py-1 bg-[#FA1F4E] hover:bg-[#d9143d] text-white font-bold rounded text-[9.5px] uppercase transition-all"
                      >
                        Issue Bill
                      </button>
                    </div>
                  </div>

                  {/* Specific Invoices Ledger */}
                  <div className="space-y-1">
                    <span className="text-[9px] font-bold text-[#8a8d9a] uppercase block">Client Invoices Ledger</span>
                    <div className="max-h-28 overflow-y-auto space-y-1 bg-[#0d0e12] p-2 rounded border border-[#1a1d26]">
                      {selectedUser.invoices && selectedUser.invoices.length > 0 ? (
                        selectedUser.invoices.map((inv, idx) => (
                          <div key={idx} className="flex justify-between items-center text-[9px] border-b border-[#161822] last:border-none pb-1 mt-1 first:mt-0">
                            <div>
                              <span className="text-white font-bold">{inv.id}</span>
                              <span className="text-[#8a8d9a] mx-1">({inv.date})</span>
                              <span className="text-[#3b82f6] uppercase">[{inv.type}]</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <span className="text-white font-bold">${inv.amount.toFixed(2)}</span>
                              <span className={`px-1.5 rounded-[3px] text-[7.5px] font-extrabold ${
                                inv.status === 'PAID'
                                  ? 'bg-[#00e676]/10 text-[#00e676]'
                                  : inv.status === 'WAIVED'
                                  ? 'bg-[#3b82f6]/10 text-[#3b82f6]'
                                  : 'bg-[#ff9800]/10 text-[#ff9800]'
                              }`}>
                                {inv.status}
                              </span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-[#8a8d9a] text-center py-2 text-[9px]">
                          No invoices issued for this client.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Sub-Tab 3: Login Sessions Tracker */}
              {clientSubTab === "logins" && (
                <div className="space-y-2 pt-1 text-[10px]">
                  <span className="text-[9px] font-extrabold text-[#00e676] uppercase block flex items-center gap-1">
                    <Smartphone className="w-3 h-3" />
                    LIVE MOBILE GATEWAY & SESSION REGISTRY (ENCRYPTED)
                  </span>
                  <div className="max-h-56 overflow-y-auto space-y-1.5 bg-[#0d0e12] p-2.5 rounded border border-[#1a1d26]">
                    {selectedUser.logins && selectedUser.logins.length > 0 ? (
                      selectedUser.logins.map((lg, i) => (
                        <div key={i} className="text-[9.5px] border-b border-[#11131c] last:border-none pb-1.5">
                          <div className="flex justify-between">
                            <span className="text-[#8a8d9a]">{lg.timestamp}</span>
                            <span className={`font-bold ${lg.status === 'SUCCESS' ? 'text-[#00e676]' : 'text-[#ef4444]'}`}>
                              {lg.status}
                            </span>
                          </div>
                          <div className="flex justify-between text-white mt-0.5">
                            <span>{lg.device}</span>
                            <span className="text-[#00e5ff]">{lg.ip}</span>
                          </div>
                          <div className="text-[8.5px] text-[#8a8d9a]">{lg.location}</div>
                        </div>
                      ))
                    ) : (
                      <div className="text-[#8a8d9a] text-center py-4 text-[10px]">
                        No active login sessions recorded.
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Provision Lifetime Free VIP Account Creation (lg:span-5) */}
        <div className="lg:col-span-5 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
          <div className="flex items-center gap-2 border-b border-[#11131c] pb-2 text-[#FA1F4E] font-bold text-[10px] uppercase">
            <UserPlus className="w-4 h-4 text-[#FA1F4E]" />
            PROVISION LIFETIME FREE VIP USER
          </div>

          <form onSubmit={handleCreateVIPUser} className="space-y-3">
            <div>
              <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">
                FULL NAME / RECIPIENT NAME:
              </label>
              <input
                type="text"
                placeholder="e.g. Dearest Mother / Sister / Close Friend"
                value={newUserName}
                onChange={(e) => setNewUserName(e.target.value)}
                className="w-full bg-[#06070a] border border-[#1a1d26] hover:border-[#FA1F4E] focus:border-[#FA1F4E] text-white p-2 rounded outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">EMAIL ADDRESS:</label>
                <input
                  type="email"
                  placeholder="name@domain.com"
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  className="w-full bg-[#06070a] border border-[#1a1d26] hover:border-[#FA1F4E] focus:border-[#FA1F4E] text-white p-2 rounded outline-none"
                />
              </div>

              <div>
                <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">PHONE / WHATSAPP:</label>
                <input
                  type="text"
                  placeholder="+1 (555) 000-0000"
                  value={newUserContact}
                  onChange={(e) => setNewUserContact(e.target.value)}
                  className="w-full bg-[#06070a] border border-[#1a1d26] hover:border-[#FA1F4E] focus:border-[#FA1F4E] text-white p-2 rounded outline-none"
                />
              </div>
            </div>

            <div>
              <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">
                ASSIGNMENT PATCH / GROUP:
              </label>
              <select
                value={newUserPatch}
                onChange={(e) => setNewUserPatch(e.target.value as any)}
                className="w-full bg-[#06070a] border border-[#1a1d26] text-white p-2 rounded outline-none text-xs"
              >
                <option value="Family (1st Patch)">1st Patch: Family Members (Mother, Daughters, Siblings)</option>
                <option value="Close Friends (2nd Patch)">2nd Patch: Close Inner Circle Friends</option>
                <option value="Marketing Ambassador (3rd Patch)">3rd Patch: Marketing Ambassadors</option>
              </select>
            </div>

            <div className="p-2.5 bg-[#06070a] border border-[#FA1F4E]/30 rounded text-[9.5px] text-[#00e676] font-bold space-y-1">
              <div className="flex items-center gap-1.5">
                <Gift className="w-3.5 h-3.5 text-[#FA1F4E]" />
                <span>100% NON-BILLED / FREE FOR LIFE GUARANTEE</span>
              </div>
              <div className="text-[9px] text-[#8a8d9a]">
                Automatically attaches VIP Badge & bypasses all future billing checks permanently.
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2 bg-[#FA1F4E] hover:bg-[#d9143d] text-white font-extrabold rounded uppercase transition-all flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(250,31,78,0.3)]"
            >
              <Sparkles className="w-4 h-4" />
              PROVISION VIP USER & GENERATE LETTER
            </button>
          </form>

          {/* Generated Auto Welcome Letter Attachment */}
          {generatedLetter && (
            <div className="space-y-3 pt-3 border-t border-[#11131c] animate-fade-in">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-[#00e5ff] uppercase flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 animate-pulse" />
                  HONORABLE WELCOME LETTER ATTACHMENT
                </span>
                <button
                  onClick={copyLetterToClipboard}
                  className="px-2.5 py-1 bg-[#00e5ff]/10 hover:bg-[#00e5ff] hover:text-black border border-[#00e5ff] text-[#00e5ff] rounded text-[9px] font-bold uppercase transition-all flex items-center gap-1"
                >
                  {copiedLetter ? <Check className="w-3 h-3 text-[#00e676]" /> : <Copy className="w-3 h-3" />}
                  {copiedLetter ? "COPIED" : "COPY LETTER"}
                </button>
              </div>

              {/* High-Tech Channel Selector for Outbound Dispatch */}
              <div className="bg-[#06070a] border border-[#1a1d26] p-2.5 rounded space-y-2 relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-[#00ffcc]/10 text-[#00ffcc] text-[7.5px] font-extrabold px-1.5 py-0.5 rounded-bl uppercase tracking-wider border-l border-b border-[#00ffcc]/20">
                  ⚡ SYSTEM DEFAULT
                </div>
                <div className="flex items-center justify-between text-[8.5px] font-bold text-[#8a8d9a] tracking-wider uppercase">
                  <span>1. CHOOSE SYSTEM OUTBOUND DISPATCH RELAY:</span>
                  <span className="text-[#00ffcc] mr-12">AUTOMATED GATEWAY</span>
                </div>
                <p className="text-[8.5px] text-[#8a8d9a] leading-normal pb-0.5">
                  Standard systematic dispatch. The platform automatically transmits the package using SMTP (Email) or cellular servers:
                </p>
                <div className="grid grid-cols-3 gap-1.5">
                  {(["Email", "SMS", "WhatsApp"] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => !dispatching && setDispatchMethod(method)}
                      className={`py-1.5 rounded font-bold text-[9px] uppercase tracking-wider border transition-all ${
                        dispatchMethod === method
                          ? "bg-[#FA1F4E]/20 text-[#FA1F4E] border-[#FA1F4E]"
                          : "bg-[#0d0e12] text-slate-400 border-slate-900 hover:text-white"
                      }`}
                      disabled={dispatching}
                    >
                      {method} RELAY
                    </button>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={handleDispatchInvitation}
                  disabled={dispatching}
                  className="w-full mt-2.5 py-1.5 bg-[#00e5ff] hover:bg-[#00b2cc] text-black font-extrabold text-[9px] rounded uppercase tracking-widest transition-all flex items-center justify-center gap-1.5 shadow-[0_0_10px_rgba(0,229,255,0.25)] disabled:opacity-50"
                >
                  <Send className={`w-3.5 h-3.5 ${dispatching ? "animate-bounce" : ""}`} />
                  {dispatching ? "DISPATCHING VIP PACKAGE..." : `⚡ RUN DEFAULT SYSTEMATIC DISPATCH VIA ${dispatchMethod}`}
                </button>
              </div>

              {/* Manual Direct Send from Private Number/Device */}
              <div className="bg-[#06070a] border border-[#1a1d26] p-2.5 rounded space-y-2 relative overflow-hidden">
                <div className="absolute top-0 right-0 bg-[#FA1F4E]/10 text-[#FA1F4E] text-[7.5px] font-extrabold px-1.5 py-0.5 rounded-bl uppercase tracking-wider border-l border-b border-[#FA1F4E]/20">
                  📱 OPTIONAL OVERRIDE
                </div>
                <div className="flex items-center justify-between text-[8.5px] font-bold text-[#8a8d9a] tracking-wider uppercase">
                  <span>2. PRIVATE SEND (OVERRIDE FOR FAMILY & FRIENDS):</span>
                  <span className="text-[#FA1F4E] mr-14 animate-pulse">● READY</span>
                </div>
                <p className="text-[8.5px] text-[#8a8d9a] leading-normal pb-0.5">
                  Optional override. Launch WhatsApp, SMS, or Email prefilled on your own mobile or desktop to send directly from your personal account:
                </p>
                <div className="grid grid-cols-3 gap-1.5">
                  <a
                    href={`https://api.whatsapp.com/send?phone=${(selectedUser?.contact || "").replace(/[^0-9+]/g, "")}&text=${encodeURIComponent(generatedLetter || "")}`}
                    target="_blank"
                    rel="noreferrer"
                    className="py-1.5 bg-[#25d366]/10 hover:bg-[#25d366] hover:text-black border border-[#25d366] text-[#25d366] rounded font-bold text-[8.5px] uppercase tracking-wider text-center flex items-center justify-center gap-1 transition-all"
                  >
                    <Smartphone className="w-3 h-3" />
                    WHATSAPP
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>

                  <a
                    href={`sms:${(selectedUser?.contact || "").replace(/[^0-9+]/g, "")}?body=${encodeURIComponent(generatedLetter || "")}`}
                    className="py-1.5 bg-[#007aff]/10 hover:bg-[#007aff] hover:text-white border border-[#007aff] text-[#007aff] rounded font-bold text-[8.5px] uppercase tracking-wider text-center flex items-center justify-center gap-1 transition-all"
                  >
                    <Smartphone className="w-3 h-3" />
                    SMS PROTOCOL
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>

                  <a
                    href={`mailto:${selectedUser?.email || ""}?subject=${encodeURIComponent("💎 Welcome to MEMOBOT FX-PRO™ — Elite VIP Lifetime Access")}&body=${encodeURIComponent(generatedLetter || "")}`}
                    className="py-1.5 bg-[#ff9f0a]/10 hover:bg-[#ff9f0a] hover:text-black border border-[#ff9f0a] text-[#ff9f0a] rounded font-bold text-[8.5px] uppercase tracking-wider text-center flex items-center justify-center gap-1 transition-all"
                  >
                    <Send className="w-3 h-3" />
                    MAIL CLIENT
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </div>
              </div>

              {/* Interactive Dispatch Terminal Log Console */}
              {(dispatchLogs.length > 0 || dispatching) && (
                <div className="bg-black border border-slate-900 rounded p-2.5 space-y-2 font-mono">
                  <div className="flex items-center justify-between text-[8px] text-slate-500 border-b border-slate-950 pb-1">
                    <span className="flex items-center gap-1">
                      <Terminal className="w-3 h-3 text-[#00ffcc]" /> VIP DISPATCH CONSOLE LOGS
                    </span>
                    <span className="animate-pulse text-[#00ffcc] font-bold">● RELAY_CONNECTED</span>
                  </div>
                  <div className="max-h-32 overflow-y-auto space-y-1 text-[8.5px] leading-normal font-mono text-slate-400">
                    {dispatchLogs.map((log, i) => (
                      <div
                        key={i}
                        className={
                          log?.includes("✅")
                            ? "text-[#00e676] font-bold"
                            : log?.includes("🚀")
                            ? "text-[#00e5ff]"
                            : "text-slate-300"
                        }
                      >
                        {log}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <pre className="p-3 bg-[#06070a] border border-[#00e5ff]/30 text-[#00e5ff] rounded text-[9.5px] leading-relaxed whitespace-pre-wrap font-mono">
                {generatedLetter}
              </pre>
            </div>
          )}
        </div>
      </div>

      {/* Trial Invitation Hub Section */}
      <div className="bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-5">
        <div className="flex items-center gap-2 border-b border-[#11131c] pb-2 text-[#00e5ff] font-bold text-[10px] uppercase">
          <Clock className="w-4 h-4 text-[#00e5ff]" />
          TRIAL INVITATION & SANDBOX PASS HUB
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Create Trial Form (col-span-5) */}
          <div className="lg:col-span-5 bg-[#06070a] border border-[#1a1d26] p-4 rounded space-y-3">
            <span className="text-[9.5px] font-extrabold text-[#00e5ff] uppercase block">
              GENERATE NEW SYSTEM TRIAL LICENSE
            </span>
            <p className="text-[8.5px] text-[#8a8d9a] leading-relaxed">
              Provision short-term sandbox authorization keys for prospective clients. These passes grant temporary sandbox trading & API execution telemetry.
            </p>

            <form onSubmit={handleCreateTrialInvitation} className="space-y-3">
              <div>
                <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">
                  RECIPIENT NAME:
                </label>
                <input
                  type="text"
                  placeholder="e.g. Abdullah bin Zayed"
                  value={newTrialName}
                  onChange={(e) => setNewTrialName(e.target.value)}
                  className="w-full bg-[#0d0e12] border border-[#1a1d26] hover:border-[#00e5ff] focus:border-[#00e5ff] text-white p-2 rounded outline-none text-xs"
                />
              </div>

              <div>
                <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">
                  EMAIL OR PHONE / CELLULAR CONTACT:
                </label>
                <input
                  type="text"
                  placeholder="e.g. target.client@gmail.com / +971 50 123 4567"
                  value={newTrialContact}
                  onChange={(e) => setNewTrialContact(e.target.value)}
                  className="w-full bg-[#0d0e12] border border-[#1a1d26] hover:border-[#00e5ff] focus:border-[#00e5ff] text-white p-2 rounded outline-none text-xs"
                />
              </div>

              <div>
                <label className="text-[9px] text-[#8a8d9a] font-bold block mb-1 uppercase">
                  TRIAL ACTIVE TERM DURATION:
                </label>
                <select
                  value={newTrialDuration}
                  onChange={(e) => setNewTrialDuration(e.target.value as any)}
                  className="w-full bg-[#0d0e12] border border-[#1a1d26] text-white p-2 rounded outline-none text-xs cursor-pointer"
                >
                  <option value="24hrs">⚡ 24 Hours Pass (Expedited Sandbox)</option>
                  <option value="3days">🔋 3 Days Pass (Standard Trial)</option>
                  <option value="1week">💎 1 Week Full Term Pass (Premium Trial)</option>
                  <option value="1month">👑 1 Month Elite Ambassador Pass</option>
                </select>
              </div>

              <button
                type="submit"
                disabled={isSubmittingTrial}
                className="w-full mt-2 py-2 bg-[#00e5ff] hover:bg-[#00b2cc] text-black font-extrabold rounded uppercase transition-all flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(0,229,255,0.2)] disabled:opacity-50 text-xs"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {isSubmittingTrial ? "GENERATING PASS..." : "GENERATE AND RECORD TRIAL PASS"}
              </button>
            </form>

            {/* Copyable Trial Invitation Welcome Package */}
            {generatedTrialLetter && (
              <div className="mt-4 pt-3 border-t border-[#1a1d26] space-y-2 animate-fade-in">
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-bold text-[#00e5ff] uppercase flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5" />
                    TRIAL PASS WELCOME KIT
                  </span>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(generatedTrialLetter);
                      setCopiedTrialLetter(true);
                      setTimeout(() => setCopiedTrialLetter(false), 2000);
                    }}
                    className="px-2 py-0.5 bg-[#00e5ff]/10 hover:bg-[#00e5ff] hover:text-black border border-[#00e5ff] text-[#00e5ff] rounded text-[8px] font-bold uppercase transition-all flex items-center gap-1"
                  >
                    {copiedTrialLetter ? <Check className="w-2.5 h-2.5 text-[#00e676]" /> : <Copy className="w-2.5 h-2.5" />}
                    {copiedTrialLetter ? "COPIED" : "COPY LETTER"}
                  </button>
                </div>
                <pre className="bg-[#0d0e12] border border-[#161822] text-[#8a8d9a] p-2.5 rounded text-[8px] font-mono whitespace-pre-wrap select-all max-h-48 overflow-y-auto leading-normal">
                  {generatedTrialLetter}
                </pre>
              </div>
            )}
          </div>

          {/* Trial Audit Ledger (col-span-7) */}
          <div className="lg:col-span-7 bg-[#06070a] border border-[#1a1d26] p-4 rounded space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-[9.5px] font-extrabold text-white uppercase block">
                TRIAL KEY AUDIT RECORD DATABASE
              </span>
              <span className="text-[8px] text-[#8a8d9a] font-bold uppercase">
                TOTAL: {trialInvitations.length} RECORDED
              </span>
            </div>

            <div className="max-h-96 overflow-y-auto space-y-2 pr-1">
              {trialInvitations.length > 0 ? (
                trialInvitations.map((inv) => (
                  <div
                    key={inv.id}
                    className="bg-[#0d0e12] border border-[#161822] hover:border-[#1a1d26] p-3 rounded space-y-2 transition-all"
                  >
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 border-b border-[#11131c] pb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-white font-extrabold font-mono text-xs text-[#00e5ff]">
                          {inv.id}
                        </span>
                        <span className="px-1.5 py-0.5 bg-[#00e5ff]/10 border border-[#00e5ff]/30 text-[#00e5ff] text-[8px] font-extrabold rounded uppercase">
                          {inv.duration}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className={`px-2 py-0.5 rounded text-[8px] font-bold border uppercase ${
                          inv.status === 'ACTIVE'
                            ? 'bg-[#00e676]/10 text-[#00e676] border-[#00e676]/30'
                            : inv.status === 'PENDING'
                            ? 'bg-[#ff9800]/10 text-[#ff9800] border-[#ff9800]/30'
                            : inv.status === 'EXPIRED'
                            ? 'bg-[#8a8d9a]/10 text-[#8a8d9a] border-[#8a8d9a]/30'
                            : 'bg-[#FA1F4E]/10 text-[#FA1F4E] border-[#FA1F4E]/30'
                        }`}>
                          {inv.status}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[9px] leading-normal">
                      <div>
                        <span className="text-[#8a8d9a] block text-[7.5px] uppercase">RECIPIENT CLIENT:</span>
                        <span className="text-white font-bold">{inv.recipientName}</span>
                      </div>
                      <div>
                        <span className="text-[#8a8d9a] block text-[7.5px] uppercase">CONTACT VECTOR:</span>
                        <span className="text-slate-300 font-bold">{inv.recipientContact}</span>
                      </div>
                      <div>
                        <span className="text-[#8a8d9a] block text-[7.5px] uppercase">GENERATION TIMELINE:</span>
                        <span className="text-[#8a8d9a]">{inv.createdAt}</span>
                      </div>
                      <div>
                        <span className="text-[#8a8d9a] block text-[7.5px] uppercase">EXPIRATION SETTLEMENT:</span>
                        <span className="text-[#FA1F4E] font-bold">{inv.expiresAt}</span>
                      </div>
                    </div>

                    {inv.username && inv.password && (
                      <div className="bg-[#06070a] border border-[#161822] p-2 rounded text-[8.5px] font-mono text-[#00e5ff] flex items-center justify-between gap-1 mt-1">
                        <div className="truncate">
                          <span className="text-[#8a8d9a] mr-1">LOGIN ID:</span>
                          <span className="text-white font-bold">{inv.username}</span>
                          <span className="text-[#8a8d9a] mx-2">|</span>
                          <span className="text-[#8a8d9a] mr-1">KEY:</span>
                          <span className="text-[#00e5ff] font-bold">{inv.password}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            navigator.clipboard.writeText(`Access ID: ${inv.username}\nTemporary Password Key: ${inv.password}`);
                            showAlert(`Credentials copied for ${inv.recipientName}!`);
                          }}
                          className="px-1.5 py-0.5 bg-[#00e5ff]/10 hover:bg-[#00e5ff] hover:text-black border border-[#00e5ff]/20 text-[#00e5ff] rounded text-[7.5px] font-bold uppercase transition-all whitespace-nowrap"
                        >
                          COPY LOGINS
                        </button>
                      </div>
                    )}

                    <div className="flex justify-end gap-1.5 pt-1.5 border-t border-[#11131c]">
                      {inv.status === "PENDING" && (
                        <button
                          type="button"
                          onClick={() => handleToggleTrialStatus(inv.id, "ACTIVE")}
                          className="px-2 py-0.5 bg-[#00e676]/10 hover:bg-[#00e676] hover:text-black border border-[#00e676]/30 text-[#00e676] rounded text-[8px] font-bold uppercase transition-all"
                        >
                          Activate Pass
                        </button>
                      )}
                      {(inv.status === "PENDING" || inv.status === "ACTIVE") && (
                        <button
                          type="button"
                          onClick={() => handleToggleTrialStatus(inv.id, "REVOKED")}
                          className="px-2 py-0.5 bg-[#FA1F4E]/10 hover:bg-[#FA1F4E] hover:text-white border border-[#FA1F4E]/30 text-[#FA1F4E] rounded text-[8px] font-bold uppercase transition-all"
                        >
                          Revoke / Suspend
                        </button>
                      )}
                      {inv.status === "REVOKED" && (
                        <button
                          type="button"
                          onClick={() => handleToggleTrialStatus(inv.id, "ACTIVE")}
                          className="px-2 py-0.5 bg-[#00e5ff]/10 hover:bg-[#00e5ff] hover:text-black border border-[#00e5ff]/30 text-[#00e5ff] rounded text-[8px] font-bold uppercase transition-all"
                        >
                          Re-activate Pass
                        </button>
                      )}
                      <span className="text-[8px] text-[#8a8d9a] self-center ml-auto">
                        Invited by: <strong className="text-white font-normal">{inv.invitedBy}</strong>
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-[#8a8d9a] text-center py-10 text-[9.5px]">
                  No active or past sandbox trial invitations recorded in DB state.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
