import React, { useState, useEffect } from "react";
import { Package, CheckCircle2, BarChart3, CreditCard, HeartHandshake, ShieldCheck, Sparkles, Heart, Wallet } from "lucide-react";
import { PersonalPayoutTreasury } from "./PersonalPayoutTreasury";

interface SubscriptionFeesSettingsProps {
  showAlert: (msg: string) => void;
}


function usePersistentState<T>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const [state, setState] = React.useState<T>(() => {
    const saved = localStorage.getItem(key);
    if (saved !== null) {
      try { return JSON.parse(saved); } catch (e) { return saved as any; }
    }
    return initialValue;
  });
  React.useEffect(() => {
    localStorage.setItem(key, JSON.stringify(state));
  }, [key, state]);
  return [state, setState];
}

export const SubscriptionFeesSettings: React.FC<SubscriptionFeesSettingsProps> = ({ showAlert }) => {
const [selectedInclusionTier, setSelectedInclusionTier] = usePersistentState("memobot_sub_selectedInclusionTier", "INCLUSIVE");

  const currentPlan = {
    name: "Proprietary Institutional & Inclusive Tier",
    status: "ACTIVE",
    renewal: "2026-08-22",
    features: [
      "Unlimited Engine Execution",
      "Priority HFT WebSocket Gateway",
      "Shariah Compliance Auditor Pro",
      "Full AI Co-Pilot Suite",
      "Micro-Capital Safeguard Protection"
    ]
  };

  const fees = [
    { id: "INV-0842", date: "2026-07-20", type: "SUCCESS_FEE", amount: 145.20, status: "PAID" },
    { id: "INV-0721", date: "2026-07-01", type: "SUBSCRIPTION", amount: 499.00, status: "PAID" },
    { id: "INV-0615", date: "2026-06-20", type: "SUCCESS_FEE", amount: 88.50, status: "PAID" },
  ];

  const handleExportCSV = () => {
    const csvContent = "data:text/csv;charset=utf-8," + 
      "Invoice ID,Date,Type,Amount,Status\n" + 
      fees.map(f => `${f.id},${f.date},${f.type},${f.amount},${f.status}`).join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "memobot_invoices_ledger.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showAlert("Invoices ledger downloaded as CSV");
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#FA1F4E]/20 pb-3">
        <div className="flex items-center gap-2">
          <CreditCard className="w-4 h-4 text-[#FA1F4E]" />
          <h3 className="text-sm font-extrabold text-[#FA1F4E] uppercase tracking-wider">
            SUBSCRIPTION & FINANCIAL INCLUSION FEES
          </h3>
        </div>
        <span className="text-[10px] text-[#3b82f6] font-bold bg-[#3b82f6]/10 border border-[#3b82f6]/30 px-2.5 py-1 rounded uppercase flex items-center gap-1.5">
          <Heart className="w-3 h-3 text-[#FA1F4E] fill-[#FA1F4E]" />
          UNIVERSAL ACCESSIBILITY ACTIVE
        </span>
      </div>

      {/* Personal Payout & Receiving Treasury (Configurable Wallet Addresses) */}
      <PersonalPayoutTreasury showAlert={showAlert} />

      {/* Universal Financial Purpose & Inclusive Mission Card */}
      <div className="bg-[#0b0d12] border border-[#3b82f6]/30 p-5 rounded-lg space-y-3 shadow-[0_0_20px_rgba(59,130,246,0.08)]">
        <div className="flex items-center justify-between border-b border-[#11141f] pb-2">
          <div className="flex items-center gap-2">
            <HeartHandshake className="w-5 h-5 text-[#3b82f6]" />
            <span className="text-white font-extrabold uppercase tracking-widest text-xs font-mono">
              MEMOBOT™ MISSION: UNIVERSAL FINANCIAL EMPOWERMENT
            </span>
          </div>
          <span className="px-2 py-0.5 bg-[#00e676]/15 text-[#00e676] border border-[#00e676]/40 rounded text-[9px] font-bold uppercase">
            ZERO CAPITAL BARRIER
          </span>
        </div>

        <p className="text-[11px] text-[#3b82f6] font-extrabold uppercase leading-relaxed tracking-wide">
          "FOR EVERY PERSON, EVERY CAPITAL SIZE. MEMOBOT IS DESIGNED TO PROTECT CAPITAL FIRST AND SPREAD HAPPINESS."
        </p>

        <p className="text-[10px] text-[#8a8d9a] leading-relaxed">
          Whether you are investing a small amount—especially high-priority groups like women, elderly, and retired individuals—or managing large institutional portfolios, MemoBot adjusts its execution to safeguard capital and maximize growth without forcing heavy fee barriers.
        </p>

        {/* Interactive Inclusion Tiers Preview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
          <div
            onClick={() => {
              setSelectedInclusionTier("INCLUSIVE");
              showAlert("Switched to Micro-Capital & Senior Inclusive Shield Tier");
            }}
            className={`p-3 rounded border cursor-pointer transition-all ${
              selectedInclusionTier === "INCLUSIVE"
                ? "bg-[#3b82f6]/10 border-[#3b82f6] shadow-[0_0_12px_rgba(59,130,246,0.2)]"
                : "bg-[#06070a] border-[#1a1d26] hover:border-[#333]"
            }`}
          >
            <div className="flex justify-between items-center mb-1">
              <span className="text-[#3b82f6] font-bold text-[10px] uppercase">MICRO & SENIOR SHIELD</span>
              <Sparkles className="w-3.5 h-3.5 text-[#3b82f6]" />
            </div>
            <div className="text-white font-extrabold text-xs">0% PLATFORM FEE</div>
            <p className="text-[9px] text-[#8a8d9a] mt-1">
              Tailored for women, retirees, and small capital accounts. Maximum safety with zero fixed cost.
            </p>
          </div>

          <div
            onClick={() => {
              setSelectedInclusionTier("GROWTH");
              showAlert("Switched to Balanced Capital Growth Tier");
            }}
            className={`p-3 rounded border cursor-pointer transition-all ${
              selectedInclusionTier === "GROWTH"
                ? "bg-[#FA1F4E]/10 border-[#FA1F4E] shadow-[0_0_12px_rgba(250,31,78,0.2)]"
                : "bg-[#06070a] border-[#1a1d26] hover:border-[#333]"
            }`}
          >
            <div className="flex justify-between items-center mb-1">
              <span className="text-[#FA1F4E] font-bold text-[10px] uppercase">BALANCED GROWTH TIER</span>
              <CheckCircle2 className="w-3.5 h-3.5 text-[#FA1F4E]" />
            </div>
            <div className="text-white font-extrabold text-xs">LOW SUCCESS-ONLY FEE</div>
            <p className="text-[9px] text-[#8a8d9a] mt-1">
              For active growing accounts. Fees are only deducted when net profits are achieved and verified.
            </p>
          </div>

          <div
            onClick={() => {
              setSelectedInclusionTier("INSTITUTIONAL");
              showAlert("Switched to Institutional & High Net Worth Tier");
            }}
            className={`p-3 rounded border cursor-pointer transition-all ${
              selectedInclusionTier === "INSTITUTIONAL"
                ? "bg-[#00e676]/10 border-[#00e676] shadow-[0_0_12px_rgba(0,230,118,0.2)]"
                : "bg-[#06070a] border-[#1a1d26] hover:border-[#333]"
            }`}
          >
            <div className="flex justify-between items-center mb-1">
              <span className="text-[#00e676] font-bold text-[10px] uppercase">INSTITUTIONAL PRO</span>
              <ShieldCheck className="w-3.5 h-3.5 text-[#00e676]" />
            </div>
            <div className="text-white font-extrabold text-xs">CUSTOM HFT ROUTING</div>
            <p className="text-[9px] text-[#8a8d9a] mt-1">
              For high capital investors. Dedicated liquidity pools, custom risk limits, and priority latency.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Active Plan Card (lg:span-4) */}
        <div className="lg:col-span-4 bg-[#0d0e12] border border-[#1a1d26] p-5 rounded space-y-4">
          <div className="flex items-center gap-2 border-b border-[#11131c] pb-2">
            <Package className="w-4 h-4 text-[#FA1F4E]" />
            <span className="text-xs text-[#FA1F4E] font-bold uppercase tracking-wider">ACTIVE LICENSE PLAN</span>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="font-bold text-white text-sm">{currentPlan.name}</span>
              <span className="bg-[rgba(0,230,118,0.15)] text-[#00e676] px-2 py-0.5 rounded text-[10px] font-bold border border-[#00e676]">
                {currentPlan.status}
              </span>
            </div>
            
            <div className="bg-[#06070a] p-3 rounded border border-[#1a1d26] space-y-2">
              <div className="flex justify-between text-[10px]">
                <span>NEXT RENEWAL:</span>
                <span className="text-white font-bold">{currentPlan.renewal}</span>
              </div>
              <div className="flex justify-between text-[10px]">
                <span>BILLING MODEL:</span>
                <span className="text-white">FAIR SUCCESS-ONLY & ZERO BARRIER</span>
              </div>
            </div>

            <div className="space-y-1.5 pt-1">
              <span className="text-[10px] font-bold text-[#FA1F4E] block uppercase">INCLUDED CAPABILITIES:</span>
              {currentPlan.features.map((f, i) => (
                <div key={i} className="flex items-center gap-2 text-[10px]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#00e676] shrink-0" />
                  <span>{f}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Success Fee / Invoices Table (lg:span-8) */}
        <div className="lg:col-span-8 bg-[#0d0e12] border border-[#1a1d26] rounded overflow-hidden flex flex-col h-full">
          <div className="bg-[#090a0d] px-4 py-3 border-b border-[#11131c] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-[#FA1F4E]" />
              <span className="text-[10px] text-[#FA1F4E] font-mono font-bold tracking-wider uppercase">
                INVOICE & PERFORMANCE FEE LEDGER
              </span>
            </div>
            <button
              onClick={handleExportCSV}
              className="text-[9px] text-[#3b82f6] hover:underline font-bold uppercase"
            >
              EXPORT DATA (.CSV)
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            <table className="w-full text-left border-collapse text-[10px]">
              <thead>
                <tr className="border-b border-[#11131c] text-[#8a8d9a] uppercase bg-[#06070a]">
                  <th className="py-2.5 px-4 font-semibold">INVOICE ID</th>
                  <th className="py-2.5 px-4 font-semibold">DATE</th>
                  <th className="py-2.5 px-4 font-semibold">FEE TYPE</th>
                  <th className="py-2.5 px-4 font-semibold">AMOUNT (USDT)</th>
                  <th className="py-2.5 px-4 font-semibold">STATUS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1a1d26]">
                {fees.map((fee) => (
                  <tr key={fee.id} className="hover:bg-[#12161f] transition-colors">
                    <td className="py-3 px-4 text-white font-bold">{fee.id}</td>
                    <td className="py-3 px-4">{fee.date}</td>
                    <td className="py-3 px-4">{fee.type}</td>
                    <td className="py-3 px-4 text-white font-bold">${fee.amount.toFixed(2)}</td>
                    <td className="py-3 px-4">
                      <span className="text-[#00e676] font-bold">{fee.status}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="bg-[#090a0d] p-4 border-t border-[#1a1d26] flex justify-between items-center">
            <div className="text-[10px] text-[#8a8d9a]">
              PERFORMANCE FEES ARE COMPUTED WITH CAPITAL PROTECTION SAFEGUARDS ACTIVE.
            </div>
            <button
              onClick={() => showAlert("Payment method update window initialized.")}
              className="px-4 py-1.5 bg-[#3b82f6]/10 border border-[#3b82f6] text-[#3b82f6] hover:bg-[#3b82f6] hover:text-white rounded text-[10px] font-bold uppercase transition-all"
            >
              UPDATE PAYMENT METHOD
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
