import React from "react";
import { Lock, ShieldCheck, CheckCircle2 } from "lucide-react";
import { useLanguage } from "./LanguageProvider";

interface ShariahLockBannerProps {
  className?: string;
}

export const ShariahLockBanner: React.FC<ShariahLockBannerProps> = ({ className = "" }) => {
  const { t } = useLanguage();

  return (
    <div className={`relative overflow-hidden rounded-xl bg-[#0d0e12] border border-[#1a1d26] p-4 shadow-[0_0_20px_rgba(0,0,0,0.4)] ${className}`}>
      {/* Background subtle glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-[#FA1F4E]/5 rounded-full blur-2xl pointer-events-none" />
      
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
        <div className="flex items-center gap-3.5">
          <div className="relative shrink-0">
            <div className="p-2.5 rounded-lg bg-[#06070a] border border-[#1a1d26] text-white">
              <Lock className="w-5 h-5" />
            </div>
            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#FA1F4E] rounded-full" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#FA1F4E]" />
                {t("ISLAMIC SHARIAH MODE ACTIVE")}
              </span>
              <span className="px-2 py-0.5 rounded bg-[#06070a] border border-[#1a1d26] text-white text-[9px] font-bold uppercase tracking-widest">
                {t("PROTECTED BY SHARIAH PROTOCOL")}
              </span>
            </div>
            <p className="text-xs text-[#8a8d9a] font-sans mt-0.5 leading-snug">
              {t("System hard-locked to Spot 1X (0% Interest / 0% Leverage / Halal Assets Only). All trading algorithms, risk triggers, and order routing operate strictly under AAOIFI Islamic standards.")}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 bg-[#06070a] px-3 py-2 rounded-lg border border-[#1a1d26]">
          <CheckCircle2 className="w-4 h-4 text-[#FA1F4E]" />
          <span className="text-[10px] font-mono font-bold text-white uppercase tracking-wider">
            {t("FULL SYSTEM LOCK ACTIVE")}
          </span>
        </div>
      </div>
    </div>
  );
};

