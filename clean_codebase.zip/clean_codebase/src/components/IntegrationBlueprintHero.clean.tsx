import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShieldCheck,
  Lock,
  FileCheck,
  Layers,
  ArrowRight,
  TrendingUp,
  Activity,
  Zap,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  Compass,
  Cpu
} from "lucide-react";
import { useLanguage } from "./LanguageProvider";
import { useTheme } from "./ThemeProvider";

interface NodeDetail {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  badge: string;
  color: string;
  glow: string;
  icon: React.ElementType;
  description: string;
  liveMetric: string;
  metrics: { label: string; value: string }[];
  pathCoords: { startX: number; startY: number; endX: number; endY: number };
}

export const IntegrationBlueprintHero: React.FC<{ onNavigateTo?: (page: string) => void }> = ({ onNavigateTo }) => {
  const [activeNode, setActiveNode] = useState<string>("core");
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [liveOps, setLiveOps] = useState<number>(254820);
  const [pulseTick, setPulseTick] = useState<number>(0);
  const { t } = useLanguage();
  
  let accentColor = "#FA1F4E";
  try {
    const theme = useTheme();
    if (theme?.accentColor) accentColor = theme.accentColor;
  } catch (e) {}

  // Subtle live micro-counter simulation for HFT feel
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveOps((prev) => prev + Math.floor(Math.random() * 19 - 8));
      setPulseTick((prev) => (prev + 1) % 100);
    }, 1200);
    return () => clearInterval(interval);
  }, []);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  const nodes: Record<string, NodeDetail> = {
    strategy: {
      id: "strategy",
      category: "STRATEGY",
      title: "BLUEPRINT",
      subtitle: "9 ACTIVE PAIRS",
      badge: "QUANT ALGO ONLINE",
      color: "#38bdf8", // Electric Sky Blue
      glow: "rgba(56, 189, 248, 0.45)",
      icon: Layers,
      description: "High-frequency algorithmic strategy engine executing micro-breakout and mean-reversion trades across 9 vetted spot pairs.",
      liveMetric: "88.4% Win Confidence",
      metrics: [
        { label: "Active Spot Pairs", value: "BTC, ETH, SOL, XAU, EUR, GBP, XRP, ADA, BNB" },
        { label: "Execution Speed", value: "0.18 ms Average" },
        { label: "Fill Ratio", value: "99.98% Guaranteed" },
      ],
      pathCoords: { startX: 25, startY: 30, endX: 50, endY: 50 },
    },
    risk: {
      id: "risk",
      category: "RISK",
      title: "SHIELD",
      subtitle: "SL/TP ENFORCED",
      badge: "1.5% MAX DD GUARD",
      color: "#FA1F4E", // MemoBot Crimson
      glow: "rgba(250, 31, 78, 0.5)",
      icon: ShieldCheck,
      description: "Autonomous capital protection shield that enforces rigid Stop-Loss/Take-Profit bounds on every millisecond order to guarantee capital safety.",
      liveMetric: "0.00% Unhedged Exposure",
      metrics: [
        { label: "Max Position Risk", value: "1.00% Per Trade" },
        { label: "Slippage Guard", value: "< 0.001% Enforced" },
        { label: "Auto-Kill Switch", value: "Armed & Responsive" },
      ],
      pathCoords: { startX: 25, startY: 55, endX: 50, endY: 50 },
    },
    shariah: {
      id: "shariah",
      category: "SHARIYAH",
      title: "BUREAU",
      subtitle: "COMPLIANT",
      badge: "AAOIFI STANDARD NO.21",
      color: "#00e676", // Islamic Emerald
      glow: "rgba(0, 230, 118, 0.45)",
      icon: CheckCircle2,
      description: "100% Islamic Spot Trading certification ensuring zero interest (Riba), zero overnight swap fees, zero margin leverage loans, and instant physical spot handshake.",
      liveMetric: "0 Riba / 0 Swap Fees",
      metrics: [
        { label: "Riba / Interest Rate", value: "0.00% (Strictly Forbidden)" },
        { label: "Overnight Swap", value: "0.00 USD" },
        { label: "Handshake Protocol", value: "Instant Spot Handshake" },
      ],
      pathCoords: { startX: 25, startY: 80, endX: 50, endY: 50 },
    },
    core: {
      id: "core",
      category: "QUANTUM HFT",
      title: "CENTRAL ENGINES STATION",
      subtitle: "SYSTEM CORE",
      badge: "HFT QUANTUM ENGINE v4.2",
      color: "#FA1F4E",
      glow: "rgba(250, 31, 78, 0.6)",
      icon: Cpu,
      description: "The neural nerve center of Memobot FX-Pro™. Orchestrates live sub-millisecond execution routes, dynamic liquidity depth, and instant compliance audits.",
      liveMetric: `${liveOps.toLocaleString()} Ops/Sec`,
      metrics: [
        { label: "Throughput", value: `${liveOps.toLocaleString()} Ops/Sec` },
        { label: "Uptime SLA", value: "99.999% Institutional" },
        { label: "Latency", value: "0.18ms Sub-Millisecond" },
      ],
      pathCoords: { startX: 50, startY: 50, endX: 50, endY: 50 },
    },
    market: {
      id: "market",
      category: "PAPER",
      title: "TRADE",
      subtitle: "LIVE DEPTH ON",
      badge: "MULTI-EXCHANGE L2",
      color: "#f59e0b", // Amber Gold
      glow: "rgba(245, 158, 11, 0.45)",
      icon: Compass,
      description: "Direct L2/L3 orderbook depth stream connected to tier-1 liquidity venues for optimal bid/ask fill execution.",
      liveMetric: "50 Level Orderbook Depth",
      metrics: [
        { label: "Orderbook Layers", value: "50 Level Depth" },
        { label: "Global Ping", value: "< 8ms Ultra-Fast" },
        { label: "Liquidity Access", value: "$4.2B Institutional" },
      ],
      pathCoords: { startX: 75, startY: 30, endX: 50, endY: 50 },
    },
    vault: {
      id: "vault",
      category: "VAULT",
      title: "SECURITY",
      subtitle: "FERNET ACTIVE",
      badge: "AES-256 ENCRYPTED",
      color: "#a855f7", // Neon Purple
      glow: "rgba(168, 85, 247, 0.45)",
      icon: Lock,
      description: "Cryptographic Fernet key storage and HSM hardware isolation preserving user credentials and transaction logs.",
      liveMetric: "HSM Hardware Isolated",
      metrics: [
        { label: "Encryption Grade", value: "AES-256-GCM + Fernet" },
        { label: "Key Storage", value: "Hardware Isolation" },
        { label: "Audit State", value: "Zero Leak Verified" },
      ],
      pathCoords: { startX: 75, startY: 55, endX: 50, endY: 50 },
    },
    audit: {
      id: "audit",
      category: "AUDITING",
      title: "HUB",
      subtitle: "LOGS MONITOR",
      badge: "IMMUTABLE LEDGER",
      color: "#ff6d00", // Bright Orange
      glow: "rgba(255, 109, 0, 0.45)",
      icon: FileCheck,
      description: "Real-time cryptographically hashed telemetry logger tracking every buy/sell order, indicator snapshot, and execution timestamp.",
      liveMetric: "100% Correlation ID Linked",
      metrics: [
        { label: "Ledger Type", value: "Immutable Cryptographic" },
        { label: "Traceability", value: "100% Correlation ID Linked" },
        { label: "Export Formats", value: "PDF, Word, Excel, Email" },
      ],
      pathCoords: { startX: 75, startY: 80, endX: 50, endY: 50 },
    },
  };

  const selectedNode = nodes[activeNode] || nodes["core"];

  return (
    <div
      onMouseMove={handleMouseMove}
      className="relative bg-[#07090f]/95 border border-[#181d2a] rounded-2xl p-4 sm:p-6 font-mono overflow-hidden shadow-2xl select-none transition-all"
      style={{ boxShadow: '0 4px 24px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,255,255,0.03)' }}
    >
      {/* Dynamic Cursor Reactive Spotlight Glow */}
      <div
        className="pointer-events-none absolute -inset-px opacity-30 transition-opacity duration-300"
        style={{
          background: `radial-gradient(600px circle at ${mousePos.x}px ${mousePos.y}px, ${accentColor}20, transparent 70%)`,
        }}
      />

      {/* Futuristic Blueprint Coordinate Grid & Corner Reticles */}
      <div className="absolute inset-0 bg-[radial-gradient(#141a2e_1.2px,transparent_1.2px)] [background-size:20px_20px] opacity-35 pointer-events-none" />
      <div className="absolute top-3 left-3 w-3 h-3 border-t-2 border-l-2 pointer-events-none" style={{ borderColor: `${accentColor}40` }} />
      <div className="absolute top-3 right-3 w-3 h-3 border-t-2 border-r-2 pointer-events-none" style={{ borderColor: `${accentColor}40` }} />
      <div className="absolute bottom-3 left-3 w-3 h-3 border-b-2 border-l-2 pointer-events-none" style={{ borderColor: `${accentColor}40` }} />
      <div className="absolute bottom-3 right-3 w-3 h-3 border-b-2 border-r-2 pointer-events-none" style={{ borderColor: `${accentColor}40` }} />

      {/* Top Banner Row */}
      <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-[#141724] pb-4 mb-5">
        <div className="flex items-center gap-3.5">
          {/* Frameless Floating Brand Emblem */}
          <div className="shrink-0 flex items-center justify-center relative">
            <img
              src="/MemoBot.png"
              alt="MemoBot Logo"
              style={{ filter: `drop-shadow(0 0 16px ${accentColor}95)` }}
              className="h-11 w-auto object-contain mix-blend-screen hover:scale-105 transition-transform"
            />
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base sm:text-lg font-black tracking-widest text-white uppercase font-aquire">
                {t("INTEGRATION BLUEPRINT")}
              </h2>
              <span 
                style={{
                  color: accentColor,
                  borderColor: `${accentColor}40`,
                  backgroundColor: `${accentColor}15`,
                  boxShadow: `0 0 10px ${accentColor}20`
                }}
                className="px-2.5 py-0.5 text-[9px] font-black border rounded flex items-center gap-1.5 uppercase"
              >
                <span className="w-1.5 h-1.5 rounded-full animate-ping" style={{ backgroundColor: accentColor }} />
                {t("QUANTUM HFT ACTIVE")}
              </span>
            </div>
            <p className="text-[11.5px] text-[#7d8294] mt-0.5 font-sans">
              {t("Welcome to MEMOBOT FX-PRO™ — Trading in a certified 100% Shariah Spot & Capital Safeguarded financial ecosystem.")}
            </p>
          </div>
        </div>

        {/* Shariah Certified Active Badge */}
        <button
          onClick={() => {
            setActiveNode("shariah");
            if (onNavigateTo) onNavigateTo("shariyah-bureau");
          }}
          style={{
            borderColor: `${accentColor}50`,
            backgroundColor: `${accentColor}15`,
            color: "#ffffff",
            boxShadow: `0 0 16px ${accentColor}20`
          }}
          className="flex items-center gap-2 px-4 py-2 border font-extrabold text-xs rounded-xl transition-all cursor-pointer group shrink-0"
        >
          <span className="font-mono tracking-wider">{t("SHARIYAH CERTIFIED")}</span>
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: accentColor, boxShadow: `0 0 8px ${accentColor}` }} />
        </button>
      </div>

      {/* Main Interactive Matrix (Left Satellites + Center Quantum Reactor + Right Satellites) */}
      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-4 lg:gap-5 items-center my-3">
        {/* SVG Synaptic Circuit Traces (Desktop Vector Flow) */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none hidden lg:block z-0"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <filter id="glow-hero" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Left Wing to Center Synaptic Lines */}
          <path
            d="M 270 65 C 330 65, 330 140, 390 140"
            fill="none"
            stroke={activeNode === "strategy" ? "#38bdf8" : "#1e2436"}
            strokeWidth={activeNode === "strategy" ? "2" : "1"}
            strokeDasharray={activeNode === "strategy" ? "6 3" : "none"}
            filter={activeNode === "strategy" ? "url(#glow-hero)" : undefined}
            className="transition-all duration-300"
          />
          <path
            d="M 270 140 L 390 140"
            fill="none"
            stroke={activeNode === "risk" ? "#FA1F4E" : "#1e2436"}
            strokeWidth={activeNode === "risk" ? "2" : "1"}
            strokeDasharray={activeNode === "risk" ? "6 3" : "none"}
            filter={activeNode === "risk" ? "url(#glow-hero)" : undefined}
            className="transition-all duration-300"
          />
          <path
            d="M 270 215 C 330 215, 330 140, 390 140"
            fill="none"
            stroke={activeNode === "shariah" ? "#00e676" : "#1e2436"}
            strokeWidth={activeNode === "shariah" ? "2" : "1"}
            strokeDasharray={activeNode === "shariah" ? "6 3" : "none"}
            filter={activeNode === "shariah" ? "url(#glow-hero)" : undefined}
            className="transition-all duration-300"
          />

          {/* Right Wing to Center Synaptic Lines */}
          <path
            d="M 720 65 C 660 65, 660 140, 600 140"
            fill="none"
            stroke={activeNode === "market" ? "#f59e0b" : "#1e2436"}
            strokeWidth={activeNode === "market" ? "2" : "1"}
            strokeDasharray={activeNode === "market" ? "6 3" : "none"}
            filter={activeNode === "market" ? "url(#glow-hero)" : undefined}
            className="transition-all duration-300"
          />
          <path
            d="M 720 140 L 600 140"
            fill="none"
            stroke={activeNode === "vault" ? "#a855f7" : "#1e2436"}
            strokeWidth={activeNode === "vault" ? "2" : "1"}
            strokeDasharray={activeNode === "vault" ? "6 3" : "none"}
            filter={activeNode === "vault" ? "url(#glow-hero)" : undefined}
            className="transition-all duration-300"
          />
          <path
            d="M 720 215 C 660 215, 660 140, 600 140"
            fill="none"
            stroke={activeNode === "audit" ? "#ff6d00" : "#1e2436"}
            strokeWidth={activeNode === "audit" ? "2" : "1"}
            strokeDasharray={activeNode === "audit" ? "6 3" : "none"}
            filter={activeNode === "audit" ? "url(#glow-hero)" : undefined}
            className="transition-all duration-300"
          />
        </svg>

        {/* ================= LEFT WING SATELLITE NODES ================= */}
        <div className="lg:col-span-3 space-y-2.5 z-10">
          {/* Strategy Blueprint */}
          <div
            onClick={() => setActiveNode("strategy")}
            className={`cursor-pointer p-3.5 rounded-xl border transition-all duration-300 relative group overflow-hidden ${
              activeNode === "strategy"
                ? "bg-[#091524] border-[#38bdf8] shadow-[0_0_24px_rgba(56,189,248,0.35)] scale-[1.02]"
                : "bg-[#080a12]/90 border-[#181d2a] hover:border-[#38bdf8]/60 hover:bg-[#0c121e]"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] text-[#38bdf8] font-black uppercase tracking-wider">{t("STRATEGY")}</span>
              <span className={`w-2 h-2 rounded-full ${activeNode === "strategy" ? "bg-[#38bdf8] shadow-[0_0_8px_#38bdf8] animate-pulse" : "bg-slate-600"}`} />
            </div>
            <div className="text-sm font-black text-white mt-0.5 uppercase tracking-wide">{t("BLUEPRINT")}</div>
            <div className="flex items-center justify-between text-[9.5px] mt-1 text-[#8a8d9a]">
              <span>{t("9 ACTIVE PAIRS")}</span>
              <span className="text-[#38bdf8] font-bold">88.4% WR</span>
            </div>
          </div>

          {/* Risk Shield */}
          <div
            onClick={() => setActiveNode("risk")}
            className={`cursor-pointer p-3.5 rounded-xl border transition-all duration-300 relative group overflow-hidden ${
              activeNode === "risk"
                ? "bg-[#1f090e] border-[#FA1F4E] shadow-[0_0_24px_rgba(250,31,78,0.35)] scale-[1.02]"
                : "bg-[#080a12]/90 border-[#181d2a] hover:border-[#FA1F4E]/60 hover:bg-[#18090d]"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] text-[#FA1F4E] font-black uppercase tracking-wider">{t("RISK")}</span>
              <span className={`w-2 h-2 rounded-full ${activeNode === "risk" ? "bg-[#FA1F4E] shadow-[0_0_8px_#FA1F4E] animate-ping" : "bg-slate-600"}`} />
            </div>
            <div className="text-sm font-black text-white mt-0.5 uppercase tracking-wide">{t("SHIELD")}</div>
            <div className="flex items-center justify-between text-[9.5px] mt-1 text-[#8a8d9a]">
              <span>{t("SL/TP ENFORCED")}</span>
              <span className="text-[#FA1F4E] font-bold">MAX 1.5%</span>
            </div>
          </div>

          {/* Shariyah Bureau */}
          <div
            onClick={() => setActiveNode("shariah")}
            className={`cursor-pointer p-3.5 rounded-xl border transition-all duration-300 relative group overflow-hidden ${
              activeNode === "shariah"
                ? "bg-[#061810] border-[#00e676] shadow-[0_0_24px_rgba(0,230,118,0.35)] scale-[1.02]"
                : "bg-[#080a12]/90 border-[#181d2a] hover:border-[#00e676]/60 hover:bg-[#08150f]"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] text-[#00e676] font-black uppercase tracking-wider">{t("SHARIYAH")}</span>
              <span className={`w-2 h-2 rounded-full ${activeNode === "shariah" ? "bg-[#00e676] shadow-[0_0_8px_#00e676] animate-pulse" : "bg-slate-600"}`} />
            </div>
            <div className="text-sm font-black text-white mt-0.5 uppercase tracking-wide">{t("BUREAU")}</div>
            <div className="flex items-center justify-between text-[9.5px] mt-1 text-[#8a8d9a]">
              <span>{t("COMPLIANT")}</span>
              <span className="text-[#00e676] font-bold">0 RIBA</span>
            </div>
          </div>
        </div>

        {/* ================= CENTER QUANTUM REACTOR CORE ================= */}
        <div className="lg:col-span-6 flex flex-col items-center justify-center p-1 z-10">
          <div
            onClick={() => setActiveNode("core")}
            className={`cursor-pointer w-full p-6 sm:p-7 rounded-2xl border-2 transition-all duration-300 text-center relative overflow-hidden group ${
              activeNode === "core"
                ? "bg-gradient-to-b from-[#18060b] via-[#0a0507] to-[#120508] border-[#FA1F4E] shadow-[0_0_60px_rgba(250,31,78,0.45)] scale-[1.01]"
                : "bg-[#080a12]/95 border-[#FA1F4E]/40 hover:border-[#FA1F4E] hover:shadow-[0_0_35px_rgba(250,31,78,0.25)]"
            }`}
          >
            {/* Ambient Animated Energy Rings Behind Core */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
              <div className="w-64 h-64 rounded-full border border-dashed border-[#FA1F4E] animate-spin" style={{ animationDuration: "35s" }} />
              <div className="absolute w-48 h-48 rounded-full border border-[#00e5ff]/30 animate-spin" style={{ animationDuration: "20s", animationDirection: "reverse" }} />
            </div>

            <div className="relative z-10 space-y-3">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1 bg-[#FA1F4E]/15 border border-[#FA1F4E]/60 rounded-full text-[#FA1F4E] text-[9.5px] font-black uppercase tracking-widest shadow-[0_0_12px_rgba(250,31,78,0.3)]">
                <Cpu className="w-3.5 h-3.5 animate-spin text-[#FA1F4E]" />
                <span>{t("SYSTEM CORE")}</span>
              </div>

              {/* Central Title */}
              <h3 className="text-xl sm:text-2xl font-black text-white tracking-widest uppercase font-aquire drop-shadow-[0_0_14px_rgba(255,255,255,0.4)]">
                {t("CENTRAL ENGINES STATION")}
              </h3>

              <p className="text-xs text-[#8a8d9a] max-w-md mx-auto font-sans leading-relaxed">
                {t("Autonomous Multi-Engine Quant Station coordinating high-frequency trades, capital safeguards, and instant compliance audits.")}
              </p>

              {/* Dynamic HUD Metric Pills */}
              <div className="pt-2 flex flex-wrap items-center justify-center gap-2">
                <div className="px-3 py-1 bg-[#05060b] border border-[#1b202e] text-white text-[9.5px] font-bold rounded-lg flex items-center gap-1.5 shadow-inner">
                  <Activity className="w-3 h-3 text-[#FA1F4E]" />
                  <span>{t("0.18ms LATENCY")}</span>
                </div>
                <div className="px-3 py-1 bg-[#05060b] border border-[#1b202e] text-white text-[9.5px] font-bold rounded-lg flex items-center gap-1.5 shadow-inner">
                  <ShieldCheck className="w-3 h-3 text-[#00e676]" />
                  <span>{t("100% CAPITAL PROTECTED")}</span>
                </div>
                <div className="px-3 py-1 bg-[#05060b] border border-[#1b202e] text-white text-[9.5px] font-bold rounded-lg flex items-center gap-1.5 shadow-inner">
                  <Zap className="w-3 h-3 text-[#38bdf8]" />
                  <span>{t("L2 LIQUIDITY DIRECT")}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ================= RIGHT WING SATELLITE NODES ================= */}
        <div className="lg:col-span-3 space-y-2.5 z-10">
          {/* Paper Trade */}
          <div
            onClick={() => setActiveNode("market")}
            className={`cursor-pointer p-3.5 rounded-xl border transition-all duration-300 relative group overflow-hidden ${
              activeNode === "market"
                ? "bg-[#1c1407] border-[#f59e0b] shadow-[0_0_24px_rgba(245,158,11,0.35)] scale-[1.02]"
                : "bg-[#080a12]/90 border-[#181d2a] hover:border-[#f59e0b]/60 hover:bg-[#140f06]"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] text-[#f59e0b] font-black uppercase tracking-wider">{t("PAPER")}</span>
              <span className={`w-2 h-2 rounded-full ${activeNode === "market" ? "bg-[#f59e0b] shadow-[0_0_8px_#f59e0b] animate-pulse" : "bg-slate-600"}`} />
            </div>
            <div className="text-sm font-black text-white mt-0.5 uppercase tracking-wide">{t("TRADE")}</div>
            <div className="flex items-center justify-between text-[9.5px] mt-1 text-[#8a8d9a]">
              <span>{t("LIVE DEPTH ON")}</span>
              <span className="text-[#f59e0b] font-bold">50-L2</span>
            </div>
          </div>

          {/* Vault Security */}
          <div
            onClick={() => setActiveNode("vault")}
            className={`cursor-pointer p-3.5 rounded-xl border transition-all duration-300 relative group overflow-hidden ${
              activeNode === "vault"
                ? "bg-[#1a0c26] border-[#a855f7] shadow-[0_0_24px_rgba(168,85,247,0.35)] scale-[1.02]"
                : "bg-[#080a12]/90 border-[#181d2a] hover:border-[#a855f7]/60 hover:bg-[#13091c]"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] text-[#a855f7] font-black uppercase tracking-wider">{t("VAULT")}</span>
              <span className={`w-2 h-2 rounded-full ${activeNode === "vault" ? "bg-[#a855f7] shadow-[0_0_8px_#a855f7] animate-pulse" : "bg-slate-600"}`} />
            </div>
            <div className="text-sm font-black text-white mt-0.5 uppercase tracking-wide">{t("SECURITY")}</div>
            <div className="flex items-center justify-between text-[9.5px] mt-1 text-[#8a8d9a]">
              <span>{t("FERNET ACTIVE")}</span>
              <span className="text-[#a855f7] font-bold">AES-256</span>
            </div>
          </div>

          {/* Auditing Hub */}
          <div
            onClick={() => setActiveNode("audit")}
            className={`cursor-pointer p-3.5 rounded-xl border transition-all duration-300 relative group overflow-hidden ${
              activeNode === "audit"
                ? "bg-[#210e05] border-[#ff6d00] shadow-[0_0_24px_rgba(255,109,0,0.35)] scale-[1.02]"
                : "bg-[#080a12]/90 border-[#181d2a] hover:border-[#ff6d00]/60 hover:bg-[#170a04]"
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[9px] text-[#ff6d00] font-black uppercase tracking-wider">{t("AUDITING")}</span>
              <span className={`w-2 h-2 rounded-full ${activeNode === "audit" ? "bg-[#ff6d00] shadow-[0_0_8px_#ff6d00] animate-pulse" : "bg-slate-600"}`} />
            </div>
            <div className="text-sm font-black text-white mt-0.5 uppercase tracking-wide">{t("HUB")}</div>
            <div className="flex items-center justify-between text-[9.5px] mt-1 text-[#8a8d9a]">
              <span>{t("LOGS MONITOR")}</span>
              <span className="text-[#ff6d00] font-bold">100% AUDIT</span>
            </div>
          </div>
        </div>
      </div>

      {/* ================= TELEMETRY INSPECTOR DRAWER ================= */}
      <AnimatePresence mode="wait">
        <motion.div
          key={selectedNode.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.2 }}
          className="relative z-10 mt-5 bg-[#080a12] border border-[#181d2a] p-4 sm:p-5 rounded-2xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 shadow-lg"
          style={{ boxShadow: '0 4px 20px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)' }}
        >
          <div className="flex items-start gap-3.5 flex-1">
            {/* Frameless MemoBot Emblem */}
            <div className="shrink-0 mt-0.5 flex items-center justify-center">
              <img
                src="/MemoBot.png"
                alt="MemoBot Module Emblem"
                style={{ filter: `drop-shadow(0 0 14px ${accentColor}95)` }}
                className="h-9 w-auto object-contain mix-blend-screen"
              />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-white font-black text-xs uppercase tracking-wider font-aquire">
                  {t(selectedNode.title)}
                </span>
                <span className="text-[9.5px] text-[#8a8d9a] font-bold">[{t(selectedNode.subtitle)}]</span>
                <span
                  className="px-2 py-0.5 text-[8.5px] font-black rounded uppercase border"
                  style={{
                    color: selectedNode.color,
                    borderColor: `${selectedNode.color}60`,
                    backgroundColor: `${selectedNode.color}18`,
                    boxShadow: `0 0 10px ${selectedNode.glow}`,
                  }}
                >
                  {t(selectedNode.badge)}
                </span>
              </div>
              <p className="text-xs text-[#8a8d9a] mt-1 font-sans leading-relaxed">{t(selectedNode.description)}</p>
            </div>
          </div>

          {/* Granular Key Metrics */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0 self-stretch lg:self-center justify-end">
            {selectedNode.metrics.map((m, idx) => (
              <div key={idx} className="bg-[#05060b] border border-[#1b202e] px-3 py-1.5 rounded-xl text-left shadow-inner">
                <span className="text-[8.5px] text-[#7d8294] block font-bold uppercase">{t(m.label)}</span>
                <span className="text-white font-black text-[10px]">{t(m.value)}</span>
              </div>
            ))}

            {onNavigateTo && (
              <button
                onClick={() => {
                  if (selectedNode.id === "audit") onNavigateTo("audit");
                  else if (selectedNode.id === "vault") onNavigateTo("secure-vault");
                  else if (selectedNode.id === "strategy") onNavigateTo("strategies");
                  else if (selectedNode.id === "shariah") onNavigateTo("secure-vault");
                  else if (selectedNode.id === "risk") onNavigateTo("live-positions");
                  else if (selectedNode.id === "market") onNavigateTo("market-intel");
                  else onNavigateTo("engines");
                }}
                style={{
                  backgroundColor: accentColor,
                  boxShadow: `0 0 16px ${accentColor}40`
                }}
                className="px-4 py-2.5 text-white rounded-xl text-[10px] font-black uppercase transition-all flex items-center gap-1.5 cursor-pointer active:scale-98"
              >
                <span>{t("INSPECT MODULE")}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Bottom Reassurance Footer Bar */}
      <div className="relative z-10 mt-4 border-t border-[#141724] pt-3 flex flex-col sm:flex-row items-center justify-between text-[10px] text-[#7d8294] gap-2">
        <div className="flex items-center gap-2 font-bold">
          <Activity className="w-3.5 h-3.5" style={{ color: accentColor }} />
          <span>{t("PROFIT ASSURANCE ENGINE ACTIVE: ZERO SLIPPAGE & CAPITAL SAFEGUARD GUARANTEED")}</span>
        </div>
        <div className="flex items-center gap-4 text-[9px] font-mono">
          <span>{t("INSTITUTIONAL ENCRYPTION:")} <strong className="text-white">AES-256</strong></span>
          <span>{t("WEBSOCKET PING:")} <strong className="text-white">0.18ms</strong></span>
        </div>
      </div>
    </div>
  );
};

export default IntegrationBlueprintHero;
