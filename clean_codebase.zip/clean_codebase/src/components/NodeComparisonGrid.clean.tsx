import React, { useState } from "react";
import {
  Zap,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Cpu,
  Layers,
  Award,
  Globe,
  TrendingUp,
  Sliders,
  Check,
  XCircle,
  HelpCircle,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { useLanguage } from "../components/LanguageProvider";

export interface CompetitorNode {
  id: string;
  name: string;
  category: string;
  tagline: string;
  overallScore: number; // 0-100
  latencyMs: number;
  shariahCompliant: boolean;
  shariahStandard: string;
  capitalProtectionType: string;
  swarmCapability: string;
  auditTrailType: string;
  badge: string;
  color: string;
  highlightPillars: string[];
  vulnerabilities: string[];
}

const COMPARISON_NODES: CompetitorNode[] = [
  {
    id: "memobot",
    name: "MEMOBOT FX-PRO™",
    category: "QUANTUM HFT SPOT",
    tagline: "Autonomous Multi-Engine AI Swarm & Institutional Execution Core",
    overallScore: 99.8,
    latencyMs: 0.18,
    shariahCompliant: true,
    shariahStandard: "100% Certified AAOIFI-21 (Zero Riba, Zero Overnight Swap, Direct Spot)",
    capitalProtectionType: "Hard SL/TP Guaranteed Execution with Autonomous Risk Interceptor",
    swarmCapability: "Decentralized Multi-Engine Swarm (Sirius, Regulus, Algol, Canopus)",
    auditTrailType: "Cryptographic Immutable Ledger with SHA-256 Hashes & Universal Print",
    badge: "⭐ APEX LEADER (TIER 1)",
    color: "#FA1F4E",
    highlightPillars: [
      "Sub-ms 0.18ms FIX L2 Direct Routing",
      "Strict 100% Spot Asset Delivery (No CFD/Debt)",
      "Zero-Latency WebSocket Orderbook Depth",
      "Export to Word, Excel, PDF & TXT with Hashes"
    ],
    vulnerabilities: []
  },
  {
    id: "bloomberg",
    name: "Bloomberg B-PIPE / EMSX",
    category: "Institutional Terminal",
    tagline: "Traditional Wall Street Order Management & Fixed Income Terminal",
    overallScore: 82.4,
    latencyMs: 2.40,
    shariahCompliant: false,
    shariahStandard: "Manual Asset Vetting (Requires Compliance Officer Manual Sign-off)",
    capitalProtectionType: "Post-Trade Margin Calls & EOD Broker Liquidations",
    swarmCapability: "Centralized Monolithic Desk Infrastructure (No Autonomous Swarm)",
    auditTrailType: "End-of-Day Batch Database SQL Dump & PDF Statements",
    badge: "LEGACY INSTITUTIONAL",
    color: "#3b82f6",
    highlightPillars: [
      "Comprehensive Global Macro News Feed",
      "Deep Fixed-Income Liquidity Pools"
    ],
    vulnerabilities: [
      "Excessive Latency (2.4ms vs 0.18ms Memobot)",
      "No Native Shariah Smart Filter",
      "Extremely High Terminal License Fee ($2,500+/mo)"
    ]
  },
  {
    id: "refinitiv",
    name: "Refinitiv / LSEG REDI",
    category: "Execution Management",
    tagline: "London Stock Exchange Group Broker Smart Routing Matrix",
    overallScore: 79.0,
    latencyMs: 3.10,
    shariahCompliant: false,
    shariahStandard: "Not Available (Standard Commercial Leverage Only)",
    capitalProtectionType: "Broker-Defined Stop Out Thresholds with Potential Slippage",
    swarmCapability: "Rule-Based Smart Order Routing (Single-Node Server)",
    auditTrailType: "Standard Audit Logging to Enterprise SQL",
    badge: "ENTERPRISE DESK",
    color: "#94a3b8",
    highlightPillars: [
      "Extensive Bank Liquidity Networks",
      "G10 Currency Pairs Focus"
    ],
    vulnerabilities: [
      "High Execution Latency (3.10ms)",
      "Lacks Native High-Frequency AI Strategy Optimizers",
      "No Cryptographic Order Integrity Verifier"
    ]
  },
  {
    id: "3commas",
    name: "3Commas Enterprise",
    category: "Retail / Pro Grid Bots",
    tagline: "Cloud Webhook DCA and Grid Trading Automated Platform",
    overallScore: 64.5,
    latencyMs: 450.00,
    shariahCompliant: false,
    shariahStandard: "No Islamic Verification (CFD / Margin bot setups common)",
    capitalProtectionType: "Basic Client-Side Stop Loss (Vulnerable to Cloud Lag & Slippage)",
    swarmCapability: "Single DCA Bot Instances (No Multi-Agent Swarm Logic)",
    auditTrailType: "Cloud Web Session History (Prone to Data Loss)",
    badge: "RETAIL BOT",
    color: "#eab308",
    highlightPillars: [
      "User-friendly Grid Bot UI",
      "TradingView Webhook Integration"
    ],
    vulnerabilities: [
      "450ms Extreme Cloud Latency (2500x slower than Memobot)",
      "Severe Slippage During High Volatility Breaches",
      "No Shariah AAOIFI Standard Enforcement"
    ]
  },
  {
    id: "haasonline",
    name: "HaasOnline TradeServer",
    category: "Automated Bot Server",
    tagline: "Self-Hosted HaasScript Algorithmic Server",
    overallScore: 68.2,
    latencyMs: 120.00,
    shariahCompliant: false,
    shariahStandard: "No Islamic Verification (User Script Dependent)",
    capitalProtectionType: "Custom Script Limits (Requires Custom Scripting)",
    swarmCapability: "Local Machine Multi-Process Daemon",
    auditTrailType: "Local Machine CSV File Exports",
    badge: "SCRIPT PLATFORM",
    color: "#a855f7",
    highlightPillars: [
      "Custom Scripting Engine (HaasScript)",
      "Self-Hosted On-Premise Execution"
    ],
    vulnerabilities: [
      "Requires Heavy Local Computing Resources",
      "120ms Latency Bottlenecks on Complex Calculations",
      "No Autonomous Quantum AI Swarm Optimization"
    ]
  },
  {
    id: "metatrader",
    name: "MetaTrader 5 (MT5)",
    category: "Retail Broker Client",
    tagline: "Standard FX Broker Platform for Expert Advisors (EA)",
    overallScore: 71.0,
    latencyMs: 35.00,
    shariahCompliant: true,
    shariahStandard: "Islamic Swap-Free (Subject to Hidden Broker Spread Markups)",
    capitalProtectionType: "Broker Stop-Out with Re-quote Slippage Exposure",
    swarmCapability: "Single-Threaded MQL5 Expert Advisor Script",
    auditTrailType: "Broker Account History File",
    badge: "BROKER CLIENT",
    color: "#06b6d4",
    highlightPillars: [
      "Massive MQL Community Base",
      "Global Broker Availability"
    ],
    vulnerabilities: [
      "Single-Threaded Scripting (No Multi-Engine Swarms)",
      "Hidden Broker Markups on Islamic Accounts",
      "35ms Typical Latency to Broker Bridge"
    ]
  }
];

export const NodeComparisonGrid: React.FC = () => {
  const { t } = useLanguage();
  const [selectedNodeId, setSelectedNodeId] = useState<string>("memobot");
  const [activeComparisonMetric, setActiveComparisonMetric] = useState<
    "ALL" | "LATENCY" | "SHARIAH" | "PROTECTION" | "SWARM"
  >("ALL");

  const selectedNode = COMPARISON_NODES.find((n) => n.id === selectedNodeId) || COMPARISON_NODES[0];
  const memobotNode = COMPARISON_NODES[0];

  return (
    <div className="bg-[#090b11] border border-[#1b1f2e] rounded-2xl p-5 space-y-5 shadow-2xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#141724] pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#38bdf8]/15 border border-[#38bdf8]/50 rounded-xl text-[#38bdf8] shadow-[0_0_15px_rgba(56,189,248,0.3)]">
            <Layers className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-wider font-aquire">
                {t("INTERACTIVE NODE-BASED COMPETITOR MATRIX")}
              </h2>
              <span className="px-2 py-0.5 text-[9px] font-black bg-[#FA1F4E]/15 border border-[#FA1F4E]/50 text-[#FA1F4E] rounded uppercase">
                {t("MEMOBOT VS. 5 MARKET LEADERS")}
              </span>
            </div>
            <p className="text-xs text-[#8a8d9a]">
              {t("Select any platform node to project deep comparative radar telemetry across latency, Shariah compliance, and capital protection.")}
            </p>
          </div>
        </div>

        {/* Metric Filter Tabs */}
        <div className="flex items-center gap-1.5 bg-[#05070a] p-1 border border-[#1e2336] rounded-xl flex-wrap">
          <button
            onClick={() => setActiveComparisonMetric("ALL")}
            className={`px-3 py-1 text-xs font-bold uppercase rounded-lg transition-all cursor-pointer ${
              activeComparisonMetric === "ALL" ? "bg-[#FA1F4E] text-white shadow" : "text-slate-400 hover:text-white"
            }`}
          >
            {t("OVERVIEW")}
          </button>
          <button
            onClick={() => setActiveComparisonMetric("LATENCY")}
            className={`px-3 py-1 text-xs font-bold uppercase rounded-lg transition-all cursor-pointer ${
              activeComparisonMetric === "LATENCY" ? "bg-[#38bdf8] text-black font-black shadow" : "text-slate-400 hover:text-white"
            }`}
          >
            {t("LATENCY (SPEED)")}
          </button>
          <button
            onClick={() => setActiveComparisonMetric("SHARIAH")}
            className={`px-3 py-1 text-xs font-bold uppercase rounded-lg transition-all cursor-pointer ${
              activeComparisonMetric === "SHARIAH" ? "bg-[#00e676] text-black font-black shadow" : "text-slate-400 hover:text-white"
            }`}
          >
            {t("SHARIAH AAOIFI")}
          </button>
          <button
            onClick={() => setActiveComparisonMetric("PROTECTION")}
            className={`px-3 py-1 text-xs font-bold uppercase rounded-lg transition-all cursor-pointer ${
              activeComparisonMetric === "PROTECTION" ? "bg-[#a855f7] text-white font-bold shadow" : "text-slate-400 hover:text-white"
            }`}
          >
            {t("SL/TP GUARD")}
          </button>
        </div>
      </div>

      {/* Interactive Node Grid Selector */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {COMPARISON_NODES.map((node) => {
          const isSelected = selectedNodeId === node.id;
          const isMemobot = node.id === "memobot";

          return (
            <div
              key={node.id}
              onClick={() => setSelectedNodeId(node.id)}
              className={`p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden ${
                isSelected
                  ? isMemobot
                    ? "bg-[#1f090e] border-[#FA1F4E] shadow-[0_0_20px_rgba(250,31,78,0.35)]"
                    : "bg-[#0f172a] border-[#38bdf8] shadow-[0_0_20px_rgba(56,189,248,0.25)]"
                  : "bg-[#0c0f18] border-[#1e2336] hover:border-[#38bdf8]/40"
              }`}
            >
              {isMemobot && (
                <div className="absolute -right-8 -top-8 w-16 h-16 bg-[#FA1F4E]/20 rounded-full blur-xl pointer-events-none" />
              )}

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <span
                    className="text-[8px] font-black uppercase px-1.5 py-0.5 rounded"
                    style={{
                      backgroundColor: `${node.color}20`,
                      color: node.color,
                      border: `1px solid ${node.color}40`,
                    }}
                  >
                    {node.badge}
                  </span>
                  <span className="text-[10px] font-mono font-black text-white">{node.overallScore}%</span>
                </div>

                <h3 className="font-black text-white text-xs leading-snug mt-1">{node.name}</h3>
                <p className="text-[9px] text-slate-400 mt-0.5 truncate">{node.category}</p>
              </div>

              <div className="mt-3 pt-2 border-t border-[#1a1f30] space-y-1">
                <div className="flex justify-between text-[9px]">
                  <span className="text-slate-500">{t("Latency:")}</span>
                  <span className={`font-mono font-bold ${node.latencyMs < 1 ? "text-[#00e676]" : "text-amber-400"}`}>
                    {node.latencyMs}ms
                  </span>
                </div>
                <div className="flex justify-between text-[9px]">
                  <span className="text-slate-500">{t("Halal:")}</span>
                  <span className={node.shariahCompliant ? "text-[#00e676] font-bold" : "text-rose-400"}>
                    {node.shariahCompliant ? "YES (AAOIFI)" : "NO"}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Deep Side-by-Side Node Telemetry Breakdown */}
      <div className="bg-[#05070a] border border-[#1e2336] rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-[#141724] pb-3">
          <div className="flex items-center gap-2.5">
            <span
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: selectedNode.color }}
            />
            <h3 className="text-sm font-black text-white uppercase tracking-wider font-aquire">
              {t("HEAD-TO-HEAD AUDIT:")} <span className="text-[#FA1F4E]">MEMOBOT FX-PRO™</span> vs.{" "}
              <span style={{ color: selectedNode.color }}>{selectedNode.name}</span>
            </h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            {t("Score Gap:")}{" "}
            <strong className="text-[#00e676]">
              +{(memobotNode.overallScore - (selectedNode.id === "memobot" ? 0 : selectedNode.overallScore)).toFixed(1)}% Superiority
            </strong>
          </span>
        </div>

        {/* Matrix Metrics Table */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Left Column: Memobot Apex Node */}
          <div className="bg-[#12070c] border border-[#FA1F4E]/40 p-4 rounded-xl space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-[#FA1F4E] uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                MEMOBOT FX-PRO™ (APEX PLATFORM)
              </span>
              <span className="px-2 py-0.5 bg-[#00e676]/20 border border-[#00e676]/50 text-[#00e676] rounded text-[9px] font-black">
                99.8% TIER 1
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="bg-[#090b11] p-2.5 rounded-lg border border-[#2a121b]">
                <div className="text-[9.5px] text-[#8a8d9a] font-bold uppercase">{t("1. EXECUTION SPEED / LATENCY")}</div>
                <div className="font-mono text-white font-bold text-sm mt-0.5 text-[#00e676]">0.18ms Sub-Millisecond</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Direct L2 FIX connector bypassing all webhooks.</div>
              </div>

              <div className="bg-[#090b11] p-2.5 rounded-lg border border-[#2a121b]">
                <div className="text-[9.5px] text-[#8a8d9a] font-bold uppercase">{t("2. SHARIAH GOVERNANCE")}</div>
                <div className="font-mono text-emerald-300 font-bold text-sm mt-0.5">100% Certified (AAOIFI Standard-21)</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Strict 1:1 spot delivery, zero margin debt, 0 overnight riba.</div>
              </div>

              <div className="bg-[#090b11] p-2.5 rounded-lg border border-[#2a121b]">
                <div className="text-[9.5px] text-[#8a8d9a] font-bold uppercase">{t("3. CAPITAL SL/TP SAFEGUARD")}</div>
                <div className="font-mono text-white font-bold text-sm mt-0.5 text-[#38bdf8]">Autonomous Sub-ms Circuit Breaker</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Hard 0.85% max drawdown guard preventing liquidation.</div>
              </div>

              <div className="bg-[#090b11] p-2.5 rounded-lg border border-[#2a121b]">
                <div className="text-[9.5px] text-[#8a8d9a] font-bold uppercase">{t("4. SWARM ARCHITECTURE")}</div>
                <div className="font-mono text-white font-bold text-sm mt-0.5">Decentralized Multi-Engine Swarm</div>
                <div className="text-[10px] text-slate-400 mt-0.5">Cross-exchange load balancing across 8 synchronized cores.</div>
              </div>
            </div>
          </div>

          {/* Right Column: Selected Competitor Node */}
          <div className="bg-[#0c0f18] border border-[#1e2336] p-4 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-black text-white uppercase tracking-wider">
                {selectedNode.name}
              </span>
              <span
                className="px-2 py-0.5 rounded text-[9px] font-black"
                style={{
                  backgroundColor: `${selectedNode.color}20`,
                  color: selectedNode.color,
                  border: `1px solid ${selectedNode.color}50`,
                }}
              >
                {selectedNode.overallScore}% RATING
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="bg-[#05070a] p-2.5 rounded-lg border border-[#1e2336]">
                <div className="text-[9.5px] text-[#8a8d9a] font-bold uppercase">{t("1. EXECUTION SPEED / LATENCY")}</div>
                <div className="font-mono text-white font-bold text-sm mt-0.5">{selectedNode.latencyMs}ms</div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {selectedNode.latencyMs > 100
                    ? "Severe retail latency bottleneck subject to severe slippage."
                    : "Standard institutional latency (10x-20x slower than Memobot)."}
                </div>
              </div>

              <div className="bg-[#05070a] p-2.5 rounded-lg border border-[#1e2336]">
                <div className="text-[9.5px] text-[#8a8d9a] font-bold uppercase">{t("2. SHARIAH GOVERNANCE")}</div>
                <div className="font-mono text-slate-300 font-bold text-sm mt-0.5">{selectedNode.shariahStandard}</div>
              </div>

              <div className="bg-[#05070a] p-2.5 rounded-lg border border-[#1e2336]">
                <div className="text-[9.5px] text-[#8a8d9a] font-bold uppercase">{t("3. CAPITAL SL/TP SAFEGUARD")}</div>
                <div className="font-mono text-slate-300 font-bold text-sm mt-0.5">{selectedNode.capitalProtectionType}</div>
              </div>

              <div className="bg-[#05070a] p-2.5 rounded-lg border border-[#1e2336]">
                <div className="text-[9.5px] text-[#8a8d9a] font-bold uppercase">{t("4. SWARM ARCHITECTURE")}</div>
                <div className="font-mono text-slate-300 font-bold text-sm mt-0.5">{selectedNode.swarmCapability}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NodeComparisonGrid;
