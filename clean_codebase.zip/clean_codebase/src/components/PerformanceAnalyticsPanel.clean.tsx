import React, { useState } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Cell,
  Legend,
  RadialBarChart,
  RadialBar
} from "recharts";
import {
  TrendingUp,
  Activity,
  ShieldCheck,
  Zap,
  Award,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  Layers,
  ChevronDown
} from "lucide-react";
import { useLanguage } from "../components/LanguageProvider";

interface StrategyMetric {
  name: string;
  category: string;
  winRate: number; // 0-100%
  winLossRatio: number; // e.g. 3.4
  maxDrawdown: number; // % e.g. 1.8%
  profitFactor: number;
  tradesCount: number;
  efficiencyScore: number; // 0-100
  latencyMs: number;
  color: string;
}

const STRATEGY_DATA: StrategyMetric[] = [
  {
    name: "ALPHA BREAKOUT v4.2",
    category: "MOMENTUM SPOT",
    winRate: 84.6,
    winLossRatio: 3.42,
    maxDrawdown: 1.25,
    profitFactor: 4.15,
    tradesCount: 1420,
    efficiencyScore: 98.4,
    latencyMs: 0.18,
    color: "#FA1F4E",
  },
  {
    name: "MEAN REVERSION ALPHA",
    category: "STAT-ARB SPOT",
    winRate: 81.2,
    winLossRatio: 2.85,
    maxDrawdown: 1.60,
    profitFactor: 3.65,
    tradesCount: 2180,
    efficiencyScore: 95.8,
    latencyMs: 0.22,
    color: "#38bdf8",
  },
  {
    name: "QUANTUM MICRO-SCALP",
    category: "ULTRA-HFT SPOT",
    winRate: 89.1,
    winLossRatio: 4.10,
    maxDrawdown: 0.85,
    profitFactor: 5.20,
    tradesCount: 4890,
    efficiencyScore: 99.2,
    latencyMs: 0.14,
    color: "#00e676",
  },
  {
    name: "G7 SPREAD ARBITRAGE",
    category: "FX SPOT ARB",
    winRate: 92.4,
    winLossRatio: 4.80,
    maxDrawdown: 0.45,
    profitFactor: 6.10,
    tradesCount: 3120,
    efficiencyScore: 99.6,
    latencyMs: 0.19,
    color: "#a855f7",
  },
  {
    name: "GOLD SPOT MOMENTUM",
    category: "COMMODITY SPOT",
    winRate: 79.5,
    winLossRatio: 2.45,
    maxDrawdown: 2.10,
    profitFactor: 3.10,
    tradesCount: 940,
    efficiencyScore: 92.4,
    latencyMs: 0.15,
    color: "#f59e0b",
  },
];

// Historical equity curve & drawdown simulation data
const PERFORMANCE_TIMELINE = [
  { time: "00:00", alpha: 100.0, meanRev: 100.0, microScalp: 100.0, drawdown: -0.1 },
  { time: "04:00", alpha: 101.8, meanRev: 101.1, microScalp: 102.4, drawdown: -0.3 },
  { time: "08:00", alpha: 103.5, meanRev: 102.9, microScalp: 105.1, drawdown: -0.2 },
  { time: "12:00", alpha: 106.2, meanRev: 104.5, microScalp: 108.7, drawdown: -0.8 },
  { time: "16:00", alpha: 108.9, meanRev: 106.8, microScalp: 112.3, drawdown: -0.4 },
  { time: "20:00", alpha: 111.4, meanRev: 109.2, microScalp: 115.8, drawdown: -0.6 },
  { time: "24:00", alpha: 114.8, meanRev: 112.1, microScalp: 119.5, drawdown: -0.2 },
];

export const PerformanceAnalyticsPanel: React.FC = () => {
  const { t } = useLanguage();
  const [selectedMetric, setSelectedMetric] = useState<"EFFICIENCY" | "WIN_LOSS" | "DRAWDOWN" | "ALL">("EFFICIENCY");
  const [activeStrategyFilter, setActiveStrategyFilter] = useState<string>("ALL");

  const filteredStrategies = STRATEGY_DATA.filter(
    (s) => activeStrategyFilter === "ALL" || s.name.includes(activeStrategyFilter)
  );

  return (
    <div className="bg-[#090b11] border border-[#1b1f2e] rounded-2xl p-5 space-y-5 shadow-2xl">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#141724] pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#FA1F4E]/15 border border-[#FA1F4E]/50 rounded-xl text-[#FA1F4E] shadow-[0_0_15px_rgba(250,31,78,0.3)]">
            <Activity className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base sm:text-lg font-black text-white uppercase tracking-wider font-aquire">
                {t("MEMOBOT PERFORMANCE & STRATEGY EFFICIENCY ANALYTICS")}
              </h2>
              <span className="px-2 py-0.5 text-[9px] font-black bg-[#00e676]/15 border border-[#00e676]/50 text-[#00e676] rounded uppercase">
                {t("REAL-TIME DYNAMIC TELEMETRY")}
              </span>
            </div>
            <p className="text-xs text-[#8a8d9a]">
              {t("Visualizing strategy efficiency scores, win/loss ratios, trade distributions, and strictly controlled drawdowns.")}
            </p>
          </div>
        </div>

        {/* View Switcher Controls */}
        <div className="flex items-center gap-1.5 bg-[#05070a] p-1 border border-[#1e2336] rounded-xl">
          <button
            onClick={() => setSelectedMetric("EFFICIENCY")}
            className={`px-3 py-1 text-xs font-black uppercase rounded-lg transition-all cursor-pointer ${
              selectedMetric === "EFFICIENCY"
                ? "bg-[#FA1F4E] text-white shadow-[0_0_10px_rgba(250,31,78,0.4)]"
                : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            {t("EFFICIENCY")}
          </button>
          <button
            onClick={() => setSelectedMetric("WIN_LOSS")}
            className={`px-3 py-1 text-xs font-black uppercase rounded-lg transition-all cursor-pointer ${
              selectedMetric === "WIN_LOSS"
                ? "bg-[#38bdf8] text-black font-black shadow-[0_0_10px_rgba(56,189,248,0.4)]"
                : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            {t("WIN/LOSS RATIO")}
          </button>
          <button
            onClick={() => setSelectedMetric("DRAWDOWN")}
            className={`px-3 py-1 text-xs font-black uppercase rounded-lg transition-all cursor-pointer ${
              selectedMetric === "DRAWDOWN"
                ? "bg-[#00e676] text-black font-black shadow-[0_0_10px_rgba(0,230,118,0.4)]"
                : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            {t("DRAWDOWN GUARD")}
          </button>
          <button
            onClick={() => setSelectedMetric("ALL")}
            className={`px-3 py-1 text-xs font-black uppercase rounded-lg transition-all cursor-pointer ${
              selectedMetric === "ALL"
                ? "bg-[#a855f7] text-white shadow-[0_0_10px_rgba(168,85,247,0.4)]"
                : "text-[#8a8d9a] hover:text-white"
            }`}
          >
            {t("FULL SPECTRUM")}
          </button>
        </div>
      </div>

      {/* Top 4 Performance High-Impact Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-[#0c0f18] border border-[#1e2336] p-4 rounded-xl flex items-center justify-between relative overflow-hidden group hover:border-[#FA1F4E]/60 transition-all">
          <div>
            <span className="text-[9.5px] text-[#8a8d9a] font-black uppercase tracking-wider">{t("AVERAGE WIN RATE")}</span>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">85.36%</div>
            <div className="text-[10px] text-[#00e676] flex items-center gap-1 mt-0.5 font-bold">
              <ArrowUpRight className="w-3 h-3" />
              <span>+4.2% vs. Q2 Baseline</span>
            </div>
          </div>
          <div className="p-3 bg-[#FA1F4E]/10 rounded-xl text-[#FA1F4E] border border-[#FA1F4E]/20">
            <Award className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-[#0c0f18] border border-[#1e2336] p-4 rounded-xl flex items-center justify-between relative overflow-hidden group hover:border-[#38bdf8]/60 transition-all">
          <div>
            <span className="text-[9.5px] text-[#8a8d9a] font-black uppercase tracking-wider">{t("AGGREGATE WIN/LOSS RATIO")}</span>
            <div className="text-xl sm:text-2xl font-black text-[#38bdf8] mt-1">3.62 : 1</div>
            <div className="text-[10px] text-slate-400 mt-0.5 font-sans">{t("Reward to risk superiority")}</div>
          </div>
          <div className="p-3 bg-[#38bdf8]/10 rounded-xl text-[#38bdf8] border border-[#38bdf8]/20">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-[#0c0f18] border border-[#1e2336] p-4 rounded-xl flex items-center justify-between relative overflow-hidden group hover:border-[#00e676]/60 transition-all">
          <div>
            <span className="text-[9.5px] text-[#8a8d9a] font-black uppercase tracking-wider">{t("MAX OBSERVED DRAWDOWN")}</span>
            <div className="text-xl sm:text-2xl font-black text-[#00e676] mt-1">0.85%</div>
            <div className="text-[10px] text-emerald-400 mt-0.5 font-sans">{t("Guaranteed sub-3.0% hard stop")}</div>
          </div>
          <div className="p-3 bg-[#00e676]/10 rounded-xl text-[#00e676] border border-[#00e676]/20">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-[#0c0f18] border border-[#1e2336] p-4 rounded-xl flex items-center justify-between relative overflow-hidden group hover:border-[#a855f7]/60 transition-all">
          <div>
            <span className="text-[9.5px] text-[#8a8d9a] font-black uppercase tracking-wider">{t("TOTAL EXECUTED TRADES")}</span>
            <div className="text-xl sm:text-2xl font-black text-white mt-1">12,550</div>
            <div className="text-[10px] text-purple-400 mt-0.5 font-sans">{t("Zero-loss slippage verified")}</div>
          </div>
          <div className="p-3 bg-[#a855f7]/10 rounded-xl text-[#a855f7] border border-[#a855f7]/20">
            <Zap className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Main Charts Area */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Chart 1: Strategy Efficiency & Win/Loss Comparative Dynamic Bar Chart */}
        <div className="bg-[#05070a] border border-[#1e2336] p-4 rounded-xl space-y-3">
          <div className="flex items-center justify-between border-b border-[#141724] pb-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#FA1F4E]" />
              <h3 className="text-xs font-black text-white uppercase tracking-wider">
                {t("STRATEGY EFFICIENCY & WIN RATE COMPARISON (%)")}
              </h3>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">100% AUDITED</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={filteredStrategies} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#161b2a" />
                <XAxis
                  dataKey="name"
                  stroke="#64748b"
                  fontSize={9}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis stroke="#64748b" fontSize={9} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#090b11",
                    border: "1px solid #2d3748",
                    borderRadius: "8px",
                    color: "#fff",
                    fontSize: "11px",
                    fontFamily: "monospace",
                  }}
                  cursor={{ fill: "rgba(250, 31, 78, 0.05)" }}
                />
                <Legend wrapperStyle={{ fontSize: "10px", paddingTop: "10px" }} />
                <Bar dataKey="efficiencyScore" name={t("Efficiency Score (%)")} fill="#FA1F4E" radius={[4, 4, 0, 0]} />
                <Bar dataKey="winRate" name={t("Win Rate (%)")} fill="#38bdf8" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Cumulative Alpha & Controlled Drawdown Timeline */}
        <div className="bg-[#05070a] border border-[#1e2336] p-4 rounded-xl space-y-3">
          <div className="flex items-center justify-between border-b border-[#141724] pb-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#00e676]" />
              <h3 className="text-xs font-black text-white uppercase tracking-wider">
                {t("CUMULATIVE ALPHA GROWTH & DRAWDOWN PROFILE")}
              </h3>
            </div>
            <span className="text-[10px] text-emerald-400 font-mono font-bold">+19.5% PEAK SPOT</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={PERFORMANCE_TIMELINE} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="microScalpGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00e676" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#00e676" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="alphaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#FA1F4E" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#FA1F4E" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#161b2a" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={9} />
                <YAxis stroke="#64748b" fontSize={9} domain={[98, 122]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#090b11",
                    border: "1px solid #2d3748",
                    borderRadius: "8px",
                    color: "#fff",
                    fontSize: "11px",
                    fontFamily: "monospace",
                  }}
                />
                <Legend wrapperStyle={{ fontSize: "10px", paddingTop: "5px" }} />
                <Area
                  type="monotone"
                  dataKey="microScalp"
                  name={t("Micro-Scalping Alpha")}
                  stroke="#00e676"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#microScalpGrad)"
                />
                <Area
                  type="monotone"
                  dataKey="alpha"
                  name={t("Breakout Alpha")}
                  stroke="#FA1F4E"
                  strokeWidth={2}
                  fillOpacity={1}
                  fill="url(#alphaGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Granular Strategy Breakdown Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3 pt-2">
        {filteredStrategies.map((stg, i) => (
          <div
            key={i}
            className="bg-[#0c0f18] border border-[#1e2336] p-3.5 rounded-xl space-y-2 hover:border-[#FA1F4E]/60 transition-all shadow-sm"
          >
            <div className="flex items-center justify-between">
              <span className="text-[8.5px] px-1.5 py-0.5 rounded font-black uppercase bg-[#1e2336] text-[#8a8d9a]">
                {stg.category}
              </span>
              <span className="text-[10px] font-mono text-[#00e676] font-bold">{stg.efficiencyScore}%</span>
            </div>
            <div className="font-black text-white text-xs leading-snug">{stg.name}</div>

            <div className="space-y-1 pt-1 text-[9.5px]">
              <div className="flex justify-between text-slate-400">
                <span>{t("Win Rate:")}</span>
                <span className="text-white font-bold">{stg.winRate}%</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>{t("Win/Loss:")}</span>
                <span className="text-[#38bdf8] font-bold">{stg.winLossRatio} : 1</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>{t("Max Drawdown:")}</span>
                <span className="text-[#00e676] font-bold">{stg.maxDrawdown}%</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>{t("Profit Factor:")}</span>
                <span className="text-amber-300 font-bold">{stg.profitFactor}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PerformanceAnalyticsPanel;
