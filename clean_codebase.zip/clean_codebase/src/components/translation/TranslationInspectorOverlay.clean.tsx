import React, { useState, useEffect } from "react";
import { Sparkles, X, Check, Globe, Edit3 } from "lucide-react";
import { TranslationService } from "../../services/translationService";
import { transformToLiteralArabic, transformArabicToEnglish } from "../../config/arabicDictionary";

interface Props {
  isActive: boolean;
  onClose: () => void;
  showAlert: (msg: string) => void;
}

export const TranslationInspectorOverlay: React.FC<Props> = ({
  isActive,
  onClose,
  showAlert,
}) => {
  const [selectedText, setSelectedText] = useState<string | null>(null);
  const [arabicText, setArabicText] = useState<string>("");
  const [englishText, setEnglishText] = useState<string>("");
  const [dialogPos, setDialogPos] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (!isActive) {
      setSelectedText(null);
      setDialogPos(null);
      return;
    }

    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target) return;

      // Ignore clicks within inspector dialog itself
      if (target.closest("#translation-inspector-dialog") || target.closest("#translation-inspector-banner")) {
        return;
      }

      e.preventDefault();
      e.stopPropagation();

      // Extract raw or original text
      const orig = (target as any).__origText || target.innerText || target.textContent || "";
      const clean = orig.trim();
      if (!clean || clean.length < 2) return;

      // Determine English and Arabic versions
      const isAr = /[\u0600-\u06FF]/.test(clean);
      const en = isAr ? transformArabicToEnglish(clean) : clean;
      const ar = isAr ? clean : transformToLiteralArabic(clean);

      setSelectedText(clean);
      setEnglishText(en);
      setArabicText(ar);

      // Position dialog near click but within viewport
      const x = Math.min(Math.max(20, e.clientX - 160), window.innerWidth - 380);
      const y = Math.min(Math.max(60, e.clientY + 15), window.innerHeight - 320);
      setDialogPos({ x, y });
    };

    window.addEventListener("click", handleClick, true);
    return () => window.removeEventListener("click", handleClick, true);
  }, [isActive]);

  const handleSave = () => {
    if (!englishText.trim() || !arabicText.trim()) {
      showAlert("Both English and Arabic fields are required.");
      return;
    }

    const success = TranslationService.saveTranslation(englishText.trim(), arabicText.trim());
    if (success) {
      showAlert(`Translation saved! Updated "${englishText.slice(0, 20)}..." everywhere.`);
      setSelectedText(null);
      setDialogPos(null);
    }
  };

  if (!isActive) return null;

  return (
    <>
      {/* Top Banner Indicator */}
      <div
        id="translation-inspector-banner"
        className="fixed top-2 left-1/2 -translate-x-1/2 z-[99999] bg-[#0c0e14]/95 border border-cyan-500/80 shadow-[0_0_25px_rgba(6,182,212,0.4)] px-4 py-2 rounded-full flex items-center gap-3 text-xs font-mono text-cyan-300 backdrop-blur-md"
      >
        <span className="flex h-2.5 w-2.5 relative">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
        </span>
        <span className="font-bold tracking-wide">
          CLICK-TO-TRANSLATE ACTIVE: Click any text on screen to edit
        </span>
        <button
          onClick={onClose}
          className="ml-2 px-2 py-0.5 rounded bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-600/40 text-cyan-200 text-[10px] font-bold cursor-pointer"
        >
          Exit Inspector
        </button>
      </div>

      {/* Floating Quick Translation Dialog */}
      {dialogPos && selectedText && (
        <div
          id="translation-inspector-dialog"
          style={{ top: dialogPos.y, left: dialogPos.x }}
          className="fixed z-[999999] w-[360px] bg-[#0c0e16] border border-cyan-500/90 shadow-[0_10px_35px_rgba(0,0,0,0.8)] rounded-xl p-4 text-xs font-mono text-white space-y-3 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150"
        >
          <div className="flex items-center justify-between border-b border-[#1c2030] pb-2">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
              <Globe className="w-3.5 h-3.5" />
              <span>Translate Element</span>
            </div>
            <button
              onClick={() => { setSelectedText(null); setDialogPos(null); }}
              className="text-[#8a8d9a] hover:text-white p-1"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          <div>
            <label className="text-[10px] text-[#8a8d9a] uppercase block mb-1">English Source Text</label>
            <textarea
              value={englishText}
              onChange={(e) => setEnglishText(e.target.value)}
              rows={2}
              className="w-full p-2 bg-[#06070a] border border-[#1f232f] rounded text-white text-xs font-sans placeholder-[#555] focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div>
            <label className="text-[10px] text-[#8a8d9a] uppercase block mb-1">Arabic Translation (الترجمة العربية)</label>
            <textarea
              value={arabicText}
              onChange={(e) => setArabicText(e.target.value)}
              dir="rtl"
              rows={2}
              className="w-full p-2 bg-[#06070a] border border-[#1f232f] rounded text-white text-xs font-sans placeholder-[#555] focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex justify-between items-center pt-1 border-t border-[#1c2030]">
            <button
              type="button"
              onClick={() => { setSelectedText(null); setDialogPos(null); }}
              className="px-2.5 py-1 bg-[#141722] hover:bg-[#1c2030] border border-[#222] rounded text-[10px] text-[#8a8d9a]"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-[11px] font-bold flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Check className="w-3.5 h-3.5" />
              Save & Apply Everywhere
            </button>
          </div>
        </div>
      )}
    </>
  );
};
