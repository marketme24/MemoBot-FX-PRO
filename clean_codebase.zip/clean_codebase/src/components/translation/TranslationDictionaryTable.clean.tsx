import React, { useState, useMemo } from "react";
import { Search, Plus, Edit2, Trash2, Check, X, Sparkles, Filter, Copy, CheckCheck } from "lucide-react";
import { TranslationItem } from "../../services/translationStore";
import { TranslationService } from "../../services/translationService";

interface Props {
  items: TranslationItem[];
  accentColor: string;
  onSelectPhrase?: (item: TranslationItem) => void;
  showAlert: (msg: string) => void;
}

export const TranslationDictionaryTable: React.FC<Props> = ({
  items,
  accentColor,
  showAlert,
}) => {
  const [search, setSearch] = useState("");
  const [selectedCat, setSelectedCat] = useState<string>("all");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editArabic, setEditArabic] = useState("");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // New Phrase Form State
  const [showAddForm, setShowAddForm] = useState(false);
  const [newEn, setNewEn] = useState("");
  const [newAr, setNewAr] = useState("");

  const filtered = useMemo(() => {
    return items.filter((item) => {
      const matchSearch =
        !search ||
        item.english.toLowerCase().includes(search.toLowerCase()) ||
        item.arabic.includes(search);

      const matchCat =
        selectedCat === "all"
          ? true
          : selectedCat === "custom"
          ? item.isCustom
          : item.category === selectedCat;

      return matchSearch && matchCat;
    });
  }, [items, search, selectedCat]);

  const handleStartEdit = (item: TranslationItem) => {
    setEditingId(item.id);
    setEditArabic(item.arabic);
  };

  const handleSaveEdit = (item: TranslationItem) => {
    if (!editArabic.trim()) {
      showAlert("Translation cannot be empty.");
      return;
    }
    const success = TranslationService.saveTranslation(item.english, editArabic.trim());
    if (success) {
      showAlert(`Saved permanent translation for "${item.english.slice(0, 25)}..."`);
      setEditingId(null);
    }
  };

  const handleDelete = (item: TranslationItem) => {
    const success = TranslationService.deleteTranslation(item.english);
    if (success) {
      showAlert(`Removed custom override for "${item.english.slice(0, 25)}..."`);
    }
  };

  const handleAddNew = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEn.trim() || !newAr.trim()) {
      showAlert("Please enter both English text and Arabic translation.");
      return;
    }
    const success = TranslationService.saveTranslation(newEn.trim(), newAr.trim());
    if (success) {
      showAlert(`Added new custom phrase: "${newEn.slice(0, 25)}..."`);
      setNewEn("");
      setNewAr("");
      setShowAddForm(false);
    }
  };

  const handleCopy = (item: TranslationItem) => {
    navigator.clipboard.writeText(`${item.english} => ${item.arabic}`);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 1500);
  };

  return (
    <div className="space-y-4 text-xs font-mono">
      {/* Search & Actions Bar */}
      <div className="flex flex-col sm:flex-row gap-2 justify-between items-stretch sm:items-center bg-[#0d0e12] p-3 rounded-lg border border-[#1a1d26]">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#8a8d9a]" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search English or Arabic phrases..."
            className="w-full pl-9 pr-3 py-1.5 bg-[#06070a] border border-[#1f232f] rounded text-white text-xs placeholder-[#555] focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            style={{ backgroundColor: `${accentColor}20`, borderColor: accentColor, color: "#fff" }}
            className="px-3 py-1.5 rounded border text-[11px] font-bold flex items-center gap-1.5 cursor-pointer hover:brightness-110 transition-all shadow-sm"
          >
            <Plus className="w-3.5 h-3.5" style={{ color: accentColor }} />
            <span>Add Phrase</span>
          </button>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center gap-1.5">
        {[
          { id: "all", label: "All Phrases" },
          { id: "custom", label: "Custom Overrides ⭐" },
          { id: "vault", label: "Vault & Keys" },
          { id: "engines", label: "Engines & HFT" },
          { id: "risk", label: "Risk & Shariah" },
          { id: "settings", label: "Settings & Theme" },
          { id: "system", label: "System Core" },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCat(cat.id)}
            className={`px-2.5 py-1 rounded text-[10px] uppercase font-bold border transition-all cursor-pointer ${
              selectedCat === cat.id
                ? "bg-cyan-500/20 border-cyan-500 text-cyan-300"
                : "bg-[#0a0b0f] border-[#181a24] text-[#8a8d9a] hover:border-[#333] hover:text-white"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Add New Phrase Form */}
      {showAddForm && (
        <form onSubmit={handleAddNew} className="p-3.5 rounded-lg bg-[#0e1017] border border-cyan-500/40 space-y-3">
          <div className="flex items-center justify-between text-[11px] font-bold text-cyan-400">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Add Permanent Custom Translation
            </span>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-[#8a8d9a] hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-[#8a8d9a] uppercase block mb-1">English Source Text</label>
              <textarea
                value={newEn}
                onChange={(e) => setNewEn(e.target.value)}
                placeholder="e.g. FREEDOM MATRIX & AUDIT SYSTEM"
                rows={2}
                className="w-full p-2 bg-[#06070a] border border-[#1f232f] rounded text-white text-xs placeholder-[#555] focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div>
              <label className="text-[10px] text-[#8a8d9a] uppercase block mb-1">Arabic Translation (الترجمة العربية)</label>
              <textarea
                value={newAr}
                onChange={(e) => setNewAr(e.target.value)}
                placeholder="مثال: مصفوفة الحرية ونظام التدقيق"
                dir="rtl"
                rows={2}
                className="w-full p-2 bg-[#06070a] border border-[#1f232f] rounded text-white text-xs placeholder-[#555] focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-3 py-1 bg-[#141722] hover:bg-[#1a1d2c] border border-[#222] rounded text-[10px] text-[#8a8d9a]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded text-[10px] font-bold flex items-center gap-1"
            >
              <Check className="w-3 h-3" />
              Save Translation
            </button>
          </div>
        </form>
      )}

      {/* Translations List / Table */}
      <div className="border border-[#1a1d26] rounded-lg overflow-hidden bg-[#0a0b0f] divide-y divide-[#141722] max-h-[440px] overflow-y-auto">
        <div className="grid grid-cols-12 bg-[#0e1017] p-2.5 text-[10px] font-bold text-[#8a8d9a] uppercase sticky top-0 z-10 border-b border-[#1a1d26]">
          <div className="col-span-5">English Source</div>
          <div className="col-span-5 text-right">Arabic Translation (العربية)</div>
          <div className="col-span-2 text-center">Actions</div>
        </div>

        {filtered.length === 0 ? (
          <div className="p-8 text-center text-[#666]">
            No translations match your search filter. Click "+ Add Phrase" to create one.
          </div>
        ) : (
          filtered.map((item) => (
            <div key={item.id} className="grid grid-cols-12 p-2.5 items-center gap-2 hover:bg-[#11131a] transition-colors">
              {/* English */}
              <div className="col-span-5 text-white font-sans text-xs break-words pr-2">
                <span className="font-mono text-[11px]">{item.english}</span>
                {item.isCustom && (
                  <span className="ml-2 px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 text-[9px] font-bold border border-amber-500/30">
                    CUSTOM
                  </span>
                )}
              </div>

              {/* Arabic */}
              <div className="col-span-5 text-right font-sans text-xs break-words pl-2" dir="rtl">
                {editingId === item.id ? (
                  <div className="flex items-center gap-1.5 justify-end">
                    <input
                      type="text"
                      value={editArabic}
                      onChange={(e) => setEditArabic(e.target.value)}
                      className="w-full p-1.5 bg-[#06070a] border border-cyan-500 rounded text-white text-xs"
                      dir="rtl"
                      autoFocus
                    />
                    <button
                      onClick={() => handleSaveEdit(item)}
                      className="p-1.5 bg-emerald-600 hover:bg-emerald-500 rounded text-white"
                      title="Save"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setEditingId(null)}
                      className="p-1.5 bg-rose-900/60 hover:bg-rose-800 rounded text-[#8a8d9a]"
                      title="Cancel"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <span className="text-cyan-300 font-medium">{item.arabic}</span>
                )}
              </div>

              {/* Actions */}
              <div className="col-span-2 flex items-center justify-center gap-1">
                {editingId !== item.id && (
                  <>
                    <button
                      onClick={() => handleStartEdit(item)}
                      className="p-1.5 rounded bg-[#141722] hover:bg-cyan-950/60 border border-[#222] hover:border-cyan-500/50 text-[#8a8d9a] hover:text-cyan-300 transition-all"
                      title="Edit Translation"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => handleCopy(item)}
                      className="p-1.5 rounded bg-[#141722] hover:bg-[#1f2438] border border-[#222] text-[#8a8d9a] hover:text-white transition-all"
                      title="Copy"
                    >
                      {copiedId === item.id ? <CheckCheck className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    </button>
                    {item.isCustom && (
                      <button
                        onClick={() => handleDelete(item)}
                        className="p-1.5 rounded bg-[#141722] hover:bg-rose-950/60 border border-[#222] hover:border-rose-500/50 text-[#8a8d9a] hover:text-rose-400 transition-all"
                        title="Delete Custom Override"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      <div className="text-[10px] text-[#666] flex justify-between items-center px-1">
        <span>Showing {filtered.length} of {items.length} phrases</span>
        <span>All saved edits apply instantly across the entire application</span>
      </div>
    </div>
  );
};
