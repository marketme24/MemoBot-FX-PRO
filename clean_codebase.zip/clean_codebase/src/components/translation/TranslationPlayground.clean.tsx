import React, { useState } from "react";
import { Sparkles, ArrowRight, Check, Plus, RefreshCw } from "lucide-react";
import { transformToLiteralArabic, transformArabicToEnglish, ARABIC_DICTIONARY } from "../../config/arabicDictionary";
import { TranslationService } from "../../services/translationService";

interface Props {
  accentColor: string;
  showAlert: (msg: string) => void;
}

export const TranslationPlayground: React.FC<Props> = ({ accentColor, showAlert }) => {
  const [inputText, setInputText] = useState("");
  const [direction, setDirection] = useState<"en2ar" | "ar2en">("en2ar");

  const outputText = inputText
    ? direction === "en2ar"
      ? transformToLiteralArabic(inputText)
      : transformArabicToEnglish(inputText)
    : "";

  const handleSavePair = () => {
    if (!inputText.trim() || !outputText.trim()) return;

    const en = direction === "en2ar" ? inputText.trim() : outputText.trim();
    const ar = direction === "en2ar" ? outputText.trim() : inputText.trim();

    const success = TranslationService.saveTranslation(en, ar);
    if (success) {
      showAlert(`Added "${en.slice(0, 20)}..." to permanent dictionary.`);
    }
  };

  return (
    <div className="space-y-4 text-xs font-mono">
      <div className="bg-[#0d0e12] p-4 rounded-lg border border-[#1a1d26] space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-cyan-400 font-bold">
            <Sparkles className="w-4 h-4" />
            <span>Interactive Translation Simulator & Debugger</span>
          </div>

          <button
            onClick={() => setDirection(direction === "en2ar" ? "ar2en" : "en2ar")}
            className="px-2.5 py-1 rounded bg-[#141722] hover:bg-[#1a1d2e] border border-[#222] text-[#8a8d9a] hover:text-white flex items-center gap-1.5 text-[10px] cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            <span>{direction === "en2ar" ? "English ➔ Arabic" : "Arabic ➔ English"}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Input Panel */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-[10px] text-[#8a8d9a] uppercase font-bold">
              <span>{direction === "en2ar" ? "Source Text (English)" : "النص الأصلي (العربية)"}</span>
              <span>{inputText.length} chars</span>
            </div>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                direction === "en2ar"
                  ? "Type or paste any English sentence or term to test its Arabic output..."
                  : "اكتب أو الصق أي نص باللغة العربية لاختبار تحويله..."
              }
              rows={4}
              dir={direction === "ar2en" ? "rtl" : "ltr"}
              className="w-full p-3 bg-[#06070a] border border-[#1f232f] rounded-lg text-white font-sans text-xs placeholder-[#555] focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Output Panel */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-[10px] text-[#8a8d9a] uppercase font-bold">
              <span>{direction === "en2ar" ? "Live Output (العربية)" : "Live Output (English)"}</span>
              <span>{outputText.length} chars</span>
            </div>
            <div
              dir={direction === "en2ar" ? "rtl" : "ltr"}
              className="w-full p-3 min-h-[96px] bg-[#06070a] border border-[#1f232f] rounded-lg text-cyan-300 font-sans text-xs flex flex-col justify-between"
            >
              <span>{outputText || <span className="text-[#444] italic">Live translation will appear here instantly...</span>}</span>
              
              {inputText.trim() && (
                <div className="pt-2 flex justify-end">
                  <button
                    onClick={handleSavePair}
                    className="px-3 py-1 bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-500/50 text-cyan-200 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Save to Custom Dictionary</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
