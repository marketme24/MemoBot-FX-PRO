import { ApiClient } from "./api";
import { engineStore, WingsData } from "./engineStore";
import { Scheduler } from "./scheduler";
import { WebSocketManager } from "./websocket";
import { TOPICS } from "../config/constants";

export class EngineService {
  private static wsUnsubscribers: Array<() => void> = [];

  public static async init() {
    // Ensure clean state before initializing
    this.destroy();

    // Fetch initial configuration and active status
    await this.fetchEngineData();
    await this.fetchWingsData();

    // Register Polling Task for Wings Order Book depth (every 6 seconds)
    Scheduler.register("wings-polling-task", async () => {
      await this.fetchWingsData();
    }, 6000);

    // Register Polling Task for local second-based uptime tick
    Scheduler.register("engines-uptime-tick-task", () => {
      const state = engineStore.getState();
      const currentEngines = JSON.parse(JSON.stringify(state.engines));
      let updated = false;

      Object.keys(currentEngines).forEach((key) => {
        const eng = currentEngines[key];
        if (eng.status === "Running") {
          updated = true;
          eng.uptime_seconds += 1;
          // Progress 9-stage pipeline animation every 6 seconds for client visualization
          if (eng.uptime_seconds % 6 === 0) {
            eng.current_stage_idx = (eng.current_stage_idx + 1) % 9;
          }
        }
      });

      if (updated) {
        engineStore.setState({ engines: currentEngines });
      }
    }, 1000);

    // Subscribe to WS Realtime notifications (Rule 6, stateless reactive binding)
    const unsubEngine = WebSocketManager.subscribe(TOPICS.ENGINE_STATUS_CHANGED, (payload: any) => {
      console.log("[EngineService] WebSocket ENGINE_STATUS_CHANGED payload received:", payload);
      this.fetchEngineData();
    });

    const unsubMode = WebSocketManager.subscribe(TOPICS.ENGINE_MODE_CHANGED, (payload: any) => {
      console.log("[EngineService] WebSocket ENGINE_MODE_CHANGED payload received:", payload);
      this.fetchEngineData();
    });

    const unsubKill = WebSocketManager.subscribe(TOPICS.EMERGENCY_KILL_SWITCH_ACTIVATED, (payload: any) => {
      console.log("[EngineService] WebSocket EMERGENCY_KILL_SWITCH_ACTIVATED received:", payload);
      this.fetchEngineData();
    });

    const unsubConfig = WebSocketManager.subscribe(TOPICS.ENGINE_CONFIG_CHANGED, (payload: any) => {
      console.log("[EngineService] WebSocket ENGINE_CONFIG_CHANGED received:", payload);
      this.fetchEngineData();
    });

    const unsubMetrics = WebSocketManager.subscribe("ENGINE_METRICS_UPDATE", () => {
      this.fetchEngineData();
    });

    this.wsUnsubscribers = [unsubEngine, unsubMode, unsubKill, unsubConfig, unsubMetrics];
  }

  public static async fetchEngineData() {
    try {
      const overview = await ApiClient.get("/engine-monitoring/overview");
      const statusData = await ApiClient.get("/engine/status");

      engineStore.setState({
        engines: overview.engines || {},
        globalMode: (statusData.mode as "Paper" | "Live") || "Paper",
        liveModeConfirmed: statusData.live_mode_confirmed || false,
        complianceMode: (statusData.compliance_mode as "Islamic" | "Commercial") || "Islamic",
        loading: false,
        error: null
      });
    } catch (err: any) {
      console.error("[EngineService] API fetch engine data exception:", err);
      engineStore.setState({ loading: false, error: err.message });
    }
  }

  public static async fetchWingsData() {
    try {
      const state = engineStore.getState();
      const activeAssets = new Set<string>();
      
      Object.values(state.engines).forEach(eng => {
        if (eng.status === "Running") {
          // Normalize asset for API (e.g., BTCUSDT -> BTC-USDT)
          let asset = eng.asset;
          if (asset.includes("USDT") && !asset.includes("-")) {
            asset = asset.replace("USDT", "-USDT");
          }
          activeAssets.add(asset);
        }
      });

      // Always include BTC-USDT as fallback
      if (activeAssets.size === 0) activeAssets.add("BTC-USDT");

      const newWingsData: Record<string, WingsData> = { ...state.wingsData };

      for (const asset of activeAssets) {
        try {
          const res = await ApiClient.get<any>(`/execution/orderbook/${asset}`).catch(() => null);
          const engineKey = asset.replace("-", "");
          if (res && res.bids && res.asks) {
            const bidVol = res.bids.reduce((acc: number, b: any) => acc + b[1], 0);
            const askVol = res.asks.reduce((acc: number, a: any) => acc + a[1], 0);
            const buyPressure = parseFloat(((bidVol / (bidVol + askVol)) * 100).toFixed(1));

            newWingsData[engineKey] = {
              buy_pressure: buyPressure,
              bids: res.bids,
              asks: res.asks
            };
          } else if (!newWingsData[engineKey]) {
            // No data available
          }
        } catch (err) {
          // Soft fallback so UI continues seamlessly
        }
      }

      engineStore.setState({ wingsData: newWingsData });
    } catch (err) {
      console.error("[EngineService] fetchWingsData exception:", err);
    }
  }

  public static async toggleStartStop(engineId: string, currentStatus: "Running" | "Stopped") {
    const nextStatus = currentStatus === "Running" ? "Stopped" : "Running";
    await ApiClient.post("/engine/status", { engine_id: engineId, status: nextStatus });
    await this.fetchEngineData();
  }

  public static async configureEngine(engineId: string, params: { strategy?: string; asset?: string; amount?: number; leverage?: number }) {
    await ApiClient.post(`/engine-monitoring/${engineId}/configure`, params);
    await this.fetchEngineData();
  }

  public static async toggleGlobalMode(currentMode: "Paper" | "Live") {
    const nextMode = currentMode === "Paper" ? "Live" : "Paper";
    await ApiClient.post("/engine/mode", { mode: nextMode });
    await this.fetchEngineData();
  }

  public static async toggleComplianceMode(currentMode: "Islamic" | "Commercial") {
    const nextMode = currentMode === "Islamic" ? "Commercial" : "Islamic";
    await ApiClient.post("/engine/compliance-mode", { compliance_mode: nextMode });
    await this.fetchEngineData();
  }

  public static async confirmLiveGate() {
    await ApiClient.post("/engine/confirm-live");
    await this.fetchEngineData();
  }

  public static async executeManualTrade(engineId: string, nickname: string, side: "BUY" | "SELL", amount: number) {
    const response = await ApiClient.post("/execution/trade", {
      symbol: "BTC/USDT",
      side,
      type: "MARKET",
      amount,
      engine: nickname
    });
    await this.fetchEngineData();
    return response;
  }

  public static destroy() {
    // Unregister timers securely from Scheduler to avoid memory leaks (Rule 6)
    Scheduler.unregister("wings-polling-task");
    Scheduler.unregister("engines-uptime-tick-task");

    // Unsubscribe from WebSocket listeners
    this.wsUnsubscribers.forEach((unsub) => unsub());
    this.wsUnsubscribers = [];
  }
}
