import { Store } from "./store";
import { SocialCampaign, ActivityQueueItem } from "../types";

export interface SocialState {
  campaigns: SocialCampaign[];
  queue: ActivityQueueItem[];
  runningDaily: boolean;
  totalApproachesSent: number;
  overallSuccessRate: number;
  loading: boolean;
  error: string | null;
}

const initialSocialState: SocialState = {
  campaigns: [
    {
      id: "CAMP-001",
      name: "Arbitrage Alpha Outbound",
      platform: "Twitter/X",
      type: "Authority Thread",
      status: "Active",
      targetAudience: "Crypto & FX Retail Traders",
      generatedApproachesCount: 24,
      successRate: 18.5
    },
    {
      id: "CAMP-002",
      name: "Institutional Halal Capital",
      platform: "LinkedIn",
      type: "LinkedIn Outreach",
      status: "Active",
      targetAudience: "Islamic Fund Managers & Wealth Advisors",
      generatedApproachesCount: 12,
      successRate: 25.0
    },
    {
      id: "CAMP-003",
      name: "Reddit Trading Subreddit Swarm",
      platform: "Reddit",
      type: "Reddit Thread",
      status: "Active",
      targetAudience: "r/algotrading & r/forex communities",
      generatedApproachesCount: 35,
      successRate: 14.2
    },
    {
      id: "CAMP-004",
      name: "Whale Alert DM Approacher",
      platform: "Telegram",
      type: "Outbound DM",
      status: "Paused",
      targetAudience: "High-net-worth DeFi Liquidity Providers",
      generatedApproachesCount: 8,
      successRate: 37.5
    },
    {
      id: "CAMP-005",
      name: "VIP Dev Alpha Lounge Invite",
      platform: "Discord",
      type: "Value Comment",
      status: "Active",
      targetAudience: "Quantitative developers & Solidity engineers",
      generatedApproachesCount: 19,
      successRate: 22.0
    },
    {
      id: "CAMP-006",
      name: "Shariah Spot Newsletter",
      platform: "Email",
      type: "Newsletter",
      status: "Active",
      targetAudience: "Registered Subscriber Base (3,400+)",
      generatedApproachesCount: 4,
      successRate: 41.2
    },
    {
      id: "CAMP-007",
      name: "Arbitrage Alert Blast",
      platform: "SMS",
      type: "Blast SMS",
      status: "Active",
      targetAudience: "Opt-In SMS Alpha Alert subscribers",
      generatedApproachesCount: 15,
      successRate: 31.0
    },
    {
      id: "CAMP-008",
      name: "Visual Alpha Dashboard",
      platform: "Instagram",
      type: "Visual Post",
      status: "Active",
      targetAudience: "Retail Gen-Z FX Traders",
      generatedApproachesCount: 6,
      successRate: 19.8
    },
    {
      id: "CAMP-009",
      name: "Quant Code Walkthroughs",
      platform: "TikTok",
      type: "Video Script",
      status: "Active",
      targetAudience: "TikTok Algorithmic Coders",
      generatedApproachesCount: 2,
      successRate: 28.5
    },
    {
      id: "CAMP-010",
      name: "Islamic Capital Network",
      platform: "Facebook",
      type: "Value Comment",
      status: "Paused",
      targetAudience: "Ethical & Halal Forex Guild Groups",
      generatedApproachesCount: 1,
      successRate: 15.0
    }
  ],
  queue: [
    {
      id: "Q-001",
      platform: "Twitter/X",
      campaignName: "Arbitrage Alpha Outbound",
      content: "⚡ MemoBot Smart Arb is observing a persistent 0.04% price spread in SPOT BTC/USDT between Binance and OKX. Executed completely Riba-free. Non-leveraged spot allocation secured. #MemoBot #CryptoArb",
      recipient: "Public (Scheduled Post)",
      scheduledAt: new Date(Date.now() + 1800000).toISOString(),
      status: "Pending"
    },
    {
      id: "Q-002",
      platform: "LinkedIn",
      campaignName: "Institutional Halal Capital",
      content: "Respected Partner, we have successfully completed our Q3 Halal compliance audit for quantitative spot trading. Our 100% spot allocation model bypasses futures margin lending. Would you be open to reviewing our certified compliance prospectus?",
      recipient: "Director of Islamic Asset Management, Dubai",
      scheduledAt: new Date(Date.now() + 3600000).toISOString(),
      status: "Pending"
    },
    {
      id: "Q-003",
      platform: "Reddit",
      campaignName: "Reddit Trading Subreddit Swarm",
      content: "How we configured a custom Node.js Express server with a lock-free Ring Buffer to execute spot-only FX trades with sub-millisecond latencies under Islamic non-leveraged guidelines. Full architecture diagram inside thread.",
      recipient: "r/algotrading thread",
      scheduledAt: new Date(Date.now() + 5400000).toISOString(),
      status: "Pending"
    }
  ],
  runningDaily: true,
  totalApproachesSent: 98,
  overallSuccessRate: 21.4,
  loading: false,
  error: null
};

class SocialStoreClass extends Store<SocialState> {
  constructor() {
    super(initialSocialState);
  }
}

export const socialStore = new SocialStoreClass();
export default socialStore;
