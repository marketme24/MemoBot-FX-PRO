import { API_CONFIG } from "./api";

type EventCallback = (data: any) => void;

export class WebSocketManager {
  private static socket: WebSocket | null = null;
  private static listeners = new Map<string, Set<EventCallback>>();
  private static reconnectTimer: any = null;
  private static attempts = 0;
  private static pingTimer: any = null;
  public static onLatencyChange: ((latency: number) => void) | null = null;
  public static onStatusChange: ((status: "CONNECTED" | "DISCONNECTED") => void) | null = null;

  public static isConnected(): boolean {
    return this.socket !== null && this.socket.readyState === WebSocket.OPEN;
  }

  public static connect() {
    if (this.socket && (this.socket.readyState === WebSocket.CONNECTING || this.socket.readyState === WebSocket.OPEN)) {
      if (this.socket.readyState === WebSocket.OPEN && this.onStatusChange) {
        this.onStatusChange("CONNECTED");
      }
      return;
    }

    try {
      this.socket = new WebSocket(API_CONFIG.WS_URL);
      
      this.socket.onopen = () => {
        console.log("WebSocket Connection Established");
        this.attempts = 0;
        if (this.onStatusChange) this.onStatusChange("CONNECTED");
        this.startPingPong();
      };

      this.socket.onmessage = (event) => {
        if (event.data === "pong") {
          const latency = Date.now() - this.lastPingTime;
          if (this.onLatencyChange) this.onLatencyChange(latency);
          return;
        }

        try {
          const payload = JSON.parse(event.data);
          const topic = payload.event;
          if (topic) {
            const set = this.listeners.get(topic);
            if (set) {
              set.forEach(cb => cb(payload));
            }
          }
        } catch (err) {
          // Silent catch for non-JSON frame payloads
        }
      };

      this.socket.onclose = () => {
        this.socket = null;
        if (this.onStatusChange) this.onStatusChange("DISCONNECTED");
        this.stopPingPong();
        this.scheduleReconnect();
      };

      this.socket.onerror = (_err) => {
        if (this.onStatusChange) this.onStatusChange("DISCONNECTED");
      };
    } catch (e) {
      if (this.onStatusChange) this.onStatusChange("DISCONNECTED");
    }
  }

  private static lastPingTime = 0;
  private static startPingPong() {
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.pingTimer = setInterval(() => {
      if (this.socket && this.socket.readyState === WebSocket.OPEN) {
        this.lastPingTime = Date.now();
        this.socket.send("ping");
      }
    }, 10000);
  }

  private static stopPingPong() {
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
  }

  private static scheduleReconnect() {
    if (this.reconnectTimer) return;
    this.attempts++;
    const delay = Math.min(1000 * Math.pow(2, this.attempts), 15000);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, delay);
  }

  public static subscribe(topic: string, callback: EventCallback) {
    if (!this.listeners.has(topic)) {
      this.listeners.set(topic, new Set());
    }
    this.listeners.get(topic)!.add(callback);
    return () => this.unsubscribe(topic, callback);
  }

  public static unsubscribe(topic: string, callback: EventCallback) {
    const set = this.listeners.get(topic);
    if (set) {
      set.delete(callback);
      if (set.size === 0) {
        this.listeners.delete(topic);
      }
    }
  }

  public static disconnect() {
    this.stopPingPong();
    if (this.socket) {
      this.socket.close();
      this.socket = null;
    }
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
  }
}
