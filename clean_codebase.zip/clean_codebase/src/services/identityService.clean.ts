import { ApiClient } from "./api";
import { identityStore } from "./identityStore";
import { TierId } from "../types";

export class IdentityService {
  public static async switchTier(tier: TierId, customUsername?: string): Promise<void> {
    try {
      // Sync with backend if available
      await ApiClient.post("/auth/provision-tier", {
        tier,
        username: customUsername
      }).catch(() => {
        // Safe graceful fallback if offline / standalone
      });
    } finally {
      identityStore.setTier(tier, customUsername);
    }
  }

  public static async verifyWebAuthn(): Promise<boolean> {
    return new Promise((resolve) => {
      setTimeout(() => {
        identityStore.setState({ biometricActive: true });
        resolve(true);
      }, 600);
    });
  }

  public static async verifyMFA(code: string): Promise<boolean> {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (code.length >= 4) {
          identityStore.setState({ mfaVerified: true });
          resolve(true);
        } else {
          resolve(false);
        }
      }, 500);
    });
  }

  public static async verifySSO(samlToken: string): Promise<boolean> {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(true);
      }, 700);
    });
  }

  public static async verifyMTLS(): Promise<boolean> {
    return new Promise((resolve) => {
      setTimeout(() => {
        identityStore.setState({ mtlsVerified: true });
        resolve(true);
      }, 600);
    });
  }

  public static toggleIdentityDrawer(isOpen?: boolean): void {
    identityStore.toggleIdentityModal(isOpen);
  }
}
