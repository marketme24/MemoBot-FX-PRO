import { STORAGE_KEYS } from "../config/constants";

// Environment Configuration (Rule 3)
const resolveApiConfig = () => {
  const origin = typeof window !== "undefined" && window.location?.origin 
    ? window.location.origin 
    : "";
  const protocol = typeof window !== "undefined" && window.location?.protocol === "https:" 
    ? "wss:" 
    : "ws:";
  const host = typeof window !== "undefined" && window.location?.host 
    ? window.location.host 
    : "localhost:3000";
  
  const baseUrl = `${origin}/api/v1`;
  const wsUrl = `${protocol}//${host}/api/ws`;
  
  return {
    BASE_URL: baseUrl,
    WS_URL: wsUrl
  };
};

export const API_CONFIG = resolveApiConfig();

export class ApiClient {
  private static inFlightRequests = new Map<string, Promise<any>>();
  private static cache = new Map<string, { data: any; timestamp: number }>();
  private static CACHE_TTL_MS = 1500;

  private static getHeaders(correlationId?: string): HeadersInit {
    const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) || sessionStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      "X-Correlation-ID": correlationId
    };
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }
    return headers;
  }

  public static async request<T = any>(endpoint: string, options: RequestInit = {}, retries = 2): Promise<T> {
    const cleanEndpoint = endpoint.startsWith("/") ? endpoint : "/" + endpoint;
    const url = `${API_CONFIG.BASE_URL}${cleanEndpoint}`;
    const method = (options.method || "GET").toUpperCase();

    // Check GET cache
    if (method === "GET") {
      const cached = this.cache.get(cleanEndpoint);
      if (cached && Date.now() - cached.timestamp < this.CACHE_TTL_MS) {
        return cached.data as T;
      }

      // Check deduplication for in-flight GET requests
      if (this.inFlightRequests.has(cleanEndpoint)) {
        return this.inFlightRequests.get(cleanEndpoint) as Promise<T>;
      }
    }

    const headers = {
      ...this.getHeaders(),
      ...(options.headers || {})
    };

    const executeRequest = async (): Promise<T> => {
      try {
        const response = await fetch(url, { ...options, headers });
        
        if (response.status === 401 && !endpoint.includes("/auth/login-json")) {
          localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
          sessionStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
          window.location.hash = "/login";
          throw new Error("Session expired. Access denied.");
        }

        if (response.status === 429) {
          if (retries > 0) {
            return this.request<T>(endpoint, options, retries - 1);
          }
          // If 429 persists and we have cached data, return cached data
          const cached = this.cache.get(cleanEndpoint);
          if (cached) {
            return cached.data as T;
          }
          throw new Error("Rate limit reached. Please try again shortly.");
        }

        const contentType = response.headers.get("content-type") || "";
        if (!contentType.includes("application/json")) {
          if (retries > 0) {
            return this.request<T>(endpoint, options, retries - 1);
          }
          const text = await response.text();
          throw new Error(`Non-JSON response received (${response.status}): ${text.slice(0, 100)}`);
        }

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          throw new Error(errorData.error || errorData.message || errorData.reason || `HTTP Error ${response.status}`);
        }

        const data = await response.json();
        if (method === "GET") {
          this.cache.set(cleanEndpoint, { data, timestamp: Date.now() });
        }
        return data;
      } catch (err: any) {
        if (retries > 0 && err?.message?.includes("Rate limit")) {
          return this.request<T>(endpoint, options, retries - 1);
        }
        throw err;
      } finally {
        if (method === "GET") {
          this.inFlightRequests.delete(cleanEndpoint);
        }
      }
    };

    if (method === "GET") {
      const requestPromise = executeRequest();
      this.inFlightRequests.set(cleanEndpoint, requestPromise);
      return requestPromise;
    }

    return executeRequest();
  }

  public static get<T = any>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: "GET" });
  }

  public static post<T = any>(endpoint: string, body?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: "POST",
      body: body ? JSON.stringify(body) : undefined
    });
  }

  public static put<T = any>(endpoint: string, body?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: "PUT",
      body: body ? JSON.stringify(body) : undefined
    });
  }

  public static delete<T = any>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: "DELETE" });
  }
}
