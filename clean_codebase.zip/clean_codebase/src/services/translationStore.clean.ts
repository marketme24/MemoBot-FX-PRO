import { Store } from "./store";
import { loadCustomPermanentTranslations, ARABIC_DICTIONARY } from "../config/arabicDictionary";

export interface TranslationItem {
  id: string;
  english: string;
  arabic: string;
  isCustom: boolean;
  category: "all" | "vault" | "engines" | "risk" | "settings" | "custom" | "system";
  updatedAt?: string;
}

export interface TranslationState {
  isOpen: boolean;
  isInspectorActive: boolean;
  searchQuery: string;
  activeCategory: string;
  customCount: number;
  totalCount: number;
  selectedItem: TranslationItem | null;
  inspectedElementText: string | null;
  lastUpdated: number;
}

const initialCustoms = loadCustomPermanentTranslations();

const initialState: TranslationState = {
  isOpen: false,
  isInspectorActive: false,
  searchQuery: "",
  activeCategory: "all",
  customCount: Object.keys(initialCustoms).length,
  totalCount: Object.keys(ARABIC_DICTIONARY).length,
  selectedItem: null,
  inspectedElementText: null,
  lastUpdated: Date.now()
};

export class TranslationStore extends Store<TranslationState> {
  private static instance: TranslationStore;

  private constructor() {
    super(initialState);
  }

  public static getInstance(): TranslationStore {
    if (!TranslationStore.instance) {
      TranslationStore.instance = new TranslationStore();
    }
    return TranslationStore.instance;
  }
}

export const translationStore = TranslationStore.getInstance();
